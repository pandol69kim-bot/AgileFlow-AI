# EnglishGreet 컴포넌트 명세서 (Atomic Design)

**버전**: v1.0  
**작성일**: 2025년 1월  
**대상**: 개발팀  
**상태**: Review 대기

---

## 📑 목차

1. [Atoms (원자)](#atoms-원자)
2. [Molecules (분자)](#molecules-분자)
3. [Organisms (유기체)](#organisms-유기체)
4. [사용 예시](#사용-예시)

---

## Atoms (원자)

### 1. Button (버튼)

**목적**: 사용자 액션 트리거  
**사용 위치**: 전체 앱

```typescript
// Props 정의
interface ButtonProps {
  // 필수 props
  label: string;                    // 버튼 텍스트
  onClick: () => void;              // 클릭 핸들러

  // 선택 props
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  loading?: boolean;
  icon?: React.ReactNode;           // 버튼 좌측 아이콘
  fullWidth?: boolean;
  className?: string;
}

// State 정의
interface ButtonState {
  isHovered: boolean;
  isPressed: boolean;
  isFocused: boolean;
}
```

**사용 사례**:
```tsx
<Button 
  label="표현 재생" 
  variant="primary" 
  size="medium"
  onClick={() => playAudio()} 
/>

<Button 
  label="즐겨찾기" 
  variant="secondary" 
  icon={<HeartIcon />}
/>

<Button 
  label="로그인" 
  disabled={!isFormValid}
  loading={isLoading}
/>
```

**스타일 가이드**:
- Primary: 파란색 (#4A90E2), 높이 44px
- Secondary: 그레이 (#E8EAED), 높이 44px
- Ghost: 투명 배경, 텍스트 컬러만
- Danger: 빨간색 (#E74C3C)

---

### 2. Badge (배지)

**목적**: 상황/난이도/카테고리 표시  
**사용 위치**: 표현 카드, 검색 결과

```typescript
interface BadgeProps {
  // 필수 props
  label: string;                    // 배지 텍스트

  // 선택 props
  type?: 'situation' | 'level' | 'category';
  color?: 'blue' | 'green' | 'orange' | 'purple';
  size?: 'small' | 'medium';
  icon?: React.ReactNode;
  dismissible?: boolean;            // X 버튼 표시 여부
  onDismiss?: () => void;
}

// State 정의
interface BadgeState {
  isHovered: boolean;
  isActive: boolean;
}
```

**사용 사례**:
```tsx
<Badge 
  label="업무 미팅" 
  type="situation" 
  color="blue"
/>

<Badge 
  label="초급" 
  type="level" 
  color="green"
/>

<Badge 
  label="인삿말" 
  type="category"
  dismissible={true}
  onDismiss={handleRemove}
/>
```

---

### 3. AudioButton (오디오 재생 버튼)

**목적**: 발음 재생 제어  
**사용 위치**: 표현 상세, 검색 결과

```typescript
interface AudioButtonProps {
  // 필수 props
  audioUrl: string;                 // 음성 파일 URL
  onPlay?: () => void;
  onPause?: () => void;

  // 선택 props
  variant?: 'icon-only' | 'with-text';
  speed?: 0.75 | 1 | 1.25 | 1.5;   // 재생 속도
  showWaveform?: boolean;           // 파형 표시
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
}

// State 정의
interface AudioButtonState {
  isPlaying: boolean;
  currentTime: number;              // 현재 재생 시간 (초)
  duration: number;                 // 전체 길이 (초)
  isLoading: boolean;
  error: string | null;
}
```

**사용 사례**:
```tsx
<AudioButton 
  audioUrl="/audio/hello.mp3"
  variant="with-text"
  speed={1}
  showWaveform={true}
/>

<AudioButton 
  audioUrl="/audio/nice-to-meet.mp3"
  variant="icon-only"
  size="large"
/>
```

---

### 4. Tag (태그)

**목적**: 표현 속성 표시 (발음, 문법 등)  
**사용 위치**: 표현 상세 페이지

```typescript
interface TagProps {
  // 필수 props
  label: string;                    // 태그 텍스트

  // 선택 props
  type?: 'pronunciation' | 'grammar' | 'colloquial' | 'formal';
  size?: 'small' | 'medium';
  variant?: 'filled' | 'outlined';
}

// State 정의
interface TagState {
  isHovered: boolean;
}
```

**사용 사례**:
```tsx
<Tag label="발음" type="pronunciation" />
<Tag label="문어체" type="formal" variant="outlined" />
```

---

### 5. ProgressBar (진행 바)

**목적**: 음성 재생 진행도 표시  
**사용 위치**: 오디오 플레이어

```typescript
interface ProgressBarProps {
  // 필수 props
  current: number;                  // 현재 진행도 (초)
  total: number;                    // 전체 길이 (초)

  // 선택 props
  height?: number;                  // 높이 (px)
  color?: string;                   // 프로그레스 색상
  backgroundColor?: string;
  onSeek?: (time: number) => void;  // 시간 이동 핸들러
  isDragging?: boolean;
}

// State 정의
interface ProgressBarState {
  isDragging: boolean;
  hoverTime: number | null;
}
```

**사용 사례**:
```tsx
<ProgressBar 
  current={15}
  total={45}
  onSeek={(time) => seekAudio(time)}
/>
```

---

### 6. Icon (아이콘)

**목적**: 시각적 정보 전달  
**사용 위치**: 버튼, 네비게이션, 상태 표시

```typescript
interface IconProps {
  // 필수 props
  name: string;  // 'play' | 'pause' | 'heart' | 'search' | 'bookmark' | 'share' | 'volume' | 'settings' | 'home' | 'favorites' | 'profile' | 'clock' | 'download' | 'edit' | 'delete' | 'copy' | 'check'

  // 선택 props
  size?: 16 | 20 | 24 | 32 | 48;    // 크기 (px)
  color?: string;                   // HEX 컬러 값
  weight?: 'light' | 'regular' | 'bold';
  className?: string;
}

// State 정의
interface IconState {
  isLoaded: boolean;
}
```

**사용 사례**:
```tsx
<Icon name="play" size={24} color="#4A90E2" />
<Icon name="heart" size={20} weight="bold" />
```

---

## Molecules (분자)

### 1. ExpressionCard (표현 카드)

**목적**: 개별 영어 표현 표시  
**사용 위치**: 검색 결과, 즐겨찾기, 홈 화면

```typescript
interface ExpressionCardProps {
  // 필수 props
  id: string;
  englishText: string;              // 영어 표현
  koreanText: string;               // 한글 번역
  audioUrl: string;                 // 발음 파일 URL
  
  // 선택 props
  situation?: string;               // "업무 미팅", "첫 만남" 등
  difficulty?: 'beginner' | 'intermediate' | 'advanced';
  isFavorite?: boolean;
  onFavoriteToggle?: (id: string) => void;
  onPlayAudio?: (audioUrl: string) => void;
  onShare?: (id: string) => void;
  showBadge?: boolean;
  isSelected?: boolean;             // 다중 선택 모드
  onSelect?: (id: string) => void;
}

// State 정의
interface ExpressionCardState {
  isPlaying: boolean;
  isHovered: boolean;
  isFavoriteAnimating: boolean;     // 좋아요 애니메이션
}
```

**레이아웃**:
```
┌─────────────────────────┐
│ [음성] "Hello, nice..." │  ← AudioButton + 영어 텍스트
│                         │
│ 안녕하세요, 반갑습니다. │  ← 한글 번역
│                         │
│ 🏢 업무미팅  📈 초급    │  ← Badge들
│                         │
│ ❤️ 공유 🔗 복사         │  ← 액션 버튼들
└─────────────────────────┘
```

**사용 사례**:
```tsx
<ExpressionCard 
  id="expr_001"
  englishText="Hello, nice to meet you"
  koreanText="안녕하세요, 반갑습니다"
  audioUrl="/audio/hello.mp3"
  situation="첫 만남"
  difficulty="beginner"
  isFavorite={false}
  onFavoriteToggle={toggleFavorite}
  showBadge={true}
/>
```

---

### 2. SearchBar (검색 바)

**목적**: 표현 검색 입력  
**사용 위치**: 검색 페이지, 헤더

```typescript
interface SearchBarProps {
  // 필수 props
  placeholder?: string;
  onSearch: (query: string) => void;

  // 선택 props
  value?: string;
  onChange?: (value: string) => void;
  onClear?: () => void;
  autoFocus?: boolean;
  disabled?: boolean;
  showHistory?: boolean;            // 검색 이력 표시
  onHistorySelect?: (history: string) => void;
  recentSearches?: string[];        // 최근 검색어
}

// State 정의
interface SearchBarState {
  isFocused: boolean;
  hasValue: boolean;
  isSearching: boolean;
  showHistorySuggestions: boolean;
}
```

**사용 사례**:
```tsx
<SearchBar 
  placeholder="표현, 상황, 키워드 입력..."
  onSearch={handleSearch}
  showHistory={true}
  recentSearches={["hello", "how are you"]}
/>
```

---

### 3. ExpressionForm (표현 입력 폼)

**목적**: 관리자가 새로운 표현 추가  
**사용 위치**: 관리 화면 (v2.0+)

```typescript
interface ExpressionFormProps {
  // 필수 props
  onSubmit: (data: ExpressionData) => void;

  // 선택 props
  initialData?: ExpressionData;      // 수정 모드
  mode?: 'create' | 'edit';
  onCancel?: () => void;
  disabled?: boolean;
}

interface ExpressionData {
  englishText: string;
  koreanText: string;
  audioUrl?: string;
  situation: string;                // 상황 선택지
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  explanation?: string;             // 상세 설명
  exampleUsage?: string;            // 사용 예시
  tags?: string[];
}

// State 정의
interface ExpressionFormState {
  isValid: boolean;
  isSubmitting: boolean;
  errors: Partial<Record<keyof ExpressionData, string>>;
  isDirty: boolean;
}
```

---

### 4. LanguageSelector (언어 선택기)

**목적**: 네이티브 발음 선택  
**사용 위치**: 표현 상세, 설정

```typescript
interface LanguageSelectorProps {
  // 필수 props
  currentLanguage: 'en-US' | 'en-GB' | 'en-AU';
  onLanguageChange: (lang: string) => void;

  // 선택 props
  size?: 'small' | 'medium';
  showLabels?: boolean;
  disabled?: boolean;
}

// State 정의
interface LanguageSelectorState {
  isOpen: boolean;
  isLoading: boolean;
}

// 옵션
const LANGUAGE_OPTIONS = [
  { code: 'en-US', label: '미국 영어 🇺🇸' },
  { code: 'en-GB', label: '영국 영어 🇬🇧' },
  { code: 'en-AU', label: '호주 영어 🇦🇺' },
];
```

---

### 5. SituationFilter (상황 필터)

**목적**: 상황별 표현 필터링  
**사용 위치**: 검색 결과, 홈 화면

```typescript
interface SituationFilterProps {
  // 필수 props
  situations: SituationOption[];
  selectedSituations: string[];
  onSituationToggle: (situation: string) => void;

  // 선택 props
  variant?: 'horizontal' | 'vertical' | 'dropdown';
  multiSelect?: boolean;
  disabled?: boolean;
}

interface SituationOption {
  id: string;
  label: string;
  icon?: React.ReactNode;
  color?: string;
}

// 기본 상황 목록
const SITUATIONS = [
  { id: 'greeting', label: '인삿말', icon: '👋' },
  { id: 'business', label: '업무', icon: '🏢' },
  { id: 'travel', label: '여행', icon: '✈️' },
  { id: 'casual', label: '일상', icon: '💬' },
  { id: 'emergency', label: '긴급', icon: '🆘' },
];

// State 정의
interface SituationFilterState {
  selectedCount: number;
  isExpanded: boolean;
}
```

**사용 사례**:
```tsx
<SituationFilter 
  situations={SITUATIONS}