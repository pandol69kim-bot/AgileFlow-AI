# EnglishGreet UI 컴포넌트 라이브러리

핵심 UI 컴포넌트 5개를 작성하겠습니다 (Button, StatusBadge, ProgressBar + 2개 기능 컴포넌트).

## 1. Button.tsx

```jsx
import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import clsx from 'clsx';

const buttonVariants = cva(
  'inline-flex items-center justify-center font-semibold rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2',
  {
    variants: {
      variant: {
        primary: 'bg-blue-500 text-white hover:bg-blue-700 focus:ring-blue-500',
        secondary:
          'bg-orange-500 text-white hover:bg-orange-700 focus:ring-orange-500',
        success: 'bg-green-500 text-white hover:bg-green-700 focus:ring-green-500',
        danger: 'bg-red-500 text-white hover:bg-red-700 focus:ring-red-500',
        outline:
          'border-2 border-blue-500 text-blue-500 hover:bg-blue-50 focus:ring-blue-500',
        ghost: 'text-blue-600 hover:bg-blue-100 focus:ring-blue-500',
      },
      size: {
        sm: 'px-3 py-1.5 text-sm',
        md: 'px-4 py-2 text-base',
        lg: 'px-6 py-3 text-lg',
        xl: 'px-8 py-4 text-xl',
      },
      fullWidth: {
        true: 'w-full',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  isLoading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      fullWidth,
      isLoading,
      icon,
      iconPosition = 'left',
      children,
      disabled,
      ...props
    },
    ref
  ) => {
    return (
      <button
        ref={ref}
        className={clsx(
          buttonVariants({ variant, size, fullWidth }),
          className
        )}
        disabled={isLoading || disabled}
        {...props}
      >
        {isLoading && (
          <svg
            className={clsx(
              'animate-spin h-4 w-4',
              iconPosition === 'left' && 'mr-2'
            )}
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        )}
        {icon && !isLoading && (
          <span
            className={clsx(
              'flex items-center',
              iconPosition === 'left' ? 'mr-2' : 'ml-2'
            )}
          >
            {icon}
          </span>
        )}
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
```

## 2. StatusBadge.tsx

```jsx
import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import clsx from 'clsx';

const statusBadgeVariants = cva(
  'inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium',
  {
    variants: {
      status: {
        success: 'bg-green-100 text-green-800',
        warning: 'bg-orange-100 text-orange-800',
        error: 'bg-red-100 text-red-800',
        info: 'bg-blue-100 text-blue-800',
        inactive: 'bg-gray-100 text-gray-800',
        premium: 'bg-purple-100 text-purple-800',
      },
    },
    defaultVariants: {
      status: 'info',
    },
  }
);

interface StatusBadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof statusBadgeVariants> {
  icon?: React.ReactNode;
  pulse?: boolean;
}

export const StatusBadge = React.forwardRef<HTMLDivElement, StatusBadgeProps>(
  ({ className, status, icon, pulse, children, ...props }, ref) => {
    const statusDotColors = {
      success: 'bg-green-500',
      warning: 'bg-orange-500',
      error: 'bg-red-500',
      info: 'bg-blue-500',
      inactive: 'bg-gray-500',
      premium: 'bg-purple-500',
    };

    return (
      <div
        ref={ref}
        className={clsx(statusBadgeVariants({ status }), className)}
        {...props}
      >
        {icon ? (
          <span>{icon}</span>
        ) : (
          <span
            className={clsx(
              'w-2 h-2 rounded-full',
              statusDotColors[status || 'info'],
              pulse && 'animate-pulse'
            )}
          />
        )}
        {children}
      </div>
    );
  }
);

StatusBadge.displayName = 'StatusBadge';
```

## 3. ProgressBar.tsx

```jsx
import React from 'react';
import clsx from 'clsx';

interface ProgressBarProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number; // 0-100
  max?: number;
  variant?: 'primary' | 'success' | 'warning' | 'error';
  animated?: boolean;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const ProgressBar = React.forwardRef<HTMLDivElement, ProgressBarProps>(
  (
    {
      value,
      max = 100,
      variant = 'primary',
      animated = false,
      showLabel = false,
      size = 'md',
      className,
      ...props
    },
    ref
  ) => {
    const percentage = Math.min((value / max) * 100, 100);

    const variantColors = {
      primary: 'bg-blue-500',
      success: 'bg-green-500',
      warning: 'bg-orange-500',
      error: 'bg-red-500',
    };

    const sizeClasses = {
      sm: 'h-1.5',
      md: 'h-2.5',
      lg: 'h-3.5',
    };

    return (
      <div
        ref={ref}
        className={clsx(
          'w-full bg-gray-200 rounded-full overflow-hidden',
          sizeClasses[size],
          className
        )}
        {...props}
      >
        <div
          className={clsx(
            'transition-all duration-300 ease-out',
            variantColors[variant],
            animated && 'animate-pulse',
            'h-full rounded-full'
          )}
          style={{ width: `${percentage}%` }}
        />
        {showLabel && (
          <div className="flex items-center justify-center text-xs font-semibold text-gray-700 mt-1">
            {Math.round(percentage)}%
          </div>
        )}
      </div>
    );
  }
);

ProgressBar.displayName = 'ProgressBar';
```

## 4. LearningCard.tsx (기능 컴포넌트 1)

```jsx
import React, { useState } from 'react';
import clsx from 'clsx';
import { Button } from './Button';
import { StatusBadge } from './StatusBadge';
import { ProgressBar } from './ProgressBar';

interface LearningCardProps {
  id: string;
  title: string;
  description: string;
  progress: number; // 0-100
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  category: string;
  isCompleted?: boolean;
  isPremium?: boolean;
  onStart?: () => void;
  onContinue?: () => void;
}

export const LearningCard: React.FC<LearningCardProps> = ({
  id,
  title,
  description,
  progress,
  difficulty,
  category,
  isCompleted = false,
  isPremium = false,
  onStart,
  onContinue,
}) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const difficultyColors = {
    beginner: 'bg-green-100 text-green-800',
    intermediate: 'bg-orange-100 text-orange-800',
    advanced: 'bg-red-100 text-red-800',
  };

  return (
    <div
      className={clsx(
        'bg-white rounded-xl border-2 border-gray-200 p-6 transition-all duration-300',
        'hover:border-blue-500 hover:shadow-lg',
        isHovered && 'shadow-lg'
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-bold text-gray-900 mb-1">{title}</h3>
          <p className="text-sm text-gray-600">{category}</p>
        </div>
        <button
          onClick={() => setIsFavorite(!isFavorite)}
          className="text-2xl transition-transform duration-200 hover:scale-110"
        >
          {isFavorite ? '⭐' : '☆'}
        </button>
      </div>

      {/* Description */}
      <p className="text-gray-700 text-sm mb-4">{description}</p>

      {/* Status Badges */}
      <div className="flex gap-2 mb-4">
        <StatusBadge
          status={isCompleted ? 'success' : 'info'}
          icon={isCompleted ? '✓' : '○'}
        >
          {isCompleted ? '완료' : '진행 중'}
        </StatusBadge>
        <div className={clsx('px-3 py-1 rounded-full text-sm font-medium', difficultyColors[difficulty])}>
          {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
        </div>
        {isPremium && (
          <StatusBadge status="premium" icon="👑">
            Premium
          </StatusBadge>
        )}
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-semibold text-gray-600">진행도</span>
          <span className="text-xs font-bold text-blue-600">{progress}%</span>
        </div>
        <ProgressBar value={progress} variant="primary" size="md" />
      </div>

      {/* Action Button */}
      <Button
        fullWidth
        variant={progress === 0 ? 'primary' : 'secondary'}
        onClick={progress === 0 ? onStart : onContinue}
      >
        {progress === 0 ? '시작하기' : '계속하기'}
      </Button>
    </div>
  );
};
```

## 5. QuizCard.tsx (기능 컴포넌트 2)

```jsx
import React, { useState } from 'react';
import clsx from 'clsx';
import { Button } from './Button';
import { StatusBadge } from './StatusBadge';

interface QuizOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

interface QuizCardProps {
  id: string;
  question: string;
  options: QuizOption[];
  hint?: string;
  onAnswer: (optionId: string, isCorrect: boolean) => void;
  disabled?: boolean;
}

export const QuizCard: React.FC<QuizCardProps> = ({
  id,
  question,
  options,
  hint,
  onAnswer,
  disabled = false,
}) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const handleSelect = (optionId: string) => {
    if (!isAnswered) {
      setSelectedOption(optionId);
    }
  };

  const handleSubmit = () => {
    if (selectedOption) {
      const selected = options.find((opt) => opt.id === selectedOption);
      if (selected) {
        onAnswer(selectedOption, selected.isCorrect);
        setIsAnswered(true);
      }
    }
  };

  const getSelectedCorrectness = () => {
    if (!selectedOption) return null;
    return options.find((opt) => opt.id === selectedOption)?.isCorrect ?? null;
  };

  const selectedCorrectness = getSelectedCorrectness();

  return (
    <div className="bg-white rounded-xl border-2 border-blue-200 p-8 max-w-2xl">
      {/* Question Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-3">{question}</h2>
        {hint && (
          <button
            onClick={() => setShowHint(!showHint)}
            className="text-sm text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
          >
            💡 {showHint ? '힌트 숨기기' : '힌트 보기'}
          </button>
        )}
      </div>

      {/* Hint */}
      {showHint && hint && (
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded">
          <p className="text-sm text-blue-900">{hint}</p>
        </div>
      )}

      {/* Options */}
      <div className="space-y-3 mb-6">
        {options.map((option) => {
          const isSelected = selectedOption === option.id;
          const isCorrectAnswer = option.isCorrect;
          const showCorrect =