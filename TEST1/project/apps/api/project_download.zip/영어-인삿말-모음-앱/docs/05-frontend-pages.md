# EnglishGreet - 주요 페이지 컴포넌트

```tsx
// src/pages/Home.tsx
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { BookOpen, Volume2, Brain, BarChart3, Zap, ArrowRight } from 'lucide-react';
import Button from '../components/common/Button/Button';
import Card from '../components/common/Card/Card';

export const Home: React.FC = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: BookOpen,
      title: '영어 표현 학습',
      description: '일상 인사말부터 비즈니스 표현까지 단계별로 학습하세요.',
      color: 'bg-blue-50',
      accentColor: 'text-blue-600',
      link: '/learn',
    },
    {
      icon: Volume2,
      title: '발음 연습',
      description: 'AI 음성 인식으로 정확한 발음을 실시간 피드백받으세요.',
      color: 'bg-orange-50',
      accentColor: 'text-orange-600',
      link: '/pronunciation',
    },
    {
      icon: Brain,
      title: '적응형 학습',
      description: '나의 학습 속도에 맞춰 개인화된 경로로 학습합니다.',
      color: 'bg-green-50',
      accentColor: 'text-green-600',
      link: '/adaptive',
    },
    {
      icon: BarChart3,
      title: '진행도 추적',
      description: '학습 통계와 성취도로 내 성장을 시각적으로 확인하세요.',
      color: 'bg-purple-50',
      accentColor: 'text-purple-600',
      link: '/dashboard',
    },
  ];

  const testimonials = [
    {
      content: '매일 10분씩 학습하니 3개월 만에 회의에서 자신감 있게 말할 수 있게 됐어요.',
      author: '김소연',
      role: '직장인',
      rating: 5,
    },
    {
      content: '발음 피드백이 정말 도움이 돼요. 반복 학습이 쉬워졌습니다.',
      author: '박준호',
      role: '학생',
      rating: 5,
    },
    {
      content: '좋아하는 주제로 표현을 배워서 더 재미있어요.',
      author: '이지은',
      role: '직장인',
      rating: 5,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <section className="pt-12 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 leading-tight">
                영어 인사말을
                <span className="block text-blue-600">자연스럽게</span>
              </h1>
              <p className="text-lg text-gray-600 leading-relaxed">
                AI 기반 발음 피드백과 적응형 학습으로 일상 영어 표현을 마스터하세요.
                매일 10분, 3개월이면 충분합니다.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                variant="primary"
                size="lg"
                onClick={() => navigate('/learn')}
                className="flex items-center justify-center gap-2"
              >
                지금 시작하기
                <ArrowRight size={20} />
              </Button>
              <Button
                variant="secondary"
                size="lg"
                onClick={() => navigate('/demo')}
              >
                데모 보기
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center gap-6 pt-8 border-t border-gray-200">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">50K+</p>
                <p className="text-sm text-gray-600">활성 학습자</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">95%</p>
                <p className="text-sm text-gray-600">만족도</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">4.8/5</p>
                <p className="text-sm text-gray-600">평점</p>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative w-full max-w-md">
              {/* Gradient Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-200 to-blue-100 rounded-3xl blur-3xl opacity-50" />

              {/* Phone Mockup */}
              <div className="relative bg-white rounded-3xl shadow-2xl overflow-hidden border-8 border-gray-900 aspect-video flex items-center justify-center">
                <div className="text-center space-y-4">
                  <Volume2 size={64} className="text-blue-600 mx-auto" />
                  <p className="text-xl font-semibold text-gray-900">
                    "How are you?"
                  </p>
                  <p className="text-sm text-gray-600">
                    발음 점수: 95점
                  </p>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '95%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              EnglishGreet의 강점
            </h2>
            <p className="text-lg text-gray-600">
              과학 기반의 학습 방법으로 빠르고 효과적인 영어 습득
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card
                  key={index}
                  className={`${feature.color} hover:shadow-lg transition-all duration-300 cursor-pointer`}
                  onClick={() => navigate(feature.link)}
                >
                  <div className="space-y-4">
                    <div className={`w-12 h-12 rounded-lg bg-white flex items-center justify-center ${feature.accentColor}`}>
                      <Icon size={24} />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 text-sm">
                      {feature.description}
                    </p>
                    <div className="flex items-center gap-2 text-blue-600 font-medium text-sm">
                      자세히 보기
                      <ArrowRight size={16} />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12">
          어떻게 작동하나요?
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              step: '1',
              title: '표현 선택',
              description: '학습할 상황과 난이도를 선택합니다.',
            },
            {
              step: '2',
              title: '발음 연습',
              description: 'AI와 함께 발음을 연습하고 피드백을 받습니다.',
            },
            {
              step: '3',
              title: '마스터하기',
              description: '반복 학습으로 완벽하게 습득합니다.',
            },
          ].map((item, index) => (
            <div key={index} className="relative">
              {/* Step Number */}
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 rounded-full bg-blue-600 text-white flex items-center justify-center text-2xl font-bold shadow-lg">
                  {item.step}
                </div>
                {index < 2 && (
                  <div className="absolute left-1/2 top-8 w-24 h-1 bg-blue-300 transform translate-y-full hidden md:block" />
                )}
              </div>

              {/* Content */}
              <div className="text-center space-y-2">
                <h3 className="text-xl font-semibold text-gray-900">
                  {item.title}
                </h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12">
            사용자 후기
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <div className="space-y-4">
                  {/* Rating */}
                  <div className="flex gap-1">
                    {Array(testimonial.rating).fill(0).map((_, i) => (
                      <span key={i} className="text-orange-400 text-lg">★</span>
                    ))}
                  </div>

                  {/* Content */}
                  <p className="text-gray-700 italic">"{testimonial.content}"</p>

                  {/* Author */}
                  <div className="pt-4 border-t border-gray-200">
                    <p className="font-semibold text-gray-900">
                      {testimonial.author}
                    </p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Footer Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-blue-700">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-4xl font-bold text-white">
            오늘 시작하세요
          </h2>
          <p className="text-xl text-blue-100">
            3개월 안에 영어 인사말을 자연스럽게 구사하세요.
            <br />
            지금 무료로 시작할 수 있습니다.
          </p>
          <Button
            variant="secondary"
            size="lg"
            onClick={() => navigate('/signup')}
            className="mx-auto"
          >
            무료 회원가입
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Home;
```

---

```tsx
// src/pages/Learn.tsx
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen,
  ChevronRight,
  Lock,
  CheckCircle,
  Circle,
  Filter,
  Search,
} from 'lucide-react';
import Button from '../components/common/Button/Button';
import Card from '../components/common/Card/Card';
import SearchInput from '../components/common/SearchInput/SearchInput';
import { useLessonStore } from '../store/useLessonStore';

export const Learn: React.FC = () => {
  const navigate = useNavigate();
  const { lessons, userProgress } = useLessonStore();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'progress' | 'difficulty'>('progress');

  const categories = ['all', 'greeting', 'business', 'casual', 'emergency'];
  const categoryLabels = {
    all: '전체',
    greeting: '기본 인사',
    business: '비즈니스',
    casual: '일상 회화',
    emergency: '긴급 상황',
  };

  const filteredLessons = useMemo(() => {
    let result = lessons;

    // Filter by category
    if (selectedCategory !== 'all') {
      result = result.filter((lesson) => lesson.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery) {
      result = result.filter(
        (lesson) =>
          lesson.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lesson.englishPhrase.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort
    if (sortBy === 'progress') {
      result.sort(
        (a, b) =>
          (userProgress[b.id]?.completionRate || 0) -
          (userProgress[a.id]?.completionRate || 0)
      );
    } else {
      result.sort((a, b) => a.difficulty - b.difficulty);
    }

    return result;
  }, [lessons, selectedCategory, searchQuery, sortBy, userProgress]);

  const getProgressColor = (rate: number)