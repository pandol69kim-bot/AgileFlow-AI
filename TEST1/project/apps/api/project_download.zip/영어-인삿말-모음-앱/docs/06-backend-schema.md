```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}

// ===========================
// 1. 사용자 관련 모델
// ===========================

model User {
  id                    String                  @id @default(cuid())
  email                 String                  @unique
  password              String
  displayName           String?
  profileImage          String?
  bio                   String?                 @db.Text
  nativeLanguage        String                  @default("ko") // 모국어
  learningLanguage      String                  @default("en") // 학습 언어
  proficiencyLevel      String                  @default("beginner") // beginner, intermediate, advanced
  isEmailVerified       Boolean                 @default(false)
  isActive              Boolean                 @default(true)
  lastLoginAt           DateTime?
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt
  deletedAt             DateTime?

  // 관계
  sessions              UserSession[]
  favorites             UserFavorite[]
  learningLogs          UserLearningLog[]
  subscriptions         UserSubscription[]
  onboardingSurvey      OnboardingSurvey?
  pushNotifications     PushNotification[]
  appEvents             AppEvent[]

  @@index([email])
  @@index([isActive])
  @@index([createdAt])
  @@index([proficiencyLevel])
}

model UserSession {
  id                    String                  @id @default(cuid())
  userId                String
  deviceType            String                  // web, ios, android
  deviceInfo            String?                 @db.Text
  ipAddress             String?
  userAgent             String?                 @db.Text
  accessToken           String?                 @db.Text
  refreshToken          String?                 @db.Text
  lastActivityAt        DateTime                @default(now())
  expiresAt             DateTime?
  isActive              Boolean                 @default(true)
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  user                  User                    @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@index([userId])
  @@index([isActive])
  @@index([lastActivityAt])
  @@index([expiresAt])
}

model UserSubscription {
  id                    String                  @id @default(cuid())
  userId                String
  planType              String                  // free, premium, pro
  status                String                  @default("active") // active, canceled, expired
  startDate             DateTime
  endDate               DateTime?
  autoRenewal           Boolean                 @default(true)
  canceledAt            DateTime?
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  user                  User                    @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([userId])
  @@index([status])
  @@index([endDate])
}

model OnboardingSurvey {
  id                    String                  @id @default(cuid())
  userId                String                  @unique
  learningGoal          String?                 // casual, business, academic
  dailyStudyTime        String?                 // 5min, 15min, 30min, 60min
  favoriteTopics        String?                 @db.Text // JSON array
  preferredLearningStyle String?                // audio, text, visual
  targetProficiency     String?                 // basic, fluent, native
  completedAt           DateTime
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  user                  User                    @relation(fields: [userId], references: [id], onDelete: Cascade)
}

// ===========================
// 2. 컨텐츠 관련 모델 (카테고리, 문구)
// ===========================

model Category {
  id                    String                  @id @default(cuid())
  name                  String                  @unique
  slug                  String                  @unique
  description           String?                 @db.Text
  icon                  String?
  displayOrder          Int                     @default(0)
  isActive              Boolean                 @default(true)
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  subCategories        SubCategory[]
  phrases               Phrase[]

  @@index([isActive])
  @@index([displayOrder])
}

model SubCategory {
  id                    String                  @id @default(cuid())
  categoryId            String
  name                  String
  slug                  String
  description           String?                 @db.Text
  icon                  String?
  displayOrder          Int                     @default(0)
  isActive              Boolean                 @default(true)
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  category              Category                @relation(fields: [categoryId], references: [id], onDelete: Cascade)
  phrases               Phrase[]

  @@unique([categoryId, slug])
  @@index([categoryId])
  @@index([isActive])
  @@index([displayOrder])
}

model Phrase {
  id                    String                  @id @default(cuid())
  categoryId            String
  subCategoryId         String?
  englishText           String                  @db.Text
  koreanTranslation     String                  @db.Text
  pronunciation         String?                 // 발음 (IPA)
  difficulty            String                  @default("beginner") // beginner, intermediate, advanced
  exampleSentence       String?                 @db.Text
  exampleTranslation    String?                 @db.Text
  tips                  String?                 @db.Text
  displayOrder          Int                     @default(0)
  viewCount             Int                     @default(0)
  likeCount             Int                     @default(0)
  isActive              Boolean                 @default(true)
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  category              Category                @relation(fields: [categoryId], references: [id], onDelete: Cascade)
  subCategory           SubCategory?            @relation(fields: [subCategoryId], references: [id], onDelete: SetNull)
  audioFiles            PhraseAudioFile[]
  favorites             UserFavorite[]
  learningLogs          UserLearningLog[]
  tags                  PhraseTag[]

  @@index([categoryId])
  @@index([subCategoryId])
  @@index([difficulty])
  @@index([isActive])
  @@index([displayOrder])
  @@index([createdAt])
}

model PhraseAudioFile {
  id                    String                  @id @default(cuid())
  phraseId              String
  audioUrl              String                  @db.Text
  audioFileSize        Int?                    // bytes
  duration              Float?                  // seconds
  speaker               String?                 // native, learning, etc
  audioType             String                  @default("native") // native, slow, emphasized
  language              String                  @default("en")
  createdAt             DateTime                @default(now())

  // 관계
  phrase                Phrase                  @relation(fields: [phraseId], references: [id], onDelete: Cascade)

  @@index([phraseId])
  @@index([audioType])
}

model Tag {
  id                    String                  @id @default(cuid())
  name                  String                  @unique
  slug                  String                  @unique
  color                 String?
  createdAt             DateTime                @default(now())

  // 관계
  phrases               PhraseTag[]

  @@index([slug])
}

model PhraseTag {
  id                    String                  @id @default(cuid())
  phraseId              String
  tagId                 String
  createdAt             DateTime                @default(now())

  // 관계
  phrase                Phrase                  @relation(fields: [phraseId], references: [id], onDelete: Cascade)
  tag                   Tag                     @relation(fields: [tagId], references: [id], onDelete: Cascade)

  @@unique([phraseId, tagId])
  @@index([phraseId])
  @@index([tagId])
}

// ===========================
// 3. 사용자 학습 관련 모델
// ===========================

model UserFavorite {
  id                    String                  @id @default(cuid())
  userId                String
  phraseId              String
  createdAt             DateTime                @default(now())

  // 관계
  user                  User                    @relation(fields: [userId], references: [id], onDelete: Cascade)
  phrase                Phrase                  @relation(fields: [phraseId], references: [id], onDelete: Cascade)

  @@unique([userId, phraseId])
  @@index([userId])
  @@index([phraseId])
  @@index([createdAt])
}

model UserLearningLog {
  id                    String                  @id @default(cuid())
  userId                String
  phraseId              String
  learningType          String                  // view, listen, repeat, quiz
  isCorrect             Boolean?
  duration              Int?                    // milliseconds
  attempts              Int                     @default(1)
  proficiencyScore      Int?                    // 0-100
  completedAt           DateTime?
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  // 관계
  user                  User                    @relation(fields: [userId], references: [id], onDelete: Cascade)
  phrase                Phrase                  @relation(fields: [phraseId], references: [id], onDelete: Cascade)

  @@index([userId])
  @@index([phraseId])
  @@index([learningType])
  @@index([createdAt])
  @@index([completedAt])
}

// ===========================
// 4. 알림 관련 모델
// ===========================

model PushNotification {
  id                    String                  @id @default(cuid())
  userId                String
  title                 String
  message               String                  @db.Text
  notificationType      String                  // daily_reminder, achievement, new_content, event
  relatedPhraseId       String?
  data                  String?                 @db.Text // JSON
  isRead                Boolean                 @default(false)
  sentAt                DateTime                @default(now())
  readAt                DateTime?
  createdAt             DateTime                @default(now())

  // 관계
  user                  User                    @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@index([userId])
  @@index([isRead])
  @@index([notificationType])
  @@index([sentAt])
}

// ===========================
// 5. 분석 & 로깅 모델
// ===========================

model AppEvent {
  id                    String                  @id @default(cuid())
  userId                String?
  eventType             String                  // page_view, button_click, form_submit, etc
  eventName             String
  category              String?                 // ui, learning, content, user
  action                String?
  label                 String?
  value                 String?
  sessionId             String?
  referrer              String?
  url                   String?                 @db.Text
  metadata              String?                 @db.Text // JSON
  createdAt             DateTime                @default(now())

  // 관계
  user                  User?                   @relation(fields: [userId], references: [id], onDelete: SetNull)

  @@index([userId])
  @@index([eventType])
  @@index([eventName])
  @@index([category])
  @@index([createdAt])
  @@index([sessionId])
}

// ===========================
// 6. 공지사항 & 콘텐츠 모델 (선택사항)
// ===========================

model Notice {
  id                    String                  @id @default(cuid())
  title                 String
  content               String                  @db.Text
  noticeType            String                  @default("general") // general, maintenance, promotion
  priority              Int                     @default(0)
  startDate             DateTime
  endDate               DateTime?
  isActive              Boolean                 @default(true)
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  @@index([isActive])
  @@index([startDate])
}

model Feedback {
  id                    String                  @id @default(cuid())
  userId                String?
  feedbackType          String                  // bug, suggestion, feature_request
  title                 String
  description           String                  @db.Text
  rating                Int?                    // 1-5
  attachments           String?                 @db.Text // JSON array of URLs
  status                String                  @default("submitted") // submitted, reviewed, in_progress, resolved
  response              String?                 @db.Text
  respondedAt           DateTime?
  createdAt             DateTime                @default(now())
  updatedAt             DateTime                @updatedAt

  @@index([userId])
  @@index([feedbackType])
  @@index([status])
  @@index([createdAt])
}
```

## 📌 스키마 주요 특징

### 1. **사용자 관리**
- `User`: 기본 사용자 정보
- `UserSession`: 다중 기기 세션 관리
- `UserSubscription`: 구독 상태 추적
- `OnboardingSurvey`: 온보딩 설문 (1:1 관계)

### 2. **컨텐츠 구조**
- `Category` → `SubCategory` → `Phrase` 계층 구조
- `Phrase`: 영문 표현, 한글 번역, 발음, 난이도 포함
- `PhraseAudioFile`: 다양한 음성 파일 지원
- `Tag` & `PhraseTag`: 다대다 관계

### 3. **학습 추적**
- `UserFavorite`: 사용자 즐겨찾기
- `UserLearningLog`: 학습 이력 추적 (정답/오답, 소요시간, 점수)

### 4. **알림 & 분석**
- `PushNotification`: 푸시 알림 이력
- `AppEvent`: GA 같은 행동 분석 로깅

### 5. **인덱싱 전략**
- 조회가 빈번한 컬럼: `userId`, `phraseId`, `createdAt`
- 필터링: `isActive`, `status`, `difficulty`, `learningType`
- 성능 최적화: 복합 인덱스 가능 (예: `userId` + `createdAt`)