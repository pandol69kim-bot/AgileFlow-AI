# EnglishGreet 백엔드 Vitest 단위/통합 테스트 코드

## 프로젝트 구조 및 설정

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    setupFiles: ['./src/test/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: ['node_modules/', 'dist/', '**/*.d.ts'],
      thresholds: {
        global: {
          branches: 80,
          functions: 80,
          lines: 80,
          statements: 80,
        },
      },
    },
    testTimeout: 10000,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
```

```typescript
// src/test/setup.ts
import { beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import { db } from '@/database/connection';
import { redis } from '@/cache/redis';

beforeAll(async () => {
  await db.migrate.latest();
});

afterAll(async () => {
  await db.destroy();
  await redis.quit();
});

beforeEach(async () => {
  await db.seed.run({ specific: 'test_seed.ts' });
});

afterEach(async () => {
  await db('phrases').truncate();
  await db('users').truncate();
  await db('favorites').truncate();
  await db('categories').truncate();
  await redis.flushdb();
});
```

---

## 1. 타입 정의

```typescript
// src/types/index.ts
export interface User {
  id: string;
  email: string;
  passwordHash: string;
  isPremium: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  isPremium: boolean;
}

export interface Phrase {
  id: string;
  categoryId: string;
  english: string;
  korean: string;
  pronunciation: string;
  audioUrl: string | null;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  isPremium: boolean;
  playCount: number;
  createdAt: Date;
}

export interface Favorite {
  id: string;
  userId: string;
  phraseId: string;
  createdAt: Date;
}

export interface PaginationOptions {
  page: number;
  limit: number;
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface SearchOptions extends PaginationOptions {
  query: string;
  categoryId?: string;
  difficulty?: string;
  isPremium?: boolean;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}
```

---

## 2. 서비스 레이어

```typescript
// src/services/phrase.service.ts
import { db } from '@/database/connection';
import { redis } from '@/cache/redis';
import type { Phrase, PaginatedResult, SearchOptions, PaginationOptions } from '@/types';

export class PhraseService {
  private readonly CACHE_TTL = 300; // 5분
  private readonly CACHE_PREFIX = 'phrase:';

  async findById(id: string): Promise<Phrase | null> {
    const cacheKey = `${this.CACHE_PREFIX}${id}`;
    const cached = await redis.get(cacheKey);

    if (cached) {
      return JSON.parse(cached) as Phrase;
    }

    const phrase = await db<Phrase>('phrases')
      .where({ id })
      .first();

    if (phrase) {
      await redis.setex(cacheKey, this.CACHE_TTL, JSON.stringify(phrase));
    }

    return phrase ?? null;
  }

  async findByCategory(
    categoryId: string,
    options: PaginationOptions,
    isPremiumUser: boolean = false
  ): Promise<PaginatedResult<Phrase>> {
    const { page, limit } = options;
    const offset = (page - 1) * limit;

    const query = db<Phrase>('phrases').where({ categoryId });

    if (!isPremiumUser) {
      query.where({ isPremium: false });
    }

    const [{ count }] = await query.clone().count('id as count');
    const total = Number(count);

    const data = await query
      .offset(offset)
      .limit(limit)
      .orderBy('createdAt', 'desc');

    return {
      data,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrev: page > 1,
    };
  }

  async search(options: SearchOptions, isPremiumUser: boolean = false): Promise<PaginatedResult<Phrase>> {
    const { query, categoryId, difficulty, page, limit } = options;
    const offset = (page - 1) * limit;

    const dbQuery = db<Phrase>('phrases')
      .where((builder) => {
        builder
          .whereILike('english', `%${query}%`)
          .orWhereILike('korean', `%${query}%`);
      });

    if (categoryId) dbQuery.where({ categoryId });
    if (difficulty) dbQuery.where({ difficulty });
    if (!isPremiumUser) dbQuery.where({ isPremium: false });

    const [{ count }] = await dbQuery.clone().count('id as count');
    const total = Number(count);

    const data = await dbQuery
      .offset(offset)
      .limit(limit)
      .orderBy('playCount', 'desc');

    return {
      data,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrev: page > 1,
    };
  }

  async incrementPlayCount(id: string): Promise<void> {
    const phrase = await this.findById(id);
    if (!phrase) {
      throw new Error('Phrase not found');
    }

    await db<Phrase>('phrases').where({ id }).increment('playCount', 1);

    // 캐시 무효화
    await redis.del(`${this.CACHE_PREFIX}${id}`);
  }

  async create(data: Omit<Phrase, 'id' | 'playCount' | 'createdAt'>): Promise<Phrase> {
    const [phrase] = await db<Phrase>('phrases')
      .insert({
        ...data,
        playCount: 0,
      })
      .returning('*');

    return phrase;
  }
}
```

```typescript
// src/services/favorite.service.ts
import { db } from '@/database/connection';
import type { Favorite, Phrase, PaginatedResult, PaginationOptions } from '@/types';

export class FavoriteService {
  async toggle(userId: string, phraseId: string): Promise<{ action: 'added' | 'removed'; favorite?: Favorite }> {
    const existing = await db<Favorite>('favorites')
      .where({ userId, phraseId })
      .first();

    if (existing) {
      await db<Favorite>('favorites').where({ id: existing.id }).delete();
      return { action: 'removed' };
    }

    const [favorite] = await db<Favorite>('favorites')
      .insert({ userId, phraseId })
      .returning('*');

    return { action: 'added', favorite };
  }

  async getUserFavorites(
    userId: string,
    options: PaginationOptions
  ): Promise<PaginatedResult<Phrase>> {
    const { page, limit } = options;
    const offset = (page - 1) * limit;

    const baseQuery = db('favorites')
      .join('phrases', 'favorites.phraseId', 'phrases.id')
      .where('favorites.userId', userId);

    const [{ count }] = await baseQuery.clone().count('favorites.id as count');
    const total = Number(count);

    const data = await baseQuery
      .select('phrases.*')
      .offset(offset)
      .limit(limit)
      .orderBy('favorites.createdAt', 'desc');

    return {
      data,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrev: page > 1,
    };
  }

  async countByUser(userId: string): Promise<number> {
    const [{ count }] = await db('favorites')
      .where({ userId })
      .count('id as count');
    return Number(count);
  }

  async isFavorited(userId: string, phraseId: string): Promise<boolean> {
    const result = await db<Favorite>('favorites')
      .where({ userId, phraseId })
      .first();
    return !!result;
  }
}
```

```typescript
// src/services/auth.service.ts
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { db } from '@/database/connection';
import { redis } from '@/cache/redis';
import type { User, AuthTokens } from '@/types';

export class AuthService {
  private readonly SALT_ROUNDS = 12;
  private readonly ACCESS_TOKEN_EXPIRY = '1h';
  private readonly REFRESH_TOKEN_EXPIRY = '30d';
  private readonly REFRESH_TOKEN_PREFIX = 'refresh:';

  async register(email: string, password: string): Promise<User> {
    const existing = await db<User>('users').where({ email }).first();
    if (existing) {
      throw new Error('Email already exists');
    }

    this.validatePassword(password);

    const passwordHash = await bcrypt.hash(password, this.SALT_ROUNDS);
    const [user] = await db<User>('users')
      .insert({ email, passwordHash, isPremium: false })
      .returning('*');

    return user;
  }

  async login(email: string, password: string): Promise<AuthTokens> {
    const user = await db<User>('users').where({ email }).first();
    if (!user) {
      throw new Error('Invalid credentials');
    }

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) {
      throw new Error('Invalid credentials');
    }

    return this.generateTokens(user);
  }

  async refreshToken(token: string): Promise<AuthTokens> {
    const cacheKey = `${this.REFRESH_TOKEN_PREFIX}${token}`;
    const userId = await redis.get(cacheKey);

    if (!userId) {
      throw new Error('Invalid or expired refresh token');
    }

    const user = await db<User>('users').where({ id: userId }).first();
    if (!user) {
      throw new Error('User not found');
    }

    await redis.del(cacheKey);
    return this.generateTokens(user);
  }

  async logout(refreshToken: string): Promise<void> {
    await redis.del(`${this.REFRESH_TOKEN_PREFIX}${refreshToken}`);
  }

  private validatePassword(password: string): void {
    if (password.length < 8) {
      throw new Error('Password must be at least 8 characters');
    }
    if (!/[A-Z]/.test(password)) {
      throw new Error('Password must contain at least one uppercase letter');
    }
    if (!/[0-9]/.test(password)) {
      throw new Error('Password must contain at least one number');
    }
  }

  private async generateTokens(user: User): Promise<AuthTokens> {
    const payload = { sub: user.id, email: user.email, isPremium: user.isPremium };
    const secret = process.env.JWT_SECRET!;

    const accessToken = jwt.sign(payload, secret, {
      expiresIn: this.ACCESS_TOKEN_EXPIRY,
    });

    const refreshToken = jwt.sign({ sub: user.id }, secret, {
      expiresIn: this.REFRESH_TOKEN_EXPIRY,
    });

    await redis.setex(
      `${this.REFRESH_TOKEN_PREFIX}${refreshToken}`,
      30 * 24 * 60 * 60,
      user.id
    );

    return { accessToken, refreshToken, expiresIn: 3600 };
  }
}
```

---

## 3. 단위 테스트 - PhraseService

```typescript
// src/services/__tests__/phrase.service.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { PhraseService } from '@/services/phrase.service';
import { db } from '@/database/connection';
import { redis } from '@/cache/redis';
import type { Phrase } from '@/types';

// ── Mock 설정 ──────────────────────────────────────────────
vi.mock('@/database/connection', () => ({
  db: vi.fn(),
}));

vi.mock('@/cache/redis', () => ({
  redis: {
    get: vi.fn(),
    setex: vi.fn(),
    del: vi.fn(),
  },
}));

// ── 테스트 픽스처 ──────────────────────────────────────────
const mockPhrase: Phrase = {
  id: 'phrase-uuid-001',
  categoryId: 'cat-uuid-001',
  english: 'Nice to meet you',
  korean: '만나서 반갑습니다',
  pronunciation: 'nais tə miːt juː',
  audioUrl: 'https://cdn.englishgreet.com/audio/nice-to-meet-you.mp3',
  difficulty: 'beginner',
  isPremium: false,
  playCount: 42,
  createdAt: new Date('2025-01-01T00:00:00Z'),
};

const mockPremiumPhrase: Phrase = {
  ...mockPhrase,
  id: 'phrase-uuid-002',
  english: 'Pleased to make your acquaintance',
  korean: '뵙게 되어 영광입니다',
  isPremium: true,
  difficulty: 'advanced',
};

// ── 헬퍼: Knex 체이닝 Mock 생성 ───────────────────────────
const createQueryBuilderMock = (returnValue: unknown) => {
  const mock = {
    where: vi.fn().mockReturnThis(),
    whereILike: vi.fn().mockReturnThis(),
    orWhereILike: vi.fn().mockReturnThis(),
    offset: vi.fn().mockReturnThis(),
    limit: vi.fn().mockReturnThis(),
    orderBy: vi.fn().mockReturnThis(),
    increment: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    clone: vi.fn().mockReturnThis(),
    count: vi.fn().mockResolvedValue([{ count: '1' }]),
    first: vi.fn().mockResolvedValue(returnValue),
    returning: vi.fn().mockResolvedValue([returnValue]),
  };
  return mock;
};

// ─────────────────────────────────────────────────────────
describe('PhraseService', () => {
  let phraseService: Phrase