# GitHub Actions CI/CD 워크플로우

EnglishGreet 프로젝트의 기술스택과 아키텍처를 기반으로 완전한 CI/CD 파이프라인을 작성합니다.

## 📁 디렉토리 구조
```
.github/
├── workflows/
│   ├── frontend-ci-cd.yml          # 프론트엔드 (React Native/Web)
│   ├── backend-ci-cd.yml           # 백엔드 (Node.js)
│   └── deploy.yml                  # 통합 배포
└── scripts/
    ├── lint.sh
    ├── test.sh
    └── build.sh
```

---

## 1️⃣ 백엔드 CI/CD 워크플로우

### `.github/workflows/backend-ci-cd.yml`

```yaml
name: Backend CI/CD Pipeline

on:
  push:
    branches: [main, develop]
    paths:
      - 'backend/**'
      - '.github/workflows/backend-ci-cd.yml'
  pull_request:
    branches: [develop, main]
    paths:
      - 'backend/**'

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}/backend
  NODE_VERSION: '18.x'

jobs:
  # ========== STAGE 1: LINT ==========
  lint:
    name: 📝 Lint & Code Quality
    runs-on: ubuntu-latest
    
    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔧 Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
          cache-dependency-path: 'backend/package-lock.json'

      - name: 📦 Install dependencies
        working-directory: ./backend
        run: npm ci

      - name: 🔍 Run ESLint
        working-directory: ./backend
        run: npm run lint
        continue-on-error: false

      - name: 🎨 Run Prettier
        working-directory: ./backend
        run: npm run format:check
        continue-on-error: false

      - name: 🔐 Security check (npm audit)
        working-directory: ./backend
        run: npm audit --audit-level=moderate
        continue-on-error: true

      - name: 📊 SAST with SonarCloud
        uses: SonarSource/sonarcloud-github-action@master
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}
        with:
          args: >
            -Dsonar.projectKey=englishgreet-backend
            -Dsonar.sources=backend/src

  # ========== STAGE 2: TEST ==========
  test:
    name: 🧪 Unit & Integration Tests
    runs-on: ubuntu-latest
    needs: lint
    
    services:
      postgres:
        image: postgres:15-alpine
        env:
          POSTGRES_USER: test_user
          POSTGRES_PASSWORD: test_password
          POSTGRES_DB: englishgreet_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

      redis:
        image: redis:7-alpine
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 6379:6379

    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔧 Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
          cache-dependency-path: 'backend/package-lock.json'

      - name: 📦 Install dependencies
        working-directory: ./backend
        run: npm ci

      - name: 🗄️ Setup test database
        working-directory: ./backend
        env:
          DATABASE_URL: postgresql://test_user:test_password@localhost:5432/englishgreet_test
        run: npm run db:migrate:test

      - name: 🧪 Run unit tests
        working-directory: ./backend
        run: npm run test:unit -- --coverage
        env:
          NODE_ENV: test

      - name: 🔗 Run integration tests
        working-directory: ./backend
        run: npm run test:integration
        env:
          NODE_ENV: test
          DATABASE_URL: postgresql://test_user:test_password@localhost:5432/englishgreet_test
          REDIS_URL: redis://localhost:6379

      - name: 📈 Upload coverage to Codecov
        uses: codecov/codecov-action@v3
        with:
          files: ./backend/coverage/lcov.info
          flags: backend
          name: backend-coverage

      - name: 📊 Comment PR with coverage
        if: github.event_name == 'pull_request'
        uses: romeovs/lcov-reporter-action@v0.3.1
        with:
          github-token: ${{ secrets.GITHUB_TOKEN }}
          lcov-file: ./backend/coverage/lcov.info

  # ========== STAGE 3: BUILD ==========
  build:
    name: 🔨 Build & Docker Image
    runs-on: ubuntu-latest
    needs: test
    
    permissions:
      contents: read
      packages: write

    outputs:
      image-tag: ${{ steps.meta.outputs.tags }}
      image-digest: ${{ steps.build.outputs.digest }}

    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔧 Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
          cache-dependency-path: 'backend/package-lock.json'

      - name: 📦 Install dependencies
        working-directory: ./backend
        run: npm ci

      - name: 🔨 Build application
        working-directory: ./backend
        run: npm run build
        env:
          NODE_ENV: production

      - name: 🔐 Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: 🔑 Log in to Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: 📝 Extract metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}
          tags: |
            type=ref,event=branch
            type=semver,pattern={{version}}
            type=semver,pattern={{major}}.{{minor}}
            type=sha,prefix={{branch}}-
            type=raw,value=latest,enable={{is_default_branch}}

      - name: 🐳 Build and push Docker image
        id: build
        uses: docker/build-push-action@v5
        with:
          context: ./backend
          push: ${{ github.event_name != 'pull_request' }}
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}
          cache-from: type=registry,ref=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:buildcache
          cache-to: type=registry,ref=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:buildcache,mode=max

  # ========== STAGE 4: DEPLOY ==========
  deploy:
    name: 🚀 Deploy to Staging/Production
    runs-on: ubuntu-latest
    needs: build
    
    if: github.event_name == 'push'
    
    environment:
      name: ${{ github.ref == 'refs/heads/main' && 'production' || 'staging' }}
      url: ${{ steps.deploy.outputs.deployment-url }}

    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔐 Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_TO_ASSUME }}
          aws-region: ap-northeast-2

      - name: 📝 Update ECS task definition
        id: task-def
        uses: aws-actions/amazon-ecs-render-task-definition@v1
        with:
          task-definition: ./infra/ecs/backend-task-def.json
          container-name: backend
          image: ${{ needs.build.outputs.image-tag }}

      - name: 🚀 Deploy to ECS
        id: deploy
        uses: aws-actions/amazon-ecs-deploy-task-definition@v1
        with:
          task-definition: ${{ steps.task-def.outputs.task-definition }}
          service: englishgreet-backend-${{ github.ref == 'refs/heads/main' && 'prod' || 'staging' }}
          cluster: englishgreet-cluster
          wait-for-service-stability: true

      - name: 🔗 Get deployment URL
        run: |
          LOAD_BALANCER=$(aws elbv2 describe-load-balancers \
            --query "LoadBalancers[?contains(LoadBalancerName, 'backend-${{ github.ref == 'refs/heads/main' && 'prod' || 'staging' }}')] | [0].DNSName" \
            --output text)
          echo "deployment-url=https://$LOAD_BALANCER" >> $GITHUB_OUTPUT

      - name: 🏥 Health check
        run: |
          MAX_ATTEMPTS=30
          ATTEMPT=0
          while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
            HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" ${{ steps.deploy.outputs.deployment-url }}/health)
            if [ "$HTTP_CODE" = "200" ]; then
              echo "✅ Service is healthy"
              exit 0
            fi
            ATTEMPT=$((ATTEMPT+1))
            sleep 10
          done
          echo "❌ Health check failed"
          exit 1

      - name: 📢 Slack notification
        if: always()
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          text: |
            Backend Deploy ${{ job.status }}
            Environment: ${{ github.ref == 'refs/heads/main' && 'Production' || 'Staging' }}
            Commit: ${{ github.sha }}
            Author: ${{ github.actor }}
            URL: ${{ steps.deploy.outputs.deployment-url }}
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}
          fields: repo,message,commit,author
```

---

## 2️⃣ 프론트엔드 CI/CD 워크플로우

### `.github/workflows/frontend-ci-cd.yml`

```yaml
name: Frontend CI/CD Pipeline

on:
  push:
    branches: [main, develop]
    paths:
      - 'frontend/**'
      - '.github/workflows/frontend-ci-cd.yml'
  pull_request:
    branches: [develop, main]
    paths:
      - 'frontend/**'

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}/frontend
  NODE_VERSION: '18.x'

jobs:
  # ========== STAGE 1: LINT ==========
  lint:
    name: 📝 Lint & Code Quality
    runs-on: ubuntu-latest
    
    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔧 Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
          cache-dependency-path: 'frontend/package-lock.json'

      - name: 📦 Install dependencies
        working-directory: ./frontend
        run: npm ci

      - name: 🔍 Run ESLint
        working-directory: ./frontend
        run: npm run lint
        continue-on-error: false

      - name: 🎨 Run Prettier
        working-directory: ./frontend
        run: npm run format:check
        continue-on-error: false

      - name: 📦 TypeScript type checking
        working-directory: ./frontend
        run: npm run type-check

  # ========== STAGE 2: TEST ==========
  test:
    name: 🧪 Unit & Integration Tests
    runs-on: ubuntu-latest
    needs: lint
    
    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔧 Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
          cache-dependency-path: 'frontend/package-lock.json'

      - name: 📦 Install dependencies
        working-directory: ./frontend
        run: npm ci

      - name: 🧪 Run unit tests
        working-directory: ./frontend
        run: npm run test:unit -- --coverage
        env:
          CI: true

      - name: 🧪 Run integration tests
        working-directory: ./frontend
        run: npm run test:integration
        env:
          CI: true

      - name: 📈 Upload coverage
        uses: codecov/codecov-action@v3
        with:
          files: ./frontend/coverage/lcov.info
          flags: frontend

      - name: 🎥 E2E Tests (Cypress)
        uses: cypress-io/github-action@v6
        with:
          working-directory: frontend
          start: npm run dev
          wait-on: 'http://localhost:3000'
          wait-on-timeout: 120
          browser: chrome
          spec: cypress/e2e/**/*.cy.ts

      - name: 📤 Upload Cypress videos
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: cypress-videos
          path: frontend/cypress/videos

  # ========== STAGE 3: BUILD ==========
  build:
    name: 🔨 Build & Docker Image
    runs-on: ubuntu-latest
    needs: test
    
    permissions:
      contents: read
      packages: write

    outputs:
      image-tag: ${{ steps.meta.outputs.tags }}

    steps:
      - name: 📥 Checkout code
        uses: actions/checkout@v4

      - name: 🔧 Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
          cache-dependency-path: 'frontend/package-lock.json'

      - name: 📦 Install dependencies
        working-directory: ./frontend
        run: npm ci

      - name: 🔨 Build application
        working-directory: ./frontend
        run: npm run build
        env:
          REACT_APP_API_URL: ${{ secrets.REACT_APP_API_URL }}
          REACT_APP_ENV: ${{ github.ref == 'refs/heads/main' && 'production' || 'staging' }}

      