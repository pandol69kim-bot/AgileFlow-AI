# EnglishGreet 코드 리뷰 체크리스트

## 📋 문서 정보

| 항목 | 내용 |
|------|------|
| **버전** | v1.0 |
| **기반 문서** | EnglishGreet PRD v1.0 |
| **적용 범위** | Frontend(Flutter/React Native), Backend(API), DB |
| **필수 승인자** | Tech Lead, Security Engineer |
| **업데이트** | 2025년 1월 |

---

## 🔴 BLOCKER (머지 불가 — 즉시 수정 필수)

> 하나라도 해당되면 PR 승인 불가. 수정 후 재검토 요청 필수.

---

## 1. 🔒 보안 (Security)

### 1.1 인증 & 인가

```
PRD 근거: Freemium 수익 모델 → 무료/프리미엄 권한 분리 필수
```

#### BLOCKER ❌

- [ ] JWT/토큰 **만료 시간 미설정** 또는 무기한 토큰 사용
- [ ] 프리미엄 전용 API 엔드포인트에 **인가 검증 없음**
- [ ] 비밀번호를 **평문(Plain Text)** 으로 저장
- [ ] 하드코딩된 API Key, Secret, DB 패스워드 존재
    ```python
    # ❌ 절대 금지
    API_KEY = "sk-1234567890abcdef"
    DB_PASSWORD = "admin123"
    
    # ✅ 올바른 방식
    API_KEY = os.environ.get("API_KEY")
    DB_PASSWORD = os.environ.get("DB_PASSWORD")
    ```

#### WARNING ⚠️

- [ ] 토큰 갱신(Refresh Token) 로직에 **재사용 방지** 처리 여부
- [ ] 로그아웃 시 **서버측 토큰 무효화** 처리 여부
- [ ] 소셜 로그인(Google/Apple) **State 파라미터** CSRF 방어 여부
- [ ] 권한 검증 로직이 **클라이언트 단에만** 존재하는지 확인

```
✅ 체크 기준:
  - 무료 사용자가 프리미엄 음성 API 직접 호출 시 → 403 반환 확인
  - 만료 토큰으로 요청 시 → 401 반환 + 클라이언트 재로그인 유도 확인
```

---

### 1.2 입력값 검증 & 인젝션 방어

```
PRD 근거: 검색 기능, 즐겨찾기 저장 → 사용자 입력 처리 필수
```

#### BLOCKER ❌

- [ ] SQL 쿼리에 **사용자 입력값 직접 삽입** (SQL Injection)
    ```python
    # ❌ 절대 금지
    query = f"SELECT * FROM expressions WHERE keyword = '{user_input}'"
    
    # ✅ Parameterized Query 사용
    query = "SELECT * FROM expressions WHERE keyword = %s"
    cursor.execute(query, (user_input,))
    ```
- [ ] XSS 방어 없이 사용자 입력값 **DOM에 직접 렌더링**
- [ ] 파일 업로드 시 **확장자/MIME 타입 검증 없음**

#### WARNING ⚠️

- [ ] 검색 입력값 **길이 제한** 미설정 (권장: 100자 이내)
- [ ] API 요청 Body **Schema 검증** (필수 필드, 타입 체크) 여부
- [ ] 특수문자 입력 시 **예외 처리** 존재 여부

```
✅ 체크 기준:
  - 검색창에 <script>alert(1)</script> 입력 → 스크립트 미실행 확인
  - SQL 특수문자(' " ; --) 입력 → 쿼리 오류 미발생 확인
  - 빈 문자열/null 입력 → 적절한 에러 메시지 반환 확인
```

---

### 1.3 데이터 보호

```
PRD 근거: 학습 이력, 즐겨찾기, 사용자 정보 저장 → 개인정보 보호 필수
```

#### BLOCKER ❌

- [ ] 사용자 PII(이메일, 이름 등) **암호화 없이** DB 저장
- [ ] HTTPS 미적용 환경에서 **민감 데이터 전송**
- [ ] 로그에 **비밀번호, 토큰, 개인정보** 출력

#### WARNING ⚠️

- [ ] 음성 파일 URL이 **인증 없이 직접 접근** 가능한지 여부
    ```
    예시: https://cdn.englishgreet.com/audio/premium_001.mp3
    → 로그인 없이 URL 직접 접근 가능한지 확인
    ```
- [ ] 회원 탈퇴 시 **개인정보 완전 삭제** 처리 여부 (GDPR/개인정보보호법)
- [ ] 앱 로컬 스토리지에 **민감 정보 비암호화 저장** 여부

```
✅ 체크 기준:
  - DB 직접 조회 시 이메일 컬럼 → 마스킹 또는 암호화 확인
  - Charles Proxy로 트래픽 캡처 → 민감 데이터 평문 전송 없음 확인
  - 로그 파일 → 개인식별 정보 미포함 확인
```

---

### 1.4 Rate Limiting & 보안 헤더

```
PRD 근거: MAU 10,000명 목표, 음성 API 남용 방지 필요
```

#### WARNING ⚠️

- [ ] 음성 재생 API에 **Rate Limit** 설정 여부
    ```
    권장 설정:
      - 무료 사용자: 분당 10회 / 일 50회
      - 프리미엄 사용자: 분당 60회
    ```
- [ ] API 응답 헤더에 **보안 헤더** 포함 여부
    ```http
    ✅ 필수 보안 헤더:
    X-Content-Type-Options: nosniff
    X-Frame-Options: DENY
    Content-Security-Policy: default-src 'self'
    Strict-Transport-Security: max-age=31536000
    ```
- [ ] 로그인 실패 횟수 **제한 및 잠금** 로직 여부 (권장: 5회 실패 시 잠금)

---

## 2. ⚡ 성능 (Performance)

### 2.1 응답 속도

```
PRD 근거:
  - "5초 안에 표현 찾기" 제품 비전
  - 첫 음성 재생까지 60초 → 30초 이내 목표
  - 세션당 평균 표현 조회 8개 이상 목표
```

#### BLOCKER ❌

- [ ] 메인 화면 로딩 시 **N+1 쿼리 발생** (표현 목록 조회)
    ```python
    # ❌ N+1 문제
    expressions = Expression.objects.all()
    for expr in expressions:
        category = expr.category  # 매번 추가 쿼리 발생
    
    # ✅ 즉시 로딩
    expressions = Expression.objects.select_related('category').all()
    ```
- [ ] 음성 파일 **동기(Sync) 방식** 다운로드로 UI 블로킹

#### WARNING ⚠️

- [ ] 표현 목록 API 응답 시간 **500ms 초과** 여부
- [ ] 음성 파일 **CDN 미적용** (직접 서버 서빙)
- [ ] 검색 쿼리에 **인덱스 미설정** 여부
    ```sql
    -- ✅ 검색 성능을 위한 인덱스 확인
    EXPLAIN SELECT * FROM expressions WHERE keyword LIKE '%hello%';
    -- Full Table Scan 발생 시 → Full-text Index 적용 필요
    ```
- [ ] 페이지네이션 없이 **전체 데이터 일괄 조회**

```
✅ 성능 기준표:
  
  | API | 목표 응답시간 | 최대 허용 |
  |-----|-------------|---------|
  | 표현 목록 조회 | 200ms | 500ms |
  | 음성 파일 URL 발급 | 100ms | 300ms |
  | 검색 결과 반환 | 300ms | 800ms |
  | 즐겨찾기 저장 | 150ms | 400ms |
  | 온보딩 완료 처리 | 200ms | 500ms |
```

---

### 2.2 캐싱 전략

```
PRD 근거: 세션당 평균 8개 표현 조회 → 중복 요청 최소화 필요
```

#### WARNING ⚠️

- [ ] 자주 조회되는 **카테고리/표현 목록 캐싱** 적용 여부
    ```python
    # ✅ Redis 캐싱 예시
    CACHE_TTL = {
        'expression_list': 3600,    # 1시간 (자주 안 바뀜)
        'category_list': 86400,     # 24시간
        'user_favorites': 300,      # 5분 (자주 바뀜)
        'audio_url': 1800,          # 30분
    }
    ```
- [ ] 캐시 **무효화(Invalidation) 전략** 존재 여부
- [ ] 음성 파일에 **브라우저 캐싱 헤더** 설정 여부
    ```http
    Cache-Control: public, max-age=86400
    ETag: "audio-file-hash"
    ```
- [ ] 동일 사용자의 중복 음성 재생 요청 **클라이언트 캐싱** 여부

---

### 2.3 앱/프론트엔드 성능

```
PRD 근거: 온보딩 완료율 80% 목표 → 초기 로딩 속도 중요
```

#### WARNING ⚠️

- [ ] 앱 초기 번들 사이즈 **불필요한 라이브러리 포함** 여부
- [ ] 이미지 리소스 **최적화(WebP, 압축)** 적용 여부
- [ ] 음성 파일 **프리로딩(Preload)** 전략 적용 여부
    ```javascript
    // ✅ 다음 표현 음성 미리 로드
    const preloadAudio = (url) => {
        const audio = new Audio();
        audio.preload = 'auto';
        audio.src = url;
    };
    ```
- [ ] **Lazy Loading** 미적용으로 불필요한 컴포넌트 초기 로드
- [ ] 리스트 렌더링 시 **가상화(Virtualization)** 적용 여부 (표현 목록 100개+)

---

### 2.4 데이터베이스 성능

#### WARNING ⚠️

- [ ] 자주 사용되는 쿼리 **실행 계획(EXPLAIN) 검토** 여부
- [ ] **인덱스 과다 생성** (쓰기 성능 저하 가능성)
- [ ] 즐겨찾기 통계 집계를 **실시간 COUNT 쿼리** 처리 여부
    ```sql
    -- ❌ 매 요청마다 COUNT 실행
    SELECT COUNT(*) FROM favorites WHERE user_id = ?
    
    -- ✅ 별도 카운터 컬럼 또는 캐시 활용
    SELECT favorites_count FROM user_stats WHERE user_id = ?
    ```

---

## 3. 🏗️ 코드 품질 (Code Quality)

### 3.1 코드 구조 & 가독성

#### BLOCKER ❌

- [ ] 단일 함수/메서드가 **50줄 초과** (단일 책임 원칙 위반)
- [ ] **중복 코드** 3회 이상 복사 (DRY 원칙 위반)
    ```python
    # ❌ 중복 코드
    def get_free_expressions():
        return db.query("SELECT * FROM expressions WHERE tier = 'free'")
    
    def get_premium_expressions():
        return db.query("SELECT * FROM expressions WHERE tier = 'premium'")
    
    # ✅ 파라미터화
    def get_expressions_by_tier(tier: str):
        return db.query("SELECT * FROM expressions WHERE tier = %s", (tier,))
    ```
- [ ] 매직 넘버/매직 스트링 **상수화 없이** 사용
    ```python
    # ❌ 매직 넘버
    if user.plan == 2:          # 2가 무엇인지 불명확
        allow_limit = 999999
    
    # ✅ 상수 사용
    PREMIUM_PLAN_ID = 2
    UNLIMITED = 999999
    if user.plan == PREMIUM_PLAN_ID:
        allow_limit = UNLIMITED
    ```

#### WARNING ⚠️

- [ ] 함수/변수명이 **역할을 명확히 설명**하는지 여부
    ```python
    # ❌ 불명확한 네이밍
    def proc(d, t):
        return d if t == 1 else []
    
    # ✅ 명확한 네이밍
    def filter_expressions_by_tier(expressions, user_tier):
        return expressions if user_tier == PREMIUM_PLAN_ID else []
    ```
- [ ] **주석 없는 복잡한