# Vite+React+Tailwind CSS 프론트엔드 초기 설정 가이드

## 📋 목차
1. [프로젝트 생성](#1-프로젝트-생성)
2. [필수 패키지 설치](#2-필수-패키지-설치)
3. [Tailwind CSS 설정](#3-tailwind-css-설정)
4. [환경변수 설정](#4-환경변수-설정)
5. [디자인 시스템 적용](#5-디자인-시스템-적용)
6. [폴더 구조 생성](#6-폴더-구조-생성)
7. [검증 및 테스트](#7-검증-및-테스트)

---

## 1. 프로젝트 생성

### 1.1 Vite React 프로젝트 초기화

```bash
# Node.js 16.0.0 이상 필요
node --version

# Vite로 React 프로젝트 생성
npm create vite@latest web -- --template react

# 프로젝트 디렉토리 이동
cd web

# 기본 의존성 설치
npm install
```

### 1.2 Vite 기본 구조 확인

```
web/
├── index.html
├── vite.config.js
├── package.json
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   └── App.css
└── public/
    └── vite.svg
```

---

## 2. 필수 패키지 설치

### 2.1 개발 의존성 설치

```bash
# Tailwind CSS 및 PostCSS
npm install -D tailwindcss postcss autoprefixer

# TypeScript 지원 (선택사항이나 권장)
npm install -D typescript @types/react @types/react-dom

# ESLint & Prettier
npm install -D eslint eslint-plugin-react prettier

# 유틸리티
npm install -D classnames
npm install clsx

# 환경변수 관리
npm install dotenv
```

### 2.2 프로덕션 의존성 설치

```bash
# 라우팅
npm install react-router-dom

# 상태 관리 (선택)
npm install zustand
# 또는
npm install @reduxjs/toolkit react-redux

# HTTP 클라이언트
npm install axios

# UI 유틸리티
npm install date-fns
npm install lodash-es

# 아이콘
npm install lucide-react

# 폼 관리 (선택)
npm install react-hook-form zod @hookform/resolvers
```

### 2.3 package.json 검증

```json
{
  "name": "englishgreet-web",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint src",
    "format": "prettier --write src"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.x.x",
    "axios": "^1.6.0",
    "zustand": "^4.x.x",
    "lucide-react": "^0.x.x",
    "clsx": "^2.x.x"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@vitejs/plugin-react": "^4.x.x",
    "vite": "^5.x.x",
    "tailwindcss": "^3.x.x",
    "postcss": "^8.x.x",
    "autoprefixer": "^10.x.x",
    "typescript": "^5.x.x"
  }
}
```

---

## 3. Tailwind CSS 설정

### 3.1 Tailwind CSS 초기화

```bash
# Tailwind 설정 파일 생성
npx tailwindcss init -p
```

생성되는 파일:
- `tailwind.config.js`
- `postcss.config.js`

### 3.2 tailwind.config.js 작성

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  
  theme: {
    extend: {
      // 커스텀 컬러 팔레트
      colors: {
        // Primary Colors - 브랜드 색상 (Blue)
        primary: {
          50:   '#f0f9ff',
          100:  '#e0f2fe',
          200:  '#bae6fd',
          300:  '#7dd3fc',
          400:  '#38bdf8',
          500:  '#0ea5e9',  // Main Brand
          600:  '#0284c7',
          700:  '#0369a1',  // Hover State
          800:  '#075985',
          900:  '#0c3d66',
        },

        // Secondary Colors - 보조 색상 (Orange)
        secondary: {
          50:   '#fef3c7',
          100:  '#fde68a',
          200:  '#fcd34d',
          300:  '#fbbf24',
          400:  '#f59e0b',
          500:  '#f97316',  // Accent
          600:  '#ea580c',
          700:  '#c2410c',
          800:  '#92400e',
          900:  '#78350f',
        },

        // Success Colors - 성공 상태 (Green)
        success: {
          50:   '#f0fdf4',
          100:  '#dcfce7',
          200:  '#bbf7d0',
          300:  '#86efac',
          400:  '#4ade80',
          500:  '#22c55e',  // Main Success
          600:  '#16a34a',
          700:  '#15803d',
          800:  '#166534',
          900:  '#145231',
        },

        // Error Colors - 에러 상태 (Red)
        error: {
          50:   '#fef2f2',
          100:  '#fee2e2',
          200:  '#fecaca',
          300:  '#fca5a5',
          400:  '#f87171',
          500:  '#ef4444',  // Main Error
          600:  '#dc2626',
          700:  '#b91c1c',
          800:  '#991b1b',
          900:  '#7f1d1d',
        },

        // Warning Colors - 경고 상태 (Amber)
        warning: {
          50:   '#fffbeb',
          100:  '#fef3c7',
          200:  '#fde68a',
          300:  '#fcd34d',
          400:  '#fbbf24',
          500:  '#f59e0b',  // Main Warning
          600:  '#d97706',
          700:  '#b45309',
          800:  '#92400e',
          900:  '#78350f',
        },

        // Neutral Colors - 회색톤
        neutral: {
          50:   '#fafafa',
          100:  '#f5f5f5',
          200:  '#e5e5e5',
          300:  '#d4d4d4',
          400:  '#a3a3a3',
          500:  '#737373',
          600:  '#525252',
          700:  '#404040',
          800:  '#262626',
          900:  '#171717',
        },

        // Semantic Colors
        'text-primary': '#0c3d66',
        'text-secondary': '#525252',
        'text-tertiary': '#a3a3a3',
        'bg-light': '#fafafa',
        'bg-surface': '#ffffff',
        'border-light': '#e5e5e5',
      },

      // 타이포그래피 확장
      fontSize: {
        // Display - 큰 제목
        'display-lg': ['4rem', { lineHeight: '1.1', fontWeight: '700' }],     // 64px
        'display-md': ['3rem', { lineHeight: '1.2', fontWeight: '700' }],     // 48px
        'display-sm': ['2.25rem', { lineHeight: '1.2', fontWeight: '700' }],  // 36px

        // Heading - 제목
        'h1': ['2rem', { lineHeight: '1.3', fontWeight: '700' }],             // 32px
        'h2': ['1.75rem', { lineHeight: '1.3', fontWeight: '700' }],          // 28px
        'h3': ['1.5rem', { lineHeight: '1.4', fontWeight: '600' }],           // 24px
        'h4': ['1.25rem', { lineHeight: '1.4', fontWeight: '600' }],          // 20px
        'h5': ['1.125rem', { lineHeight: '1.5', fontWeight: '600' }],         // 18px
        'h6': ['1rem', { lineHeight: '1.5', fontWeight: '600' }],             // 16px

        // Body - 본문
        'body-lg': ['1.125rem', { lineHeight: '1.6', fontWeight: '400' }],    // 18px
        'body-md': ['1rem', { lineHeight: '1.6', fontWeight: '400' }],        // 16px
        'body-sm': ['0.875rem', { lineHeight: '1.5', fontWeight: '400' }],    // 14px
        'body-xs': ['0.75rem', { lineHeight: '1.5', fontWeight: '400' }],     // 12px

        // Label - 라벨 & 캡션
        'label-lg': ['1rem', { lineHeight: '1.5', fontWeight: '500' }],
        'label-md': ['0.875rem', { lineHeight: '1.5', fontWeight: '500' }],
        'label-sm': ['0.75rem', { lineHeight: '1.5', fontWeight: '500' }],

        // Caption - 캡션
        'caption': ['0.75rem', { lineHeight: '1.4', fontWeight: '400' }],
      },

      fontFamily: {
        sans: [
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Roboto',
          '"Helvetica Neue"',
          'Arial',
          '"Noto Sans"',
          'sans-serif',
        ],
        mono: [
          'Fira Code',
          'Menlo',
          'Monaco',
          'Courier New',
          'monospace',
        ],
      },

      // 스페이싱 시스템
      spacing: {
        // 4px 단위 기본 스페이싱
        0: '0',
        1: '0.25rem',    // 4px
        2: '0.5rem',     // 8px
        3: '0.75rem',    // 12px
        4: '1rem',       // 16px
        5: '1.25rem',    // 20px
        6: '1.5rem',     // 24px
        7: '1.75rem',    // 28px
        8: '2rem',       // 32px
        9: '2.25rem',    // 36px
        10: '2.5rem',    // 40px
        11: '2.75rem',   // 44px
        12: '3rem',      // 48px
      },

      // 그림자 시스템
      boxShadow: {
        'xs': '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        'sm': '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        'base': '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
        'md': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'lg': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
        'xl': '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
        'interactive': '0 2px 8px rgba(14, 165, 233, 0.15)',
        'hover': '0 4px 12px rgba(14, 165, 233, 0.2)',
        'focus': '0 0 0 4px rgba(14, 165, 233, 0.1)',
      },

      // 테두리 반경
      borderRadius: {
        'none': '0',
        'xs': '0.25rem',    // 4px
        'sm': '0.375rem',   // 6px
        'base': '0.5rem',   // 8px
        'md': '0.75rem',    // 12px
        'lg': '1rem',       // 16px
        'xl': '1.5rem',     // 24px
        '2xl': '2rem',      // 32px
      },

      // 트랜지션
      transitionDuration: {
        'fast': '150ms',
        'base': '200ms',
        'slow': '300ms',
        'slower': '500ms',
      },

      transitionTimingFunction: {
        'ease-smooth': 'cubic-bezier(0.4, 0, 0.2, 1)',
        'ease-bounce': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
      },

      // 최소/최대 너비
      minWidth: {
        0: '0',
        'full': '100%',
        'min': 'min-content',
        'max': 'max-content',
        'fit': 'fit-content',
      },

      // z-index 계층
      zIndex: {
        'auto': 'auto',
        'base': 0,
        'dropdown': 1000,
        'sticky': 1020,
        'fixed': 1030,
        'modal-backdrop': 1040,
        'modal': 1050,
        'popover': 1060,
        'tooltip': 1070,
      },
    },
  },

  // 다크 테마 설정
  darkMode: 'class',

  // 플러그인
  plugins: [
    require('@tailwindcss/forms'),           // 폼 스타일
    require('@tailwindcss/typography'),      // 타이포그래피
    require('@tailwindcss/aspect-ratio'),    // 