# Node.js + Fastify 백엔드 초기 설정 가이드

EnglishGreet 프로젝트를 위한 프로덕션급 Fastify 백엔드 초기 설정입니다.

---

## 📋 목차

1. [프로젝트 초기화](#1-프로젝트-초기화)
2. [npm 스크립트 및 의존성](#2-npm-스크립트-및-의존성)
3. [디렉토리 구조](#3-디렉토리-구조)
4. [환경변수 설정](#4-환경변수-설정)
5. [Fastify 서버 설정](#5-fastify-서버-설정)
6. [Docker & Docker Compose](#6-docker--docker-compose)
7. [데이터베이스 마이그레이션](#7-데이터베이스-마이그레이션)
8. [실행 방법](#8-실행-방법)

---

## 1. 프로젝트 초기화

### 1.1 프로젝트 생성

```bash
# 프로젝트 디렉토리 생성
mkdir englishgreet-api
cd englishgreet-api

# Git 초기화
git init

# Node.js 프로젝트 초기화
npm init -y

# Node 버전 명시 (.nvmrc)
echo "18.17.0" > .nvmrc
```

### 1.2 초기 패키지 설치

```bash
# 핵심 의존성
npm install fastify fastify-plugin @fastify/cors @fastify/jwt \
            @fastify/cookie @fastify/helmet @fastify/rate-limit \
            dotenv joi pino pino-pretty

# 데이터베이스
npm install prisma @prisma/client

# 유틸리티
npm install axios lodash uuid

# 개발 의존성
npm install -D nodemon typescript @types/node @types/jest \
            eslint prettier jest ts-jest ts-node tsx

# 선택: DB 드라이버 (PostgreSQL 권장)
npm install pg
```

---

## 2. npm 스크립트 및 의존성

### 2.1 package.json

```json
{
  "name": "englishgreet-api",
  "version": "0.1.0",
  "description": "EnglishGreet Backend API - Node.js + Fastify",
  "main": "dist/index.js",
  "type": "module",
  "scripts": {
    "dev": "nodemon --exec node --loader tsx src/index.ts",
    "build": "tsc",
    "start": "node dist/index.js",
    "start:prod": "NODE_ENV=production node dist/index.js",
    "test": "jest",
    "test:watch": "jest --watch",
    "lint": "eslint src --fix",
    "format": "prettier --write \"src/**/*.ts\"",
    "db:migrate": "npx prisma migrate dev --name",
    "db:push": "npx prisma db push",
    "db:seed": "node --loader tsx prisma/seed.ts",
    "db:studio": "npx prisma studio",
    "type-check": "tsc --noEmit",
    "validate": "npm run type-check && npm run lint && npm run test"
  },
  "keywords": ["fastify", "api", "english-learning"],
  "author": "EnglishGreet Team",
  "license": "MIT",
  "dependencies": {
    "fastify": "^4.25.2",
    "fastify-plugin": "^4.5.1",
    "@fastify/cors": "^8.4.2",
    "@fastify/jwt": "^7.8.0",
    "@fastify/cookie": "^9.2.0",
    "@fastify/helmet": "^11.1.1",
    "@fastify/rate-limit": "^9.0.1",
    "@prisma/client": "^5.7.1",
    "dotenv": "^16.3.1",
    "joi": "^17.11.0",
    "pino": "^8.17.2",
    "pino-pretty": "^10.3.1",
    "axios": "^1.6.5",
    "lodash": "^4.17.21",
    "uuid": "^9.0.1"
  },
  "devDependencies": {
    "typescript": "^5.3.3",
    "@types/node": "^20.10.6",
    "@types/jest": "^29.5.11",
    "@types/lodash": "^4.14.202",
    "nodemon": "^3.0.2",
    "eslint": "^8.56.0",
    "prettier": "^3.1.1",
    "jest": "^29.7.0",
    "ts-jest": "^29.1.1",
    "ts-node": "^10.9.2",
    "tsx": "^4.7.0",
    "prisma": "^5.7.1"
  },
  "engines": {
    "node": ">=18.17.0",
    "npm": ">=9.0.0"
  }
}
```

---

## 3. 디렉토리 구조

```
englishgreet-api/
├── src/
│   ├── index.ts                 # 서버 진입점
│   ├── app.ts                   # Fastify 앱 설정
│   ├── config/
│   │   ├── env.ts              # 환경변수 검증
│   │   └── logger.ts           # Pino 로거 설정
│   ├── plugins/
│   │   ├── auth.ts             # JWT 플러그인
│   │   ├── cors.ts             # CORS 플러그인
│   │   └── rate-limit.ts       # Rate limiting
│   ├── routes/
│   │   ├── health.ts           # 헬스 체크
│   │   ├── auth/
│   │   │   ├── index.ts        # 인증 라우트
│   │   │   └── controller.ts   # 인증 컨트롤러
│   │   ├── greetings/
│   │   │   ├── index.ts        # 인삿말 라우트
│   │   │   ├── controller.ts
│   │   │   ├── service.ts
│   │   │   └── schema.ts       # 검증 스키마
│   │   └── users/
│   │       ├── index.ts
│   │       └── controller.ts
│   ├── services/
│   │   ├── auth.service.ts
│   │   └── greeting.service.ts
│   ├── middleware/
│   │   ├── auth.ts
│   │   └── error.ts
│   ├── utils/
│   │   ├── errors.ts           # 커스텀 에러
│   │   ├── response.ts         # 표준 응답 형식
│   │   └── validators.ts       # 검증 유틸
│   └── types/
│       ├── index.ts
│       ├── user.ts
│       └── greeting.ts
├── prisma/
│   ├── schema.prisma           # Prisma 스키마
│   └── seed.ts                 # 데이터 시드
├── tests/
│   ├── unit/
│   └── integration/
├── docker-compose.yml
├── Dockerfile
├── .env.example
├── .env.local
├── .env.production
├── .eslintrc.json
├── .prettierrc
├── tsconfig.json
├── jest.config.js
└── README.md
```

---

## 4. 환경변수 설정

### 4.1 .env.example

```bash
# ============================================
# 서버 설정
# ============================================
NODE_ENV=development
PORT=3000
HOST=0.0.0.0

# ============================================
# 데이터베이스
# ============================================
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/englishgreet_dev"

# ============================================
# JWT 및 인증
# ============================================
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRES_IN=7d
REFRESH_TOKEN_SECRET=your_refresh_token_secret
REFRESH_TOKEN_EXPIRES_IN=30d

# ============================================
# 로깅
# ============================================
LOG_LEVEL=info

# ============================================
# CORS
# ============================================
CORS_ORIGIN=http://localhost:3001,http://localhost:5173
CORS_CREDENTIALS=true

# ============================================
# Rate Limiting
# ============================================
RATE_LIMIT_MAX=100
RATE_LIMIT_TIMEFRAME=900000

# ============================================
# 외부 API
# ============================================
GOOGLE_CLOUD_PROJECT_ID=your-gcp-project
GOOGLE_CLOUD_KEY_FILE=path/to/service-account.json

# ============================================
# AWS S3 (음성 파일 저장)
# ============================================
AWS_REGION=ap-northeast-2
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_S3_BUCKET=englishgreet-audio

# ============================================
# 이메일 설정
# ============================================
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@englishgreet.com
SMTP_PASS=your_app_password

# ============================================
# 애널리틱스
# ============================================
MIXPANEL_TOKEN=your_mixpanel_token
```

### 4.2 .env.local (개발용)

```bash
NODE_ENV=development
PORT=3000
HOST=0.0.0.0

DATABASE_URL="postgresql://postgres:postgres@localhost:5432/englishgreet_dev"

JWT_SECRET=dev_secret_key_12345
JWT_EXPIRES_IN=7d
REFRESH_TOKEN_SECRET=dev_refresh_secret
REFRESH_TOKEN_EXPIRES_IN=30d

LOG_LEVEL=debug

CORS_ORIGIN=http://localhost:3001,http://localhost:5173,http://localhost:8081
CORS_CREDENTIALS=true

RATE_LIMIT_MAX=1000
RATE_LIMIT_TIMEFRAME=900000
```

### 4.3 .env.production

```bash
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

DATABASE_URL=${DATABASE_URL_SECRET}

JWT_SECRET=${JWT_SECRET_PROD}
JWT_EXPIRES_IN=7d
REFRESH_TOKEN_SECRET=${REFRESH_TOKEN_SECRET_PROD}
REFRESH_TOKEN_EXPIRES_IN=30d

LOG_LEVEL=warn

CORS_ORIGIN=https://englishgreet.com,https://app.englishgreet.com
CORS_CREDENTIALS=true

RATE_LIMIT_MAX=100
RATE_LIMIT_TIMEFRAME=900000

AWS_REGION=ap-northeast-2
AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID_PROD}
AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY_PROD}
AWS_S3_BUCKET=englishgreet-audio-prod

SMTP_HOST=${SMTP_HOST_PROD}
SMTP_PORT=587
SMTP_USER=${SMTP_USER_PROD}
SMTP_PASS=${SMTP_PASS_PROD}

MIXPANEL_TOKEN=${MIXPANEL_TOKEN_PROD}
```

### 4.4 config/env.ts (환경변수 검증)

```typescript
import dotenv from 'dotenv';
import Joi from 'joi';

// .env 파일 로드
const envFile = `.env.${process.env.NODE_ENV || 'local'}`;
dotenv.config({ path: envFile });

const envSchema = Joi.object({
  // 서버
  NODE_ENV: Joi.string().valid('development', 'staging', 'production').required(),
  PORT: Joi.number().port().default(3000),
  HOST: Joi.string().hostname().default('0.0.0.0'),

  // 데이터베이스
  DATABASE_URL: Joi.string().uri().required(),

  // JWT
  JWT_SECRET: Joi.string().min(16).required(),
  JWT_EXPIRES_IN: Joi.string().default('7d'),
  REFRESH_TOKEN_SECRET: Joi.string().min(16).required(),
  REFRESH_TOKEN_EXPIRES_IN: Joi.string().default('30d'),

  // 로깅
  LOG_LEVEL: Joi.string().valid('debug', 'info', 'warn', 'error').default('info'),

  // CORS
  CORS_ORIGIN: Joi.string().required(),
  CORS_CREDENTIALS: Joi.boolean().default(true),

  // Rate Limit
  RATE_LIMIT_MAX: Joi.number().default(100),
  RATE_LIMIT_TIMEFRAME: Joi.number().default(900000),

  // AWS
  AWS_REGION: Joi.string().default('ap-northeast-2'),
  AWS_ACCESS_KEY_ID: Joi.string().optional(),
  AWS_SECRET_ACCESS_KEY: Joi.string().optional(),
  AWS_S3_BUCKET: Joi.string().optional(),

  // Email
  SMTP_HOST: Joi.string().optional(),
  SMTP_PORT: Joi.number().optional(),
  SMTP_USER: Joi.string().optional(),
  SMTP_PASS: Joi.string().optional(),
}).unknown(true); // 추가 환경변수 허용

const { value: env, error } = envSchema.validate(process.env);

if (error) {
  throw new Error(`Config validation error: ${error.message}`);
}

export default env;
```

### 4.5 config/logger.ts

```typescript
import pino from 'pino';
import env from './env';

export const logger = pino(
  {
    level: env.LOG_LEVEL || 'info',
    transport:
      env.NODE_ENV === 'production'
        ? undefined
        : {
            target: 'pino-pretty',
            options: {
              colorize: true,
              translateTime: 'SYS:standard',
              ignore: 'pid,hostname',
            },
          },
  }
);

export default logger;
```

---

## 5. Fastify 서버 설정

### 5.1 app.ts (Fastify 앱 생성)

```typescript
import fastify, { FastifyInstance } from 'fastify';
import fastifyJwt from '@fastify/jwt';
import fastifyCors from '@fastify/cors';
import fastifyHelmet from '@fastify/helmet';
import fastifyRateLimit from '@fastify/rate-limit';
import fastifyCookie from '@fastify/cookie';
import env from './config/env';
import logger from './config/logger';

export async function createApp(): Promise<FastifyInstance> {
  const app = fastify({
    logger: logger,
    trustProxy: true,
    bodyLimit: 1048576, // 1MB
  });

  // ============================================
  // 보안 플러그인
  // ============================================
  await app.register(fastifyHelmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe