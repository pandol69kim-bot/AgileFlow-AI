# EnglishGreet 컴포넌트 테스트 코드

## 프로젝트 구조

```
src/
├── components/
│   ├── GreetingCard/
│   │   ├── GreetingCard.tsx
│   │   └── GreetingCard.test.tsx
│   ├── AudioPlayer/
│   │   ├── AudioPlayer.tsx
│   │   └── AudioPlayer.test.tsx
│   ├── SearchBar/
│   │   ├── SearchBar.tsx
│   │   └── SearchBar.test.tsx
│   ├── FavoriteButton/
│   │   ├── FavoriteButton.tsx
│   │   └── FavoriteButton.test.tsx
│   ├── CategoryFilter/
│   │   ├── CategoryFilter.tsx
│   │   └── CategoryFilter.test.tsx
│   └── OnboardingFlow/
│       ├── OnboardingFlow.tsx
│       └── OnboardingFlow.test.tsx
├── test/
│   └── setup.ts
└── vitest.config.ts
```

---

## 설정 파일

### `vitest.config.ts`

```typescript
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'lcov', 'html'],
      include: ['src/components/**/*.tsx'],
      exclude: ['src/test/**'],
      thresholds: {
        lines: 80,
        functions: 80,
        branches: 75,
        statements: 80,
      },
    },
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },
});
```

### `src/test/setup.ts`

```typescript
import '@testing-library/jest-dom';
import { cleanup } from '@testing-library/react';
import { afterEach, vi } from 'vitest';

// 각 테스트 후 DOM 정리
afterEach(() => {
  cleanup();
});

// HTMLMediaElement mock (jsdom은 오디오 미지원)
Object.defineProperty(window, 'HTMLMediaElement', {
  writable: true,
});

window.HTMLMediaElement.prototype.play = vi.fn().mockResolvedValue(undefined);
window.HTMLMediaElement.prototype.pause = vi.fn();
window.HTMLMediaElement.prototype.load = vi.fn();

Object.defineProperty(window.HTMLMediaElement.prototype, 'duration', {
  get: vi.fn().mockReturnValue(3.5),
});

Object.defineProperty(window.HTMLMediaElement.prototype, 'currentTime', {
  get: vi.fn().mockReturnValue(0),
  set: vi.fn(),
});

// IntersectionObserver mock
global.IntersectionObserver = vi.fn().mockImplementation(() => ({
  observe: vi.fn(),
  unobserve: vi.fn(),
  disconnect: vi.fn(),
}));

// matchMedia mock
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation((query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
});
```

---

## 타입 정의

### `src/types/greeting.ts`

```typescript
export type Category = 'daily' | 'business' | 'travel' | 'formal' | 'casual';
export type Difficulty = 'beginner' | 'intermediate' | 'advanced';

export interface Greeting {
  id: string;
  english: string;
  korean: string;
  pronunciation: string;
  audioUrl: string;
  category: Category;
  difficulty: Difficulty;
  isFavorite: boolean;
  tags: string[];
  usageExample?: string;
}
```

---

## 컴포넌트 & 테스트

### 1. GreetingCard 컴포넌트

#### `src/components/GreetingCard/GreetingCard.tsx`

```typescript
import React from 'react';
import type { Greeting } from '@/types/greeting';

interface GreetingCardProps {
  greeting: Greeting;
  onPlay: (id: string) => void;
  onFavoriteToggle: (id: string) => void;
  isPlaying?: boolean;
}

export const GreetingCard: React.FC<GreetingCardProps> = ({
  greeting,
  onPlay,
  onFavoriteToggle,
  isPlaying = false,
}) => {
  const categoryLabel: Record<string, string> = {
    daily: '일상',
    business: '비즈니스',
    travel: '여행',
    formal: '격식',
    casual: '캐주얼',
  };

  const difficultyColor: Record<string, string> = {
    beginner: 'badge-green',
    intermediate: 'badge-yellow',
    advanced: 'badge-red',
  };

  return (
    <article
      className="greeting-card"
      data-testid="greeting-card"
      aria-label={`${greeting.english} 표현 카드`}
    >
      {/* 카테고리 & 난이도 뱃지 */}
      <header className="greeting-card__header">
        <span
          className="badge badge-category"
          data-testid="category-badge"
          aria-label={`카테고리: ${categoryLabel[greeting.category]}`}
        >
          {categoryLabel[greeting.category]}
        </span>
        <span
          className={`badge ${difficultyColor[greeting.difficulty]}`}
          data-testid="difficulty-badge"
          aria-label={`난이도: ${greeting.difficulty}`}
        >
          {greeting.difficulty}
        </span>
      </header>

      {/* 표현 본문 */}
      <main className="greeting-card__body">
        <p
          className="greeting-card__english"
          data-testid="greeting-english"
          lang="en"
        >
          {greeting.english}
        </p>
        <p
          className="greeting-card__pronunciation"
          data-testid="greeting-pronunciation"
          aria-label={`발음: ${greeting.pronunciation}`}
        >
          [{greeting.pronunciation}]
        </p>
        <p
          className="greeting-card__korean"
          data-testid="greeting-korean"
          lang="ko"
        >
          {greeting.korean}
        </p>
        {greeting.usageExample && (
          <p
            className="greeting-card__example"
            data-testid="greeting-example"
          >
            예시: {greeting.usageExample}
          </p>
        )}
      </main>

      {/* 태그 목록 */}
      {greeting.tags.length > 0 && (
        <ul className="greeting-card__tags" aria-label="태그 목록">
          {greeting.tags.map((tag) => (
            <li key={tag} className="tag" data-testid="greeting-tag">
              #{tag}
            </li>
          ))}
        </ul>
      )}

      {/* 액션 버튼 */}
      <footer className="greeting-card__actions">
        <button
          type="button"
          className={`btn-play ${isPlaying ? 'btn-play--active' : ''}`}
          data-testid="play-button"
          onClick={() => onPlay(greeting.id)}
          aria-label={isPlaying ? '재생 중지' : '발음 듣기'}
          aria-pressed={isPlaying}
        >
          {isPlaying ? '⏸ 재생 중' : '▶ 듣기'}
        </button>

        <button
          type="button"
          className={`btn-favorite ${greeting.isFavorite ? 'btn-favorite--active' : ''}`}
          data-testid="favorite-button"
          onClick={() => onFavoriteToggle(greeting.id)}
          aria-label={greeting.isFavorite ? '즐겨찾기 해제' : '즐겨찾기 추가'}
          aria-pressed={greeting.isFavorite}
        >
          {greeting.isFavorite ? '★ 저장됨' : '☆ 저장'}
        </button>
      </footer>
    </article>
  );
};
```

#### `src/components/GreetingCard/GreetingCard.test.tsx`

```typescript
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { GreetingCard } from './GreetingCard';
import type { Greeting } from '@/types/greeting';

// ──────────────────────────────────────────
// 테스트 픽스처
// ──────────────────────────────────────────
const mockGreeting: Greeting = {
  id: 'g-001',
  english: 'Good morning! How are you doing today?',
  korean: '좋은 아침이에요! 오늘 어떻게 지내세요?',
  pronunciation: 'ɡʊd ˈmɔːrnɪŋ haʊ ɑːr juː ˈduːɪŋ təˈdeɪ',
  audioUrl: '/audio/good-morning.mp3',
  category: 'daily',
  difficulty: 'beginner',
  isFavorite: false,
  tags: ['아침', '안부', '일상회화'],
  usageExample: '출근길 동료에게',
};

const createGreeting = (overrides: Partial<Greeting> = {}): Greeting => ({
  ...mockGreeting,
  ...overrides,
});

// ──────────────────────────────────────────
// 테스트 스위트
// ──────────────────────────────────────────
describe('GreetingCard', () => {
  let onPlay: ReturnType<typeof vi.fn>;
  let onFavoriteToggle: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    onPlay = vi.fn();
    onFavoriteToggle = vi.fn();
  });

  // ── 렌더링 ──────────────────────────────
  describe('렌더링', () => {
    it('영어 표현을 올바르게 렌더링한다', () => {
      render(
        <GreetingCard
          greeting={mockGreeting}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      expect(
        screen.getByTestId('greeting-english'),
      ).toHaveTextContent('Good morning! How are you doing today?');
    });

    it('한국어 번역을 올바르게 렌더링한다', () => {
      render(
        <GreetingCard
          greeting={mockGreeting}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      expect(
        screen.getByTestId('greeting-korean'),
      ).toHaveTextContent('좋은 아침이에요! 오늘 어떻게 지내세요?');
    });

    it('발음 기호를 대괄호로 감싸 표시한다', () => {
      render(
        <GreetingCard
          greeting={mockGreeting}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      const pronunciation = screen.getByTestId('greeting-pronunciation');
      expect(pronunciation.textContent).toMatch(/^\[.+\]$/);
    });

    it('카테고리 뱃지에 한국어 레이블을 표시한다', () => {
      const cases: Array<[Greeting['category'], string]> = [
        ['daily', '일상'],
        ['business', '비즈니스'],
        ['travel', '여행'],
        ['formal', '격식'],
        ['casual', '캐주얼'],
      ];

      cases.forEach(([category, label]) => {
        const { unmount } = render(
          <GreetingCard
            greeting={createGreeting({ category })}
            onPlay={onPlay}
            onFavoriteToggle={onFavoriteToggle}
          />,
        );
        expect(screen.getByTestId('category-badge')).toHaveTextContent(label);
        unmount();
      });
    });

    it('태그 목록을 렌더링한다', () => {
      render(
        <GreetingCard
          greeting={mockGreeting}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      const tags = screen.getAllByTestId('greeting-tag');
      expect(tags).toHaveLength(3);
      expect(tags[0]).toHaveTextContent('#아침');
      expect(tags[1]).toHaveTextContent('#안부');
      expect(tags[2]).toHaveTextContent('#일상회화');
    });

    it('usageExample이 있을 때 예시 문장을 표시한다', () => {
      render(
        <GreetingCard
          greeting={mockGreeting}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      expect(
        screen.getByTestId('greeting-example'),
      ).toHaveTextContent('출근길 동료에게');
    });

    it('usageExample이 없을 때 예시 영역을 렌더링하지 않는다', () => {
      render(
        <GreetingCard
          greeting={createGreeting({ usageExample: undefined })}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      expect(
        screen.queryByTestId('greeting-example'),
      ).not.toBeInTheDocument();
    });

    it('태그가 없을 때 태그 목록을 렌더링하지 않는다', () => {
      render(
        <GreetingCard
          greeting={createGreeting({ tags: [] })}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      expect(
        screen.queryByTestId('greeting-tag'),
      ).not.toBeInTheDocument();
    });
  });

  // ── 즐겨찾기 상태 ────────────────────────
  describe('즐겨찾기 상태', () => {
    it('isFavorite=false 일 때 "저장" 텍스트와 미저장 aria-label을 표시한다', () => {
      render(
        <GreetingCard
          greeting={createGreeting({ isFavorite: false })}
          onPlay={onPlay}
          onFavoriteToggle={onFavoriteToggle}
        />,
      );

      const btn = screen.getByTestId('favorite-button');
      expect(btn).