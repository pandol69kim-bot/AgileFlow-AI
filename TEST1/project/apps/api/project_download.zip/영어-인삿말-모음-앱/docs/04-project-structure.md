# EnglishGreet Turborepo 모노레포 디렉토리 구조

```
englishgreet/
├── .github/
│   ├── workflows/
│   │   ├── ci.yml                          # 전체 모노레포 CI
│   │   ├── deploy-web.yml                  # Web 배포
│   │   ├── deploy-api.yml                  # API 배포
│   │   └── deploy-pipeline.yml             # Python Pipeline 배포
│   └── pull_request_template.md
│
├── apps/
│   │
│   ├── web/                                # Vite + React (프론트엔드)
│   │   ├── public/
│   │   │   ├── favicon.ico
│   │   │   ├── icons/                      # PWA 아이콘
│   │   │   └── locales/                    # i18n 정적 리소스
│   │   │       └── ko/
│   │   │           └── translation.json
│   │   ├── src/
│   │   │   ├── assets/
│   │   │   │   ├── images/
│   │   │   │   └── fonts/
│   │   │   ├── components/
│   │   │   │   ├── common/                 # 공통 컴포넌트
│   │   │   │   │   ├── Button/
│   │   │   │   │   │   ├── Button.tsx
│   │   │   │   │   │   ├── Button.test.tsx
│   │   │   │   │   │   └── index.ts
│   │   │   │   │   ├── AudioPlayer/        # 네이티브 발음 재생
│   │   │   │   │   │   ├── AudioPlayer.tsx
│   │   │   │   │   │   ├── AudioPlayer.test.tsx
│   │   │   │   │   │   └── index.ts
│   │   │   │   │   ├── Badge/
│   │   │   │   │   ├── Card/
│   │   │   │   │   ├── Modal/
│   │   │   │   │   ├── SearchBar/
│   │   │   │   │   ├── Skeleton/
│   │   │   │   │   └── Toast/
│   │   │   │   ├── layout/
│   │   │   │   │   ├── AppShell.tsx        # 전체 레이아웃 래퍼
│   │   │   │   │   ├── BottomNav.tsx       # 모바일 하단 네비게이션
│   │   │   │   │   ├── Header.tsx
│   │   │   │   │   └── Sidebar.tsx
│   │   │   │   └── features/              # 기능별 컴포넌트
│   │   │   │       ├── greeting/          # 인삿말 핵심 기능
│   │   │   │       │   ├── GreetingCard.tsx
│   │   │   │       │   ├── GreetingList.tsx
│   │   │   │       │   ├── GreetingDetail.tsx
│   │   │   │       │   ├── GreetingSearch.tsx
│   │   │   │       │   └── PronunciationButton.tsx
│   │   │   │       ├── situation/         # 상황별 분류
│   │   │   │       │   ├── SituationFilter.tsx
│   │   │   │       │   ├── SituationGrid.tsx
│   │   │   │       │   └── SituationBadge.tsx
│   │   │   │       ├── favorite/          # 즐겨찾기
│   │   │   │       │   ├── FavoriteButton.tsx
│   │   │   │       │   ├── FavoriteList.tsx
│   │   │   │       │   └── FavoriteEmpty.tsx
│   │   │   │       ├── onboarding/        # 온보딩 플로우
│   │   │   │       │   ├── OnboardingStep.tsx
│   │   │   │       │   ├── OnboardingProgress.tsx
│   │   │   │       │   └── OnboardingComplete.tsx
│   │   │   │       ├── auth/              # 인증
│   │   │   │       │   ├── LoginForm.tsx
│   │   │   │       │   ├── SocialLoginButton.tsx
│   │   │   │       │   └── AuthGuard.tsx
│   │   │   │       └── premium/           # 프리미엄 구독
│   │   │   │           ├── PremiumBanner.tsx
│   │   │   │           ├── PricingCard.tsx
│   │   │   │           └── UpgradeModal.tsx
│   │   │   ├── pages/                     # 라우트별 페이지
│   │   │   │   ├── HomePage.tsx           # 메인 (상황 카테고리)
│   │   │   │   ├── SearchPage.tsx         # 표현 검색
│   │   │   │   ├── GreetingDetailPage.tsx # 표현 상세
│   │   │   │   ├── SituationPage.tsx      # 상황별 표현 목록
│   │   │   │   ├── FavoritePage.tsx       # 즐겨찾기
│   │   │   │   ├── OnboardingPage.tsx     # 온보딩
│   │   │   │   ├── ProfilePage.tsx        # 사용자 프로필
│   │   │   │   ├── PremiumPage.tsx        # 구독 플랜
│   │   │   │   ├── LoginPage.tsx
│   │   │   │   └── NotFoundPage.tsx
│   │   │   ├── hooks/                     # 커스텀 훅
│   │   │   │   ├── useAudioPlayer.ts      # 발음 재생 훅
│   │   │   │   ├── useGreetings.ts        # 표현 조회 훅
│   │   │   │   ├── useFavorite.ts         # 즐겨찾기 훅
│   │   │   │   ├── useSearch.ts           # 검색 훅
│   │   │   │   ├── useOnboarding.ts       # 온보딩 상태 훅
│   │   │   │   └── useAuth.ts             # 인증 훅
│   │   │   ├── stores/                    # Zustand 상태 관리
│   │   │   │   ├── authStore.ts
│   │   │   │   ├── favoriteStore.ts
│   │   │   │   ├── onboardingStore.ts
│   │   │   │   └── playerStore.ts         # 오디오 플레이어 상태
│   │   │   ├── services/                  # API 호출 레이어
│   │   │   │   ├── api.ts                 # Axios 인스턴스 + 인터셉터
│   │   │   │   ├── greetingService.ts
│   │   │   │   ├── favoriteService.ts
│   │   │   │   ├── authService.ts
│   │   │   │   └── analyticsService.ts    # KPI 이벤트 추적
│   │   │   ├── router/
│   │   │   │   ├── index.tsx              # React Router 설정
│   │   │   │   └── routes.ts              # 라우트 상수
│   │   │   ├── styles/
│   │   │   │   ├── globals.css
│   │   │   │   ├── tokens.css             # 디자인 토큰 CSS 변수
│   │   │   │   └── animations.css
│   │   │   ├── utils/
│   │   │   │   ├── cn.ts                  # className 유틸
│   │   │   │   └── formatters.ts
│   │   │   ├── types/
│   │   │   │   └── env.d.ts               # Vite 환경변수 타입
│   │   │   ├── App.tsx
│   │   │   └── main.tsx
│   │   ├── index.html
│   │   ├── vite.config.ts
│   │   ├── tsconfig.json
│   │   ├── tsconfig.app.json
│   │   ├── tailwind.config.ts
│   │   ├── postcss.config.js
│   │   ├── vitest.config.ts
│   │   ├── .env.example
│   │   └── package.json
│   │
│   ├── api/                               # Fastify (백엔드 API)
│   │   ├── src/
│   │   │   ├── plugins/                   # Fastify 플러그인
│   │   │   │   ├── auth.ts                # JWT 인증 플러그인
│   │   │   │   ├── cors.ts
│   │   │   │   ├── rateLimit.ts           # 요청 제한
│   │   │   │   ├── swagger.ts             # API 문서 자동화
│   │   │   │   ├── redis.ts               # Redis 캐싱
│   │   │   │   └── prisma.ts              # DB 연결
│   │   │   ├── routes/                    # API 라우트
│   │   │   │   ├── v1/
│   │   │   │   │   ├── index.ts           # v1 라우트 등록
│   │   │   │   │   ├── greetings/
│   │   │   │   │   │   ├── index.ts       # GET /greetings
│   │   │   │   │   │   ├── [id].ts        # GET /greetings/:id
│   │   │   │   │   │   ├── search.ts      # GET /greetings/search
│   │   │   │   │   │   └── schema.ts      # Zod 스키마
│   │   │   │   │   ├── situations/
│   │   │   │   │   │   ├── index.ts       # GET /situations
│   │   │   │   │   │   ├── [id].ts        # GET /situations/:id
│   │   │   │   │   │   └── schema.ts
│   │   │   │   │   ├── favorites/
│   │   │   │   │   │   ├── index.ts       # GET/POST /favorites
│   │   │   │   │   │   ├── [id].ts        # DELETE /favorites/:id
│   │   │   │   │   │   └── schema.ts
│   │   │   │   │   ├── auth/
│   │   │   │   │   │   ├── login.ts       # POST /auth/login
│   │   │   │   │   │   ├── logout.ts
│   │   │   │   │   │   ├── refresh.ts     # POST /auth/refresh
│   │   │   │   │   │   ├── social.ts      # 소셜 로그인 콜백
│   │   │   │   │   │   └── schema.ts
│   │   │   │   │   ├── users/
│   │   │   │   │   │   ├── me.ts          # GET/PATCH /users/me
│   │   │   │   │   │   ├── onboarding.ts  # POST /users/me/onboarding
│   │   │   │   │   │   └── schema.ts
│   │   │   │   │   ├── premium/
│   │   │   │   │   │   ├── plans.ts       # GET /premium/plans
│   │   │   │   │   │   ├── subscribe.ts   # POST /premium/subscribe
│   │   │   │   │   │   └── schema.ts
│   │   │   │   │   └── analytics/
│   │   │   │   │       ├── events.ts      # POST /analytics/events
│   │   │   │   │       └── schema.ts
│   │   │   ├── services/                  # 비즈니스 로직
│   │   │   │   ├── greetingService.ts
│   │   │   │   ├── favoriteService.ts
│   │   │   │   ├── authService.ts
│   │   │   │   ├── userService.ts
│   │   │   │   ├── premiumService.ts
│   │   │   │   ├── analyticsService.ts
│   │   │   │   └── audioService.ts        # TTS / 오디오 URL 관리
│   │   │   ├── repositories/              # DB 접근 레이어
│   │   │   │   ├── greetingRepository.ts
│   │   │   │   ├── favoriteRepository.ts
│   │   │   │   ├── userRepository.ts
│   │   │   │   └── analyticsRepository.ts
│   │   │   ├── middlewares/
│   │   │   │   ├── authenticate.ts        # 인증 미들웨어
│   │   │   │   ├── premiumGuard.ts        # 프리미엄 접근 제한
│   │   │   │   └── requestLogger.ts
│   │   │   ├── config/
│   │   │   │   ├── env.ts                 # 환경변수 검증 (Zod)
│   │   │   │   └── constants.ts
│   │   │   ├── utils/
│   │   │   │   ├── errors.ts              # 커스텀 에러 클래스
│   │   │   │   ├── pagination.ts
│   │   │   │   └── cache.ts               # Redis 캐시 헬퍼
│   │   │   └── app.ts                     # Fastify 앱 초기화
│   │   ├── prisma/
│   │   │   ├── schema.prisma              # DB 스키마
│   │   │   ├── seed.ts                    # 초기 데이터 시딩
│   │   │   └── migrations/                # DB 마이그레이션
│   │   │       └── 20250101000000_init/
│   │   │           └── migration.sql
│   │   ├── tests/
│   │   │   ├── unit/
│   │   │   │   ├── services/
│   │   │   │   └── utils/
│   │   │   ├── integration/
│   │   │   │   ├── greetings.test.ts
│   │   │   │   ├── auth.test.ts
│   │   │   │   └── favorites.test.ts
│   │   │   └── fixtures/
│   │   │       └── greetings.json         # 테스트용 픽스처 데이터
│   │   ├── .env.example
│   │   ├── tsconfig.json
│   │   ├── package.json
│   │   └──