# EnglishGreet 데이터베이스 스키마 설계서

---

## 목차

1. [ERD 요약](#1-erd-요약)
2. [테이블 정의](#2-테이블-정의)
3. [인덱스 전략](#3-인덱스-전략)
4. [마이그레이션 계획](#4-마이그레이션-계획)

---

## 1. ERD 요약

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          EnglishGreet ERD 요약                               │
└─────────────────────────────────────────────────────────────────────────────┘

  [users] ──────────────────────────────────────────────────────────┐
     │ 1                                                             │
     │                                                               │
     ├──── N [user_sessions]          (세션 추적)                    │
     │                                                               │
     ├──── N [user_favorites]         (즐겨찾기)                     │
     │         N │                                                   │
     │           │ belongs_to                                        │
     ├──── N [user_learning_logs]     (학습 이력)                    │
     │         N │                                                   │
     │           │ belongs_to                                        │
     └──── N [user_subscriptions]     (구독 정보)                    │
                                                                     │
  [categories] ──── N [phrases]  ──────────────────────────────────-┘
       │ 1               │ 1
       │                 │
  [sub_categories]       ├──── N [phrase_audio_files]  (음성 파일)
       │ 1               │
       │                 ├──── N [user_favorites]
  (phrases FK)           │
                         ├──── N [user_learning_logs]
                         │
                         └──── N [phrase_tags] ──── [tags]


  [onboarding_surveys] ─── 1:1 ─── [users]     (온보딩 설문)

  [push_notifications] ─── N:1 ─── [users]     (푸시 알림 이력)

  [app_events]                                  (행동 로그 / Analytics)


  관계 요약
  ─────────────────────────────────────────────────────────────────
  users            1 ── N  user_sessions
  users            1 ── N  user_favorites
  users            1 ── N  user_learning_logs
  users            1 ── N  user_subscriptions
  users            1 ── 1  onboarding_surveys
  users            1 ── N  push_notifications
  categories       1 ── N  sub_categories
  categories       1 ── N  phrases
  sub_categories   1 ── N  phrases
  phrases          1 ── N  phrase_audio_files
  phrases          1 ── N  user_favorites
  phrases          1 ── N  user_learning_logs
  phrases          N ── N  tags  (through phrase_tags)
  ─────────────────────────────────────────────────────────────────
```

---

## 2. 테이블 정의

> **공통 규칙**
> - PK: `BIGINT UNSIGNED AUTO_INCREMENT` (MySQL) / `BIGSERIAL` (PostgreSQL 병행 기술)
> - 소프트 삭제: `deleted_at TIMESTAMP NULL` (필요한 테이블에만 적용)
> - 타임스탬프: `created_at`, `updated_at` 전 테이블 공통 적용
> - 문자셋: `utf8mb4` / Collation: `utf8mb4_unicode_ci`
> - DB 엔진: MySQL 8.0+ 기준 (PostgreSQL 호환 주석 병기)

---

### 2.1 users (사용자)

> 핵심 사용자 계정 정보. 소셜 로그인(Apple/Google) 및 이메일 가입 지원.

| # | 컬럼명 | 타입 | 제약조건 | 기본값 | 설명 |
|---|--------|------|----------|--------|------|
| 1 | `id` | BIGINT UNSIGNED | PK, AUTO_INCREMENT | - | 사용자 고유 ID |
| 2 | `uuid` | CHAR(36) | UNIQUE, NOT NULL | UUID() | 외부 노출용 UUID |
| 3 | `email` | VARCHAR(255) | UNIQUE, NULL | NULL | 이메일 (소셜 전용 시 NULL 가능) |
| 4 | `email_verified_at` | TIMESTAMP | NULL | NULL | 이메일 인증 완료 시각 |
| 5 | `password_hash` | VARCHAR(255) | NULL | NULL | bcrypt 해시 (소셜 전용 시 NULL) |
| 6 | `nickname` | VARCHAR(50) | NOT NULL | - | 표시 닉네임 |
| 7 | `profile_image_url` | VARCHAR(500) | NULL | NULL | 프로필 이미지 URL |
| 8 | `auth_provider` | ENUM | NOT NULL | 'email' | 'email','google','apple' |
| 9 | `auth_provider_id` | VARCHAR(255) | NULL | NULL | 소셜 공급자 고유 ID |
| 10 | `locale` | VARCHAR(10) | NOT NULL | 'ko' | 언어 설정 (ko, en 등) |
| 11 | `timezone` | VARCHAR(50) | NOT NULL | 'Asia/Seoul' | 타임존 |
| 12 | `is_premium` | TINYINT(1) | NOT NULL | 0 | 프리미엄 여부 (캐시 컬럼) |
| 13 | `onboarding_completed_at` | TIMESTAMP | NULL | NULL | 온보딩 완료 시각 |
| 14 | `last_active_at` | TIMESTAMP | NULL | NULL | 마지막 활동 시각 |
| 15 | `push_token` | VARCHAR(500) | NULL | NULL | FCM/APNs 푸시 토큰 |
| 16 | `push_enabled` | TINYINT(1) | NOT NULL | 1 | 푸시 알림 수신 동의 |
| 17 | `status` | ENUM | NOT NULL | 'active' | 'active','suspended','withdrawn' |
| 18 | `withdrawn_at` | TIMESTAMP | NULL | NULL | 탈퇴 처리 시각 |
| 19 | `created_at` | TIMESTAMP | NOT NULL | CURRENT_TIMESTAMP | 가입 시각 |
| 20 | `updated_at` | TIMESTAMP | NOT NULL | CURRENT_TIMESTAMP ON UPDATE | 수정 시각 |
| 21 | `deleted_at` | TIMESTAMP | NULL | NULL | 소프트 삭제 시각 |

```sql
CREATE TABLE users (
  id                      BIGINT UNSIGNED     NOT NULL AUTO_INCREMENT,
  uuid                    CHAR(36)            NOT NULL DEFAULT (UUID()),
  email                   VARCHAR(255)        NULL,
  email_verified_at       TIMESTAMP           NULL,
  password_hash           VARCHAR(255)        NULL,
  nickname                VARCHAR(50)         NOT NULL,
  profile_image_url       VARCHAR(500)        NULL,
  auth_provider           ENUM('email','google','apple') NOT NULL DEFAULT 'email',
  auth_provider_id        VARCHAR(255)        NULL,
  locale                  VARCHAR(10)         NOT NULL DEFAULT 'ko',
  timezone                VARCHAR(50)         NOT NULL DEFAULT 'Asia/Seoul',
  is_premium              TINYINT(1)          NOT NULL DEFAULT 0,
  onboarding_completed_at TIMESTAMP           NULL,
  last_active_at          TIMESTAMP           NULL,
  push_token              VARCHAR(500)        NULL,
  push_enabled            TINYINT(1)          NOT NULL DEFAULT 1,
  status                  ENUM('active','suspended','withdrawn') NOT NULL DEFAULT 'active',
  withdrawn_at            TIMESTAMP           NULL,
  created_at              TIMESTAMP           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at              TIMESTAMP           NOT NULL DEFAULT CURRENT_TIMESTAMP
                                              ON UPDATE CURRENT_TIMESTAMP,
  deleted_at              TIMESTAMP           NULL,

  PRIMARY KEY (id),
  UNIQUE  KEY uq_users_uuid          (uuid),
  UNIQUE  KEY uq_users_email         (email),
  UNIQUE  KEY uq_users_provider      (auth_provider, auth_provider_id),
          KEY idx_users_status       (status),
          KEY idx_users_last_active  (last_active_at),
          KEY idx_users_is_premium   (is_premium)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

### 2.2 user_sessions (사용자 세션)

> 앱 세션 단위 추적. Retention / 세션 수 KPI 측정에 활용.

| # | 컬럼명 | 타입 | 제약조건 | 기본값 | 설명 |
|---|--------|------|----------|--------|------|
| 1 | `id` | BIGINT UNSIGNED | PK, AUTO_INCREMENT | - | 세션 ID |
| 2 | `user_id` | BIGINT UNSIGNED | FK → users.id, NOT NULL | - | 사용자 ID |
| 3 | `session_token` | VARCHAR(255) | UNIQUE, NOT NULL | - | 세션 토큰 |
| 4 | `device_type` | ENUM | NOT NULL | 'unknown' | 'ios','android','web','unknown' |
| 5 | `device_id` | VARCHAR(255) | NULL | NULL | 디바이스 고유 식별자 |
| 6 | `app_version` | VARCHAR(20) | NULL | NULL | 앱 버전 (예: 1.0.0) |
| 7 | `os_version` | VARCHAR(20) | NULL | NULL | OS 버전 |
| 8 | `ip_address` | VARCHAR(45) | NULL | NULL | IPv4/IPv6 |
| 9 | `started_at` | TIMESTAMP | NOT NULL | CURRENT_TIMESTAMP | 세션 시작 시각 |
| 10 | `ended_at` | TIMESTAMP | NULL | NULL | 세션 종료 시각 |
| 11 | `duration_seconds` | INT UNSIGNED | NULL | NULL | 세션 지속 시간(초) |
| 12 | `phrase_view_count` | INT UNSIGNED | NOT NULL | 0 | 세션 내 표현 조회 수 |
| 13 | `created_at` | TIMESTAMP | NOT NULL | CURRENT_TIMESTAMP | 레코드 생성 시각 |

```sql
CREATE TABLE user_sessions (
  id                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  user_id           BIGINT UNSIGNED  NOT NULL,
  session_token     VARCHAR(255)     NOT NULL,
  device_type       ENUM('ios','android','web','unknown') NOT NULL DEFAULT 'unknown',
  device_id         VARCHAR(255)     NULL,
  app_version       VARCHAR(20)      NULL,
  os_version        VARCHAR(20)      NULL,
  ip_address        VARCHAR(45)      NULL,
  started_at        TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at          TIMESTAMP        NULL,
  duration_seconds  INT UNSIGNED     NULL,
  phrase_view_count INT UNSIGNED     NOT NULL DEFAULT 0,
  created_at        TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE  KEY uq_session_token          (session_token),
          KEY idx_sessions_user_id      (user_id),
          KEY idx_sessions_started_at   (started_at),
          KEY idx_sessions_device       (device_id),

  CONSTRAINT fk_sessions_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

### 2.3 categories (카테고리)

> 최상위 상황 분류. 예: 일상, 비즈니스, 여행.

| # | 컬럼명 | 타입 | 제약조건 | 기본값 | 설명 |
|---|--------|------|----------|--------|------|
| 1 | `id` | INT UNSIGNED | PK, AUTO_INCREMENT | - | 카테고리 ID |
| 2 | `slug` | VARCHAR(100) | UNIQUE, NOT NULL | - | URL용 슬러그 (예: daily-life) |
| 3 | `name_ko` | VARCHAR(100) | NOT NULL | - | 한국어 카테고리명 |
| 4 | `name_en` | VARCHAR(100) | NOT NULL | - | 영어 카테고리명 |
| 5 | `description_ko` | TEXT | NULL | NULL | 한국어 설명 |
| 6 | `icon_url` | VARCHAR(500) | NULL | NULL | 아이콘 이미지 URL |
| 7 | `color_hex` | CHAR(7) | NULL | NULL | 대표 색상 (#RRGGBB) |
| 8 | `sort_order` | SMALLINT UNSIGNED | NOT NULL | 0 | 정렬 순서 |
| 9 | `is_active` | TINYINT(1) | NOT NULL | 1 | 노출 여부 |
| 10 | `is_premium_only` | TINYINT(1) | NOT NULL | 0 | 프리미엄 전용 여부 |
| 11 | `created_at` | TIMESTAMP | NOT NULL | CURRENT_TIMESTAMP | 생성 시각 |
| 12 | `updated_at` | TIMESTAMP | NOT NULL | CURRENT_TIMESTAMP ON UPDATE | 수정 시각 |

```sql
CREATE TABLE categories (
  id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  slug            VARCHAR(100)    NOT NULL,
  name_ko         VARCHAR(100)    NOT NULL,
  name_en         VARCHAR(100)    NOT NULL,
  description_ko  TEXT            NULL,
  icon_url        VARCHAR(500)    NULL,
  color_hex       CHAR(7)         NULL,
  sort_order      SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  is_active       TINYINT(1)      NOT NULL DEFAULT 1,
  is_premium_only TINYINT(1)      NOT NULL DEFAULT 0,
  created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE  KEY uq_category_slug       (slug),
          KEY idx_category_active    (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

### 2.4 sub_categories (서브 카테고리)

> 카테고리 하위 상황 분류. 예: 비즈니스 > 회의 시