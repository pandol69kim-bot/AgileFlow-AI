# EnglishGreet 기술 스택 결정서 (Technology Stack Decision Document)

**문서 버전**: v1.0  
**작성일**: 2025년 1월  
**작성자**: Senior Software Architect (15년차)  
**검토 상태**: Draft  
**대상 독자**: 개발팀, CTO, DevOps팀, 보안팀

---

## 목차

1. [아키텍처 개요](#1-아키텍처-개요)
2. [프론트엔드 스택](#2-프론트엔드-스택)
3. [백엔드 스택](#3-백엔드-스택)
4. [데이터베이스 스택](#4-데이터베이스-스택)
5. [인프라 & DevOps](#5-인프라--devops)
6. [모니터링 & 분석](#6-모니터링--분석)
7. [보안 스택](#7-보안-스택)
8. [스택 통합 아키텍처 다이어그램](#8-스택-통합-아키텍처-다이어그램)
9. [기술 부채 & 마이그레이션 로드맵](#9-기술-부채--마이그레이션-로드맵)
10. [의사결정 로그 (ADR)](#10-의사결정-로그-adr)

---

## 1. 아키텍처 개요

### 1.1 의사결정 원칙

EnglishGreet PRD를 분석한 결과, 다음 4가지 아키텍처 원칙을 최우선으로 설정합니다.

```
┌────────────────────────────────────────────────────────────┐
│  아키텍처 4대 원칙                                           │
│                                                            │
│  1. Speed-First   → 5초 내 표현 검색 (PRD 핵심 비전)        │
│  2. Mobile-First  → 한국어권 직장인/학생 타겟 (모바일 중심)   │
│  3. Cost-Efficient → Freemium 수익모델, 초기 비용 최소화     │
│  4. Scale-Ready   → MAU 10,000 → 100,000 확장 대비         │
└────────────────────────────────────────────────────────────┘
```

### 1.2 시스템 규모 예측

PRD KPI를 기반으로 인프라 규모를 사전 산정합니다.

| 지표 | 3개월 목표 | 6개월 예상 | 아키텍처 임계점 |
|------|-----------|-----------|--------------|
| MAU | 10,000 | 50,000 | 100,000 |
| DAU (MAU × 20%) | 2,000 | 10,000 | 20,000 |
| 동시 접속자 (DAU × 5%) | 100 | 500 | 1,000 |
| 일일 API 요청 | ~100,000 | ~500,000 | ~1,000,000 |
| 음성 파일 스토리지 | ~5GB | ~20GB | ~50GB |

> **아키텍트 판단**: 초기 MAU 10,000 수준은 단일 서버로 충분하나,  
> 6개월 확장을 대비한 수평 확장 가능한 구조를 처음부터 설계합니다.  
> 과도한 마이크로서비스는 지양하고, **Modular Monolith → MSA 점진적 전환** 전략을 채택합니다.

---

## 2. 프론트엔드 스택

### 2.1 핵심 스택 결정

```
프론트엔드 메인 스택
─────────────────────────────────────────
빌드 도구     : Vite 5.x
UI 프레임워크 : React 19.x
언어          : TypeScript 5.x
상태관리      : Zustand 4.x + TanStack Query 5.x
스타일링      : Tailwind CSS 3.x + shadcn/ui
라우팅        : React Router 7.x (Data Router)
폼            : React Hook Form 7.x + Zod
애니메이션    : Framer Motion 11.x
```

### 2.2 Vite 선택 근거

#### 선택: Vite 5.x

| 평가 기준 | Vite 5.x | CRA (Create React App) | Next.js 14 | Remix |
|----------|----------|----------------------|------------|-------|
| **개발 서버 기동 속도** | ⚡ < 300ms (ESM 네이티브) | 🐢 5~30초 | 🟡 2~5초 | 🟡 2~5초 |
| **HMR 속도** | ⚡ < 50ms | 🐢 500ms+ | 🟡 200ms | 🟡 200ms |
| **번들 크기 최적화** | ✅ Rollup 기반 | ❌ Webpack 5 (헤비) | ✅ Turbopack | ✅ |
| **SSR 필요성** | ❌ SPA 충분 | ❌ | ✅ SSR 강점 | ✅ SSR 강점 |
| **SEO 중요도** | 🟡 앱스토어 랜딩은 별도 | - | ✅ | ✅ |
| **팀 러닝커브** | 낮음 | 낮음 | 중간 | 높음 |
| **생태계 성숙도** | ✅ 2025년 표준 | ❌ 공식 deprecated | ✅ | 🟡 |
| **플러그인 생태계** | ✅ 풍부 | ❌ eject 필요 | 🟡 Next 전용 | 🟡 |

**선택 근거:**

```
1. EnglishGreet는 순수 SPA 구조가 적합
   - 앱 내 콘텐츠(표현, 카테고리)는 로그인 후 접근
   - SEO 필요 페이지는 마케팅 랜딩 페이지(별도 정적 페이지) 분리
   - SSR 오버헤드 불필요 → Vite SPA 최적

2. 개발 생산성 극대화
   - PRD 마일스톤: 4-5개월 MVP → 빠른 개발 사이클 필수
   - HMR 50ms vs CRA 500ms → 하루 200회 저장 시 개발자당 1.5시간 절약

3. 번들 최적화
   - Rollup 기반 트리쉐이킹으로 음성 플레이어 등 무거운 라이브러리 lazy load 용이
   - Code splitting 전략: 카테고리별 청크 분리로 초기 로딩 최소화
```

**기각된 대안 - Next.js:**
> PRD 요구사항을 보면 학습 앱의 특성상 로그인 이후 콘텐츠가 대부분이며,  
> App Store / Play Store 배포가 주 채널입니다. 마케팅 랜딩페이지는 별도 정적 호스팅(Vercel)으로  
> 분리하면 Next.js의 SSR 이점이 사라집니다. Next.js의 복잡한 라우팅 컨벤션과  
> Server Component 러닝커브는 4-5개월 MVP 일정에 리스크입니다.

---

### 2.3 React 19 선택 근거

#### 선택: React 19.x

| 평가 기준 | React 19 | Vue 3 | Svelte 5 | Solid.js |
|----------|----------|-------|----------|---------|
| **생태계 크기** | ✅ 압도적 1위 | ✅ 2위 | 🟡 성장중 | ❌ 소규모 |
| **채용 시장** | ✅ 한국 1위 | ✅ 2위 | ❌ | ❌ |
| **React Compiler** | ✅ (19 신기능) | N/A | N/A | N/A |
| **서버 컴포넌트** | ✅ (옵션) | ❌ | ❌ | ❌ |
| **TypeScript 지원** | ✅ | ✅ | ✅ | ✅ |
| **음성 라이브러리 생태계** | ✅ react-use, howler | 🟡 | ❌ | ❌ |
| **애니메이션 라이브러리** | ✅ Framer Motion | 🟡 | ❌ | ❌ |

**선택 근거:**

```
1. React 19 Compiler 자동 최적화
   - useMemo/useCallback 수동 최적화 불필요
   - 음성 재생 상태관리 컴포넌트의 불필요한 리렌더링 자동 방지
   - 표현 목록(최대 수백 개) 렌더링 성능 향상

2. PRD 음성 기능에 최적화된 생태계
   - Howler.js: 크로스 플랫폼 음성 재생 (iOS Safari Web Audio API 이슈 처리)
   - react-use: useAudio 훅으로 음성 컨트롤 추상화
   - Web Speech API 래퍼 라이브러리 풍부

3. 팀 확장성
   - 한국 시장 React 개발자 채용 용이
   - 레퍼런스 문서/커뮤니티 한국어 자료 풍부
```

---

### 2.4 상태 관리 전략

#### 선택: Zustand + TanStack Query (역할 분리)

```
상태 관리 레이어 분리
─────────────────────────────────────────────────────
서버 상태    : TanStack Query 5.x (API 데이터, 캐싱)
클라이언트  : Zustand 4.x (UI 상태, 사용자 설정)
폼 상태      : React Hook Form (입력 상태)
URL 상태     : React Router (네비게이션 상태)
─────────────────────────────────────────────────────
```

| 상태 유형 | 담당 라이브러리 | 예시 |
|----------|--------------|------|
| 표현 목록 데이터 | TanStack Query | `/api/expressions?category=greeting` |
| 즐겨찾기 목록 | TanStack Query | `/api/favorites` (optimistic update) |
| 현재 재생 중인 음성 | Zustand | `audioStore.currentPlaying` |
| 온보딩 진행 단계 | Zustand | `onboardingStore.step` |
| 사용자 설정 (속도, 반복) | Zustand + localStorage | `settingsStore.playbackSpeed` |
| 검색 쿼리 | URL params (React Router) | `?q=hello` |

**Redux 기각 근거:**
> EnglishGreet 수준의 앱에서 Redux의 boilerplate(action, reducer, selector)는  
> 과도한 복잡성입니다. Zustand는 동일 기능을 1/5 코드로 구현하며,  
> React DevTools와 통합도 지원합니다.

**TanStack Query 선택 근거:**
```
- 표현 목록: staleTime 5분으로 반복 요청 차단 → 서버 부하 감소
- 즐겨찾기: optimistic update로 PRD 목표 "5초 내 반응" 달성
- 오프라인: 네트워크 불안정 시 캐시 데이터 제공
- PRD Day 7 Retention 목표 달성에 부드러운 UX가 핵심
```

---

### 2.5 스타일링 전략

#### 선택: Tailwind CSS 3.x + shadcn/ui

| 평가 기준 | Tailwind + shadcn/ui | Styled Components | MUI (Material UI) | Chakra UI |
|----------|---------------------|------------------|------------------|-----------|
| **번들 크기** | ✅ PurgeCSS로 ~10KB | ❌ 런타임 CSS-in-JS | ❌ ~300KB+ | ❌ ~200KB+ |
| **커스터마이징** | ✅ 완전 제어 | ✅ | 🟡 테마 시스템 | 🟡 |
| **shadcn 접근성** | ✅ Radix UI 기반 | N/A | ✅ | ✅ |
| **디자인 일관성** | ✅ Design Token | 🟡 | ✅ | ✅ |
| **React 19 호환** | ✅ | 🟡 (서버 컴포넌트 이슈) | 🟡 | 🟡 |
| **다크모드** | ✅ class 전략 | 🟡 | ✅ | ✅ |

**선택 근거:**
```
1. shadcn/ui: "복사 붙여넣기" 컴포넌트
   - 패키지 의존성 없이 소스 소유 → 번들 최적화 완전 제어
   - Radix UI 기반 접근성(a11y) 기본 제공
   - 음성 플레이어 커스텀 UI 구현에 최적

2. Tailwind: 모바일 반응형 용이
   - sm/md/lg breakpoint로 모바일 퍼스트 구현
   - PRD 타겟(직장인, 학생)의 모바일 사용 환경 최적화

3. 번들 크기
   - MUI 300KB+ vs Tailwind+shadcn 10KB 이하
   - 모바일 데이터 환경에서 초기 로딩