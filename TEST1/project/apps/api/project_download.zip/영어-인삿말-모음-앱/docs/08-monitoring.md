# EnglishGreet 모니터링 설정 문서

**문서 버전**: v1.0  
**작성일**: 2025년 1월  
**작성자**: DevOps & Observability Team  
**상태**: Draft  
**대상 독자**: DevOps팀, 백엔드팀, SRE팀

---

## 목차

1. [모니터링 아키텍처](#1-모니터링-아키텍처)
2. [LangSmith 설정](#2-langsmith-설정)
3. [Sentry 에러 트래킹](#3-sentry-에러-트래킹)
4. [헬스체크 설정](#4-헬스체크-설정)
5. [알림 규칙 정의](#5-알림-규칙-정의)
6. [대시보드 구성](#6-대시보드-구성)
7. [SLA & 목표](#7-sla--목표)

---

## 1. 모니터링 아키텍처

### 1.1 모니터링 스택 다이어그램

```
┌─────────────────────────────────────────────────────────────────┐
│                     Application Layer                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ FastAPI      │  │ LLM Service  │  │ Audio Service│          │
│  │ (Python)     │  │ (LangChain)  │  │ (Pydub)      │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
         │                    │                    │
         ├────────────────────┼────────────────────┤
         ▼                    ▼                    ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│   LangSmith      │  │    Sentry        │  │  Custom Metrics  │
│  (LLM Tracing)   │  │ (Error Tracking) │  │  (Prometheus)    │
└──────────────────┘  └──────────────────┘  └──────────────────┘
         │                    │                    │
         └────────────────────┼────────────────────┘
                              ▼
                    ┌──────────────────────┐
                    │   Alert Manager      │
                    │  (PagerDuty/Slack)   │
                    └──────────────────────┘
```

### 1.2 모니터링 계층별 담당

| 계층 | 담당 도구 | 모니터링 대상 | SLA |
|------|---------|-------------|-----|
| **LLM/AI** | LangSmith | 응답 시간, 토큰 사용량, 오류율 | <5초 응답 |
| **애플리케이션** | Sentry | 예외, 크래시, 성능 저하 | 에러율 <0.1% |
| **인프라** | Prometheus + Grafana | CPU, 메모리, 디스크, 네트워크 | 99.9% 가용성 |
| **비즈니스** | Custom Events | 사용자 행동, 전환율, 음성 파일 크기 | 실시간 분석 |

---

## 2. LangSmith 설정

### 2.1 LangSmith 초기화 (Python)

```python
# config/langsmith_config.py
import os
from langsmith import Client
from langsmith.schemas import Run
from typing import Optional, Dict, Any

# LangSmith 클라이언트 초기화
langsmith_client = Client(
    api_url=os.getenv("LANGSMITH_API_URL", "https://api.smith.langchain.com"),
    api_key=os.getenv("LANGSMITH_API_KEY")
)

# 프로젝트명 설정
LANGSMITH_PROJECT = os.getenv("LANGSMITH_PROJECT", "englishgreet-dev")

class LangSmithTracer:
    """LangSmith 통합 트레이서"""
    
    def __init__(self, project_name: str = LANGSMITH_PROJECT):
        self.project_name = project_name
        self.client = langsmith_client
    
    def start_trace(self, name: str, metadata: Dict[str, Any] = None) -> Run:
        """트레이스 시작"""
        return self.client.create_run(
            name=name,
            run_type="chain",
            project_name=self.project_name,
            metadata=metadata or {}
        )
    
    def end_trace(
        self,
        run_id: str,
        outputs: Dict[str, Any],
        error: Optional[str] = None
    ):
        """트레이스 종료"""
        self.client.update_run(
            run_id,
            end_time=None,
            outputs=outputs,
            error=error
        )

# 전역 인스턴스
langsmith_tracer = LangSmithTracer()
```

### 2.2 LangChain 통합 설정

```python
# services/llm_service.py
import os
from langchain.callbacks import LangSmithCallbackHandler
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain

# LangSmith 콜백 활성화
langsmith_callback = LangSmithCallbackHandler(
    project_name=os.getenv("LANGSMITH_PROJECT", "englishgreet-dev"),
    tags=["expression-correction"],
    metadata={
        "environment": os.getenv("ENVIRONMENT", "development"),
        "version": "1.0"
    }
)

class ExpressionCorrectionService:
    """LangChain + LangSmith 통합"""
    
    def __init__(self):
        self.llm = ChatOpenAI(
            model="gpt-4",
            temperature=0.3,
            callbacks=[langsmith_callback]
        )
        
        self.prompt = ChatPromptTemplate.from_template("""
        사용자가 영어로 표현한 문장을 검토해주세요.
        
        입력: {user_expression}
        
        다음을 포함한 JSON 형태로 응답하세요:
        {{
            "is_correct": boolean,
            "corrected_expression": "수정된 표현",
            "explanation": "설명",
            "level": "beginner|intermediate|advanced",
            "similar_expressions": ["표현1", "표현2"]
        }}
        """)
        
        self.chain = LLMChain(
            llm=self.llm,
            prompt=self.prompt,
            callbacks=[langsmith_callback]
        )
    
    async def correct_expression(self, expression: str) -> Dict[str, Any]:
        """표현 검사 with LangSmith 트레이싱"""
        result = self.chain.invoke(
            {"user_expression": expression},
            config={
                "metadata": {
                    "user_id": None,  # 나중에 추가
                    "expression_length": len(expression),
                    "language_detected": "English"
                }
            }
        )
        return result

# FastAPI 라우트에서 사용
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/v1/expressions", tags=["expressions"])
service = ExpressionCorrectionService()

class ExpressionRequest(BaseModel):
    expression: str
    user_id: Optional[str] = None

@router.post("/check")
async def check_expression(req: ExpressionRequest):
    """표현 검사 API"""
    try:
        result = await service.correct_expression(req.expression)
        return {
            "success": True,
            "data": result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### 2.3 LangSmith 환경변수 설정

```env
# .env
LANGSMITH_API_KEY=your_langsmith_api_key
LANGSMITH_PROJECT=englishgreet-dev
LANGSMITH_API_URL=https://api.smith.langchain.com

# 로그 레벨 조정
LANGCHAIN_TRACING_V2=true
LANGCHAIN_VERBOSE=false  # 운영 환경에서는 false
```

### 2.4 LangSmith 모니터링 쿼리

```python
# monitoring/langsmith_queries.py
from langsmith import Client
from datetime import datetime, timedelta
from typing import List, Dict

class LangSmithMonitor:
    """LangSmith 메트릭 수집"""
    
    def __init__(self):
        self.client = Client()
        self.project_name = os.getenv("LANGSMITH_PROJECT")
    
    def get_llm_metrics(self, hours: int = 1) -> Dict[str, Any]:
        """최근 N시간 LLM 메트릭"""
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        runs = list(self.client.list_runs(
            project_name=self.project_name,
            filter=f'gt(start_time, "{cutoff.isoformat()}")',
            limit=1000
        ))
        
        total_runs = len(runs)
        failed_runs = len([r for r in runs if r.error])
        successful_runs = total_runs - failed_runs
        
        # 응답 시간 계산
        response_times = []
        for run in runs:
            if run.end_time and run.start_time:
                duration = (run.end_time - run.start_time).total_seconds()
                response_times.append(duration)
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "total_runs": total_runs,
            "successful_runs": successful_runs,
            "failed_runs": failed_runs,
            "success_rate": (successful_runs / total_runs * 100) if total_runs > 0 else 0,
            "avg_response_time": sum(response_times) / len(response_times) if response_times else 0,
            "p95_response_time": sorted(response_times)[int(len(response_times) * 0.95)] if response_times else 0,
            "p99_response_time": sorted(response_times)[int(len(response_times) * 0.99)] if response_times else 0,
        }
    
    def get_token_usage(self, hours: int = 1) -> Dict[str, int]:
        """토큰 사용량"""
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        runs = list(self.client.list_runs(
            project_name=self.project_name,
            filter=f'gt(start_time, "{cutoff.isoformat()}")',
            limit=1000
        ))
        
        total_input_tokens = 0
        total_output_tokens = 0
        
        for run in runs:
            if run.outputs and "token_usage" in run.outputs:
                usage = run.outputs["token_usage"]
                total_input_tokens += usage.get("input_tokens", 0)
                total_output_tokens += usage.get("output_tokens", 0)
        
        return {
            "input_tokens": total_input_tokens,
            "output_tokens": total_output_tokens,
            "total_tokens": total_input_tokens + total_output_tokens
        }
    
    def get_slowest_runs(self, limit: int = 10, hours: int = 1) -> List[Dict]:
        """가장 느린 요청"""
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        runs = sorted(
            self.client.list_runs(
                project_name=self.project_name,
                filter=f'gt(start_time, "{cutoff.isoformat()}")',
                limit=1000
            ),
            key=lambda r: (r.end_time - r.start_time).total_seconds() if r.end_time else 0,
            reverse=True
        )[:limit]
        
        return [
            {
                "run_id": r.id,
                "name": r.name,
                "duration_seconds": (r.end_time - r.start_time).total_seconds(),
                "status": "error" if r.error else "success",
                "timestamp": r.start_time.isoformat()
            }
            for r in runs
        ]
```

---

## 3. Sentry 에러 트래킹

### 3.1 Sentry 초기화 (Python)

```python
# config/sentry_config.py
import os
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration
from sentry_sdk.integrations.asgi import AsgiIntegration
from sentry_sdk.integrations.logging import LoggingIntegration
from sentry_sdk.integrations.threading import ThreadingIntegration

def init_sentry():
    """Sentry 초기화"""
    sentry_sdk.init(
        dsn=os.getenv("SENTRY_DSN"),
        environment=os.getenv("ENVIRONMENT", "development"),
        traces_sample_rate=float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.1")),
        profiles_sample_rate=float(os.getenv("SENTRY_PROFILES_SAMPLE_RATE", "0.1")),
        
        # 통합 설정
        integrations=[
            FastApiIntegration(),
            SqlalchemyIntegration(),
            AsgiIntegration(),
            LoggingIntegration(
                level=logging.INFO,
                event_level=logging.ERROR
            ),
            ThreadingIntegration(propagate_hub=True),
        ],
        
        # 성능 모니터링
        enable_tracing=True,
        
        # 릴리스 정보
        release=os.getenv("APP_VERSION", "1.0.0"),
        
        # 에러 필터링
        before_send=before_send_error,
        
        # 민감 정보 보호
        max_breadcrumbs=50,
        attach_stacktrace=True,
    )

def before_send_error(event, hint):
    """Sentry로 전송할 에러 필터링"""
    
    # 무시할 에러 타입
    ignored_errors = [
        "HTTPException",
        "SkipException",
        "CancelledError"
    ]
    
    exception = event.get("exception")
    if exception:
        exc_type = exception["values"][0]["type"]
        if exc_type in ignored_errors:
            return None
    
    return event
```

### 3.2 FastAPI Sentry 미들웨어

```python
# middleware/sentry_middleware.py
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
import sentry_sdk
from datetime import datetime
import