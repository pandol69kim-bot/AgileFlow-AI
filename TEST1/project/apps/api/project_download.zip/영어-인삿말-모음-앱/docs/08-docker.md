# Docker 설정 - EnglishGreet

기술 스택을 기반으로 멀티스테이지 Dockerfile과 docker-compose.prod.yml을 작성하겠습니다.

## 1. 프론트엔드 Dockerfile (React Native Web)

```dockerfile
# frontend/Dockerfile
# 스테이지 1: 빌드
FROM node:18-alpine AS builder

WORKDIR /app

# 환경 변수
ARG REACT_APP_API_URL
ARG REACT_APP_ENVIRONMENT=production

ENV REACT_APP_API_URL=${REACT_APP_API_URL}
ENV REACT_APP_ENVIRONMENT=${REACT_APP_ENVIRONMENT}
ENV NODE_ENV=production

# 의존성 설치 (캐시 레이어 최적화)
COPY package*.json yarn.lock* ./
RUN yarn install --frozen-lockfile --production=false || npm ci

# 소스 코드 복사
COPY . .

# 빌드
RUN yarn build || npm run build

# 빌드 산출물 최적화 (불필요한 파일 제거)
RUN rm -rf node_modules && \
    yarn install --frozen-lockfile --production=true || npm ci --production

# ---

# 스테이지 2: 프로덕션 런타임
FROM node:18-alpine

WORKDIR /app

# 보안: 루트 사용자 제거
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nextjs -u 1001

# 스테이지 1에서 빌드 산출물 복사
COPY --from=builder --chown=nextjs:nodejs /app/dist ./dist
COPY --from=builder --chown=nextjs:nodejs /app/node_modules ./node_modules
COPY --from=builder --chown=nextjs:nodejs /app/package*.json ./

# 헬스체크
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD node -e "require('http').get('http://localhost:3000/health', (r) => {if (r.statusCode !== 200) throw new Error(r.statusCode)})"

# 사용자 전환
USER nextjs

EXPOSE 3000

CMD ["node", "dist/index.js"]
```

## 2. 백엔드 Dockerfile (Node.js/Express)

```dockerfile
# backend/Dockerfile
# 스테이지 1: 의존성 레이어
FROM node:18-alpine AS dependencies

WORKDIR /app

COPY package*.json yarn.lock* ./

RUN yarn install --frozen-lockfile || npm ci

# ---

# 스테이지 2: 빌드 레이어
FROM dependencies AS builder

WORKDIR /app

# 빌드 의존성 포함
COPY . .

# TypeScript 컴파일
RUN yarn build || npm run build

# ---

# 스테이지 3: 런타임 (프로덕션 의존성만)
FROM node:18-alpine AS runtime

WORKDIR /app

# 보안: 루트 사용자 제거
RUN addgroup -g 1001 -S nodejs && \
    adduser -S app -u 1001

ARG NODE_ENV=production
ENV NODE_ENV=${NODE_ENV}

# 프로덕션 의존성만 설치
COPY package*.json yarn.lock* ./
RUN yarn install --frozen-lockfile --production || npm ci --production

# 빌드 산출물 복사
COPY --from=builder --chown=app:nodejs /app/dist ./dist

# 환경 설정 파일 복사
COPY --chown=app:nodejs .env.production .env

# 헬스체크
HEALTHCHECK --interval=30s --timeout=10s --start-period=10s --retries=3 \
    CMD node -e "require('http').get('http://localhost:3001/health', (r) => {if (r.statusCode !== 200) throw new Error(r.statusCode)})"

# 사용자 전환
USER app

EXPOSE 3001

CMD ["node", "dist/main.js"]
```

## 3. docker-compose.prod.yml

```yaml
# docker-compose.prod.yml
version: '3.9'

services:
  # ================== 프론트엔드 ==================
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
      args:
        REACT_APP_API_URL: ${REACT_APP_API_URL:-https://api.englishgreet.com}
        REACT_APP_ENVIRONMENT: ${REACT_APP_ENVIRONMENT:-production}
    container_name: englishgreet-frontend
    ports:
      - "3000:3000"
    environment:
      NODE_ENV: production
      REACT_APP_API_URL: ${REACT_APP_API_URL:-https://api.englishgreet.com}
    restart: unless-stopped
    networks:
      - englishgreet-network
    depends_on:
      - backend
    # 로깅 설정
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    # 리소스 제한
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M

  # ================== 백엔드 API ==================
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
      args:
        NODE_ENV: production
    container_name: englishgreet-backend
    ports:
      - "3001:3001"
    environment:
      NODE_ENV: production
      DATABASE_URL: ${DATABASE_URL:-postgresql://user:password@postgres:5432/englishgreet_prod}
      REDIS_URL: ${REDIS_URL:-redis://redis:6379/0}
      JWT_SECRET: ${JWT_SECRET}
      JWT_EXPIRATION: ${JWT_EXPIRATION:-7d}
      OPENAI_API_KEY: ${OPENAI_API_KEY}
      AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID}
      AWS_SECRET_ACCESS_KEY: ${AWS_SECRET_ACCESS_KEY}
      AWS_REGION: ${AWS_REGION:-ap-northeast-2}
      AWS_S3_BUCKET: ${AWS_S3_BUCKET}
      CORS_ORIGIN: ${CORS_ORIGIN:-https://englishgreet.com}
      LOG_LEVEL: ${LOG_LEVEL:-info}
    restart: unless-stopped
    networks:
      - englishgreet-network
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./backend/logs:/app/logs
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 1G
        reservations:
          cpus: '1'
          memory: 512M

  # ================== PostgreSQL 데이터베이스 ==================
  postgres:
    image: postgres:15-alpine
    container_name: englishgreet-postgres
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-user}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB:-englishgreet_prod}
      PGDATA: /var/lib/postgresql/data/pgdata
    restart: unless-stopped
    networks:
      - englishgreet-network
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./scripts/init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-user}"]
      interval: 10s
      timeout: 5s
      retries: 5
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 1G
        reservations:
          cpus: '1'
          memory: 512M

  # ================== Redis 캐시 ==================
  redis:
    image: redis:7-alpine
    container_name: englishgreet-redis
    command: >
      redis-server
      --appendonly yes
      --maxmemory 512mb
      --maxmemory-policy allkeys-lru
      --requirepass ${REDIS_PASSWORD}
    restart: unless-stopped
    networks:
      - englishgreet-network
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M

  # ================== Nginx 리버스 프록시 ==================
  nginx:
    image: nginx:1.25-alpine
    container_name: englishgreet-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
      - nginx_cache:/var/cache/nginx
    depends_on:
      - frontend
      - backend
    networks:
      - englishgreet-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M

  # ================== 로깅 & 모니터링 (선택사항) ==================
  prometheus:
    image: prom/prometheus:latest
    container_name: englishgreet-prometheus
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=30d'
    ports:
      - "9090:9090"
    networks:
      - englishgreet-network
    restart: unless-stopped
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M

  grafana:
    image: grafana/grafana:latest
    container_name: englishgreet-grafana
    environment:
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_PASSWORD}
      GF_USERS_ALLOW_SIGN_UP: 'false'
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning:ro
    ports:
      - "3002:3000"
    networks:
      - englishgreet-network
    depends_on:
      - prometheus
    restart: unless-stopped
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M

# ================== 네트워크 정의 ==================
networks:
  englishgreet-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16

# ================== 볼륨 정의 ==================
volumes:
  postgres_data:
    driver: local
  redis_data:
    driver: local
  prometheus_data:
    driver: local
  grafana_data:
    driver: local
  nginx_cache:
    driver: local
```

## 4. Nginx 설정 (nginx/nginx.conf)

```nginx
# nginx/nginx.conf
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 4096;
    use epoll;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    # 성능 최적화
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 20M;

    # Gzip 압축
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript 
               application/json application/javascript application/xml+rss;

    # 속도 제한
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=100r/s;
    limit_req_zone $binary_remote_addr zone=general_limit:10m rate=1000r/s;

    # 업스트림 정의
    upstream frontend {
        least_conn;
        server frontend:3000 max_fails=3 fail_timeout=30s;
    }

    upstream backend {
        least_conn;
        server backend:3001 max_fails=3 fail_timeout=30s;
    }

    # HTTP → HTTPS 리디렉션
    server {
        listen 80;
        server_name _;
        return 301 https://$host$request_uri;
    }

    # HTTPS 서버
    server {
        listen 443 ssl http2;
        server_name englishgreet.com *.englishgreet.com;

        # SSL 인증서
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        
        # SSL 보안 설정
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;
        ssl_prefer_server_ciphers on;
        ssl_session_cache shared:SSL:10m;
        ssl_session_timeout 10m;

        # HSTS
        add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
        add_header X-Frame-Options "DENY" always;
        add_header X-Content-Type-Options "nosn