# EnglishGreet 커스텀 훅 & Zustand 스토어

## 1. Zustand 스토어 설정

### `src/store/authStore.ts`
```typescript
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'premium' | 'admin';
  avatar?: string;
  createdAt: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  logout: () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  devtools(
    persist(
      (set) => ({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,

        setUser: (user) => set({ 
          user, 
          isAuthenticated: !!user,
          error: null 
        }),
        setLoading: (isLoading) => set({ isLoading }),
        setError: (error) => set({ error }),
        logout: () => set({ 
          user: null, 
          isAuthenticated: false, 
          error: null 
        }),
        clearError: () => set({ error: null }),
      }),
      {
        name: 'auth-storage',
        partialize: (state) => ({ 
          user: state.user,
          isAuthenticated: state.isAuthenticated,
        }),
      }
    ),
    { name: 'AuthStore' }
  )
);
```

### `src/store/uiStore.ts`
```typescript
import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

type ThemeMode = 'light' | 'dark' | 'system';

interface UIState {
  theme: ThemeMode;
  sidebarOpen: boolean;
  notificationCount: number;
  
  // Actions
  setTheme: (theme: ThemeMode) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  setNotificationCount: (count: number) => void;
  incrementNotification: () => void;
  clearNotifications: () => void;
}

export const useUIStore = create<UIState>()(
  devtools(
    (set) => ({
      theme: 'system' as ThemeMode,
      sidebarOpen: true,
      notificationCount: 0,

      setTheme: (theme) => set({ theme }),
      toggleSidebar: () => set((state) => ({ 
        sidebarOpen: !state.sidebarOpen 
      })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setNotificationCount: (count) => set({ notificationCount: count }),
      incrementNotification: () => set((state) => ({ 
        notificationCount: state.notificationCount + 1 
      })),
      clearNotifications: () => set({ notificationCount: 0 }),
    }),
    { name: 'UIStore' }
  )
);
```

### `src/store/lessonStore.ts`
```typescript
import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

export interface Lesson {
  id: string;
  title: string;
  category: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  progress: number;
  isFavorite: boolean;
  completedAt?: string;
}

interface LessonFilters {
  search: string;
  category: string;
  level: 'all' | 'beginner' | 'intermediate' | 'advanced';
  favoriteOnly: boolean;
}

interface LessonState {
  lessons: Lesson[];
  filters: LessonFilters;
  selectedLessonId: string | null;
  
  // Actions
  setLessons: (lessons: Lesson[]) => void;
  updateLesson: (id: string, lesson: Partial<Lesson>) => void;
  toggleFavorite: (id: string) => void;
  setFilters: (filters: Partial<LessonFilters>) => void;
  setSelectedLesson: (id: string | null) => void;
  resetFilters: () => void;
}

const defaultFilters: LessonFilters = {
  search: '',
  category: '',
  level: 'all',
  favoriteOnly: false,
};

export const useLessonStore = create<LessonState>()(
  devtools(
    (set) => ({
      lessons: [],
      filters: defaultFilters,
      selectedLessonId: null,

      setLessons: (lessons) => set({ lessons }),
      updateLesson: (id, updatedLesson) =>
        set((state) => ({
          lessons: state.lessons.map((lesson) =>
            lesson.id === id ? { ...lesson, ...updatedLesson } : lesson
          ),
        })),
      toggleFavorite: (id) =>
        set((state) => ({
          lessons: state.lessons.map((lesson) =>
            lesson.id === id
              ? { ...lesson, isFavorite: !lesson.isFavorite }
              : lesson
          ),
        })),
      setFilters: (filters) =>
        set((state) => ({
          filters: { ...state.filters, ...filters },
        })),
      setSelectedLesson: (id) => set({ selectedLessonId: id }),
      resetFilters: () => set({ filters: defaultFilters }),
    }),
    { name: 'LessonStore' }
  )
);
```

---

## 2. TanStack Query 커스텀 훅

### `src/hooks/queries/useAuthQueries.ts`
```typescript
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/store/authStore';
import { authAPI } from '@/api/auth';

export const useLoginMutation = () => {
  const queryClient = useQueryClient();
  const { setUser, setError } = useAuthStore();

  return useMutation({
    mutationFn: (credentials: { email: string; password: string }) =>
      authAPI.login(credentials),
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || '로그인 실패';
      setError(message);
    },
  });
};

export const useSignUpMutation = () => {
  const queryClient = useQueryClient();
  const { setUser, setError } = useAuthStore();

  return useMutation({
    mutationFn: (data: {
      email: string;
      password: string;
      name: string;
    }) => authAPI.signUp(data),
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || '회원가입 실패';
      setError(message);
    },
  });
};

export const useLogoutMutation = () => {
  const queryClient = useQueryClient();
  const { logout } = useAuthStore();

  return useMutation({
    mutationFn: () => authAPI.logout(),
    onSuccess: () => {
      logout();
      queryClient.clear();
    },
  });
};

export const useUserQuery = (enabled: boolean = true) => {
  const { setUser } = useAuthStore();

  return useQuery({
    queryKey: ['user'],
    queryFn: () => authAPI.getUser(),
    enabled,
    staleTime: 1000 * 60 * 5, // 5분
    onSuccess: (data) => setUser(data),
  });
};
```

### `src/hooks/queries/useLessonQueries.ts`
```typescript
import {
  useMutation,
  useQuery,
  useQueryClient,
  useInfiniteQuery,
} from '@tanstack/react-query';
import { useLessonStore } from '@/store/lessonStore';
import { lessonAPI } from '@/api/lesson';

interface GetLessonsParams {
  search?: string;
  category?: string;
  level?: string;
  favoriteOnly?: boolean;
  page?: number;
}

export const useLessonsQuery = (params?: GetLessonsParams) => {
  const { setLessons, filters } = useLessonStore();

  return useQuery({
    queryKey: ['lessons', { ...filters, ...params }],
    queryFn: () =>
      lessonAPI.getLessons({
        ...filters,
        ...params,
      }),
    staleTime: 1000 * 60 * 5,
    onSuccess: (data) => setLessons(data.lessons),
  });
};

export const useLessonsInfiniteQuery = () => {
  const { filters } = useLessonStore();

  return useInfiniteQuery({
    queryKey: ['lessons-infinite', filters],
    queryFn: ({ pageParam = 1 }) =>
      lessonAPI.getLessons({
        ...filters,
        page: pageParam,
      }),
    getNextPageParam: (lastPage) =>
      lastPage.hasMore ? lastPage.nextPage : undefined,
    initialPageParam: 1,
  });
};

export const useLessonDetailQuery = (lessonId: string | null) => {
  return useQuery({
    queryKey: ['lesson', lessonId],
    queryFn: () => lessonAPI.getLessonDetail(lessonId!),
    enabled: !!lessonId,
    staleTime: 1000 * 60 * 10,
  });
};

export const useUpdateProgressMutation = () => {
  const queryClient = useQueryClient();
  const { updateLesson } = useLessonStore();

  return useMutation({
    mutationFn: (data: { lessonId: string; progress: number }) =>
      lessonAPI.updateProgress(data.lessonId, data.progress),
    onMutate: async (data) => {
      // Optimistic update
      updateLesson(data.lessonId, { progress: data.progress });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: ['lesson', variables.lessonId],
      });
    },
  });
};

export const useToggleFavoriteMutation = () => {
  const queryClient = useQueryClient();
  const { toggleFavorite } = useLessonStore();

  return useMutation({
    mutationFn: (lessonId: string) =>
      lessonAPI.toggleFavorite(lessonId),
    onMutate: (lessonId) => {
      toggleFavorite(lessonId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lessons'] });
    },
  });
};

export const useLessonStatisticsQuery = () => {
  return useQuery({
    queryKey: ['lesson-statistics'],
    queryFn: () => lessonAPI.getStatistics(),
    staleTime: 1000 * 60 * 5,
  });
};
```

### `src/hooks/queries/useVocabularyQueries.ts`
```typescript
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { vocabularyAPI } from '@/api/vocabulary';

export interface VocabularyWord {
  id: string;
  word: string;
  pronunciation: string;
  meaning: string;
  example: string;
  difficulty: 'easy' | 'medium' | 'hard';
  learned: boolean;
}

export const useVocabularyQuery = (lessonId: string) => {
  return useQuery({
    queryKey: ['vocabulary', lessonId],
    queryFn: () => vocabularyAPI.getVocabulary(lessonId),
    staleTime: 1000 * 60 * 10,
  });
};

export const useMarkWordLearned = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (wordId: string) =>
      vocabularyAPI.markWordLearned(wordId),
    onSuccess: (_, wordId) => {
      queryClient.invalidateQueries({ queryKey: ['vocabulary'] });
    },
  });
};

export const usePlayAudioMutation = () => {
  return useMutation({
    mutationFn: (word: string) =>
      vocabularyAPI.getAudio(word),
  });
};
```

---

## 3. 커스텀 React 훅

### `src/hooks/useAuth.ts`
```typescript
import { useEffect } from 'react';
import { useAuthStore } from '@/store/authStore';
import { useUserQuery, useLogoutMutation } from './queries/useAuthQueries';

export const useAuth = () => {
  const {
    user,
    isAuthenticated,
    isLoading,
    error,
    setLoading,
    clearError,
  } = useAuthStore();
  
  const { data: userData, isLoading: queryLoading } = useUserQuery(
    isAuthenticated
  );
  const logoutMutation = useLogoutMutation();

  useEffect(() => {
    setLoading(queryLoading);
  }, [queryLoading, setLoading]);

  return {
    user,
    isAuthenticated,
    isLoading: isLoading || queryLoading,
    error,
    clearError,
    logout: logoutMutation.mutate,
    isPremium: user?.role === 'premium',
    isAdmin: user?.role === 'admin',
  };
};
```

### `src/hooks/useTheme.ts`
```typescript
import { useEffect } from 'react';
import { useUIStore } from '@/store/uiStore';

export const useTheme = () => {
  const { theme, setTheme } = useUIStore();

  useEffect(() => {
    // 시스템 테마 감지
    if (theme === 'system') {
      const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const isDark = darkModeQuery.matches;
      
      if (isDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }

      const handleChange = (e: MediaQueryListEvent) => {
        if (e.matches) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      };

      darkModeQuery.addEventListener('change', handleChange);
      return () => darkModeQuery.removeEventListener('change', handleChange);
    }

    // 명시적 테마 설정
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  return {
    theme,
    setTheme,
    isDark: theme === 'dark',
  };
};
```

### `src/hooks/useLessons.ts`
```typescript
import { useMemo } from 'react';
import { useLessonStore, Lesson } from '@/store/lessonStore';
import { useLessonsQuery } from './queries/useLessonQueries';

export const us