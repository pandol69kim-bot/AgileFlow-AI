# EnglishGreet 테스트 전략

## 문서 정보

| 항목 | 내용 |
|------|------|
| **버전** | v1.0 |
| **작성일** | 2025년 1월 |
| **대상** | 개발팀, QA팀 |
| **연관 문서** | EnglishGreet PRD v1.0 |

---

## 목차

1. [테스트 전략 개요](#1-테스트-전략-개요)
2. [테스트 피라미드](#2-테스트-피라미드)
3. [커버리지 목표](#3-커버리지-목표)
4. [도구 선택 근거](#4-도구-선택-근거)
5. [테스트 레이어별 상세 전략](#5-테스트-레이어별-상세-전략)
6. [Acceptance Criteria 매핑](#6-acceptance-criteria-매핑)
7. [CI/CD 파이프라인 통합](#7-cicd-파이프라인-통합)
8. [품질 게이트 & 릴리즈 기준](#8-품질-게이트--릴리즈-기준)

---

## 1. 테스트 전략 개요

### 1.1 테스트 철학

```
"빠른 피드백 루프 + 신뢰할 수 있는 배포"

테스트는 버그를 찾는 행위가 아니라,
제품이 비즈니스 가치를 올바르게 전달하는지
지속적으로 검증하는 엔지니어링 활동이다.
```

### 1.2 핵심 원칙

| 원칙 | 설명 |
|------|------|
| **Fast Feedback** | 단위 테스트 < 100ms, 전체 단위 스위트 < 30초 |
| **Deterministic** | 외부 의존성 격리, 순서 무관 실행 |
| **Maintainable** | 구현이 아닌 동작(behavior) 테스트 |
| **Meaningful** | 커버리지 수치보다 비즈니스 임팩트 우선 |

### 1.3 제품 리스크 분석

PRD Acceptance Criteria 기반 리스크 우선순위:

```
🔴 Critical (테스트 필수)
├── 음성 재생 기능 (North Star Metric 직결)
├── 온보딩 플로우 (활성화율 70%+ 목표)
├── 즐겨찾기 저장/조회 (참여 지표 직결)
└── 검색 기능

🟡 High (테스트 권장)
├── 카테고리 필터링
├── 표현 조회 (세션당 5개+ 목표)
└── 오프라인 캐시

🟢 Medium
├── UI 애니메이션
├── 설정 화면
└── 에러 메시지
```

---

## 2. 테스트 피라미드

### 2.1 피라미드 구조

```
                    ╱‾‾‾‾‾‾‾‾‾‾‾‾╲
                   ╱   E2E Tests   ╲          ← 10%
                  ╱   (Playwright)  ╲
                 ╱‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾╲
                ╱  Integration Tests  ╲        ← 20%
               ╱      (Vitest)         ╲
              ╱‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾╲
             ╱       Unit Tests          ╲     ← 70%
            ╱         (Vitest)            ╲
           ╱‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾╲

   빠름 ◄────────────────────────────────────► 느림
   저비용 ◄──────────────────────────────────► 고비용
   많음 ◄────────────────────────────────────► 적음
```

### 2.2 각 레이어 역할 정의

#### 🔷 Unit Tests (70%) — 기반

```
목적:  개별 함수/컴포넌트의 로직이 올바른가?
범위:  순수 함수, 훅, 유틸리티, 상태 로직
속도:  < 10ms / test
```

| 테스트 대상 | 예시 |
|------------|------|
| 비즈니스 로직 | 검색 필터링 알고리즘, 즐겨찾기 토글 로직 |
| React 컴포넌트 | GreetingCard 렌더링, AudioButton 상태 |
| 커스텀 훅 | `useAudio`, `useFavorites`, `useSearch` |
| 유틸 함수 | 텍스트 정규화, 날짜 포맷, 에러 파싱 |
| 상태 관리 | Zustand/Redux 리듀서, 셀렉터 |

```typescript
// ✅ 좋은 단위 테스트 예시
// src/hooks/__tests__/useFavorites.test.ts

describe('useFavorites', () => {
  it('표현을 즐겨찾기에 추가하면 목록에 포함된다', () => {
    const { result } = renderHook(() => useFavorites())
    
    act(() => {
      result.current.addFavorite({ id: 'greet-001', text: 'Hello!' })
    })
    
    expect(result.current.favorites).toHaveLength(1)
    expect(result.current.isFavorite('greet-001')).toBe(true)
  })

  it('이미 즐겨찾기된 표현을 다시 추가하면 토글(제거)된다', () => {
    const { result } = renderHook(() => useFavorites())
    
    act(() => result.current.addFavorite({ id: 'greet-001', text: 'Hello!' }))
    act(() => result.current.addFavorite({ id: 'greet-001', text: 'Hello!' }))
    
    expect(result.current.favorites).toHaveLength(0)
  })
})
```

#### 🔷 Integration Tests (20%) — 연결

```
목적:  여러 모듈/레이어가 함께 올바르게 동작하는가?
범위:  컴포넌트 + 훅 + API, 페이지 단위 렌더링
속도:  < 500ms / test
```

| 테스트 대상 | 예시 |
|------------|------|
| API 연동 | MSW로 모킹된 API와 컴포넌트 상호작용 |
| 페이지 컴포넌트 | SearchPage의 입력 → 결과 렌더링 플로우 |
| 상태 + UI | 즐겨찾기 추가 → 배지 카운트 업데이트 |
| 에러 핸들링 | API 실패 시 에러 UI 노출 |

```typescript
// ✅ 좋은 통합 테스트 예시
// src/pages/__tests__/SearchPage.integration.test.tsx

describe('SearchPage 통합 테스트', () => {
  beforeEach(() => {
    server.use(
      http.get('/api/greetings/search', ({ request }) => {
        const query = new URL(request.url).searchParams.get('q')
        return HttpResponse.json(mockSearchResults(query))
      })
    )
  })

  it('검색어 입력 시 관련 표현 목록이 렌더링된다', async () => {
    const user = userEvent.setup()
    render(<SearchPage />, { wrapper: AppProviders })
    
    await user.type(screen.getByRole('searchbox'), 'good morning')
    
    await waitFor(() => {
      expect(screen.getAllByTestId('greeting-card')).toHaveLength(3)
    })
  })

  it('API 오류 시 사용자에게 에러 메시지가 노출된다', async () => {
    server.use(
      http.get('/api/greetings/search', () => 
        HttpResponse.error()
      )
    )
    
    const user = userEvent.setup()
    render(<SearchPage />, { wrapper: AppProviders })
    await user.type(screen.getByRole('searchbox'), 'hello')
    
    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent(
        '검색 중 오류가 발생했습니다'
      )
    })
  })
})
```

#### 🔷 E2E Tests (10%) — 사용자 관점

```
목적:  실제 사용자 여정이 처음부터 끝까지 동작하는가?
범위:  Critical User Journey (CUJ) 중심
속도:  < 30초 / test
```

| 테스트 대상 | 연관 AC |
|------------|---------|
| 온보딩 완료 플로우 | 활성화율 70%+ |
| 음성 재생 Happy Path | North Star Metric |
| 즐겨찾기 저장 → 목록 확인 | 참여 지표 |
| 검색 → 결과 → 재생 | 세션당 조회 5개+ |

---

## 3. 커버리지 목표

### 3.1 전체 목표: 80%+

```
📊 커버리지 목표 (Line Coverage 기준)

전체 평균        : 80% 이상 (Hard Gate)
비즈니스 로직    : 90% 이상 (Critical Path)
UI 컴포넌트      : 75% 이상
유틸리티 함수    : 95% 이상
API 클라이언트   : 85% 이상
```

### 3.2 80% 목표 선정 근거

```
✅ 80% 선정 이유

1. ROI 최적점
   - 80% → 100%: 나머지 20%는 테스트 작성 비용 대비
     버그 감소 효과가 기하급수적으로 낮아짐
   - 80% 달성으로 핵심 경로의 결함 90%+ 조기 탐지 가능

2. 스타트업 속도 고려
   - EnglishGreet MVP 4주 일정에서
     100% 커버리지 추구 시 개발 속도 40%+ 저하 예상
   - 80%는 품질과 속도의 균형점

3. 제외 항목의 명시적 관리
   ┌─────────────────────────────────────┐
   │ 커버리지 제외 항목 (v8ignore)       │
   │  - 환경 설정 파일 (*.config.ts)     │
   │  - 타입 정의 파일 (*.d.ts)          │
   │  - 스토리북 파일 (*.stories.tsx)    │
   │  - 목/픽스처 파일 (*.mock.ts)       │
   └─────────────────────────────────────┘
```

### 3.3 커버리지 측정 설정

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'lcov', 'json-summary'],
      
      // 80% 강제 게이트
      thresholds: {
        lines: 80,
        functions: 80,
        branches: 75,    // 분기는 5% 여유 (삼항연산자 패턴)
        statements: 80,
      },
      
      // 제외 경로
      exclude: [
        'node_modules/**',
        'src/**/*.d.ts',
        'src/**/*.config.ts',
        'src/**/*.stories.tsx',
        'src/**/*.mock.ts',
        'src/types/**',
      ],
      
      include: [
        'src/**/*.ts',
        'src/**/*.tsx',
      ],
    },
  },
})
```

### 3.4 커버리지 모니터링

```
📈 주간 커버리지 트렌드 추적

Week 1 목표: 60% (초기 셋업)
Week 2 목표: 70% (핵심 로직)
Week 3 목표: 78% (컴포넌트)
Week 4 목표: 80%+ (안정화)

→ PR마다 커버리지 diff 리포트 자동 생성
→ 커버리지 감소 PR은 리뷰어 승인 필수
```

---

## 4. 도구 선택 근거

### 4.1 Vitest 선택 근거

#### 비교 분석

| 기준 | Vitest | Jest | Mocha |
|------|--------|------|-------|
| **Vite 프로젝트 호환성** | ✅ Native | ⚠️ 별도 설정 | ⚠️ 별도 설정 |
| **ESM 지원** | ✅ 완전 지원 | ⚠️ 부분 지원 | ✅ 지원 |
| **설정 복잡도** | 낮음 | 중간 | 높음 |
| **실행 속도** | ⚡ 최고 | 보통 | 보통 |
| **TypeScript** | ✅ 네이티브 | ⚠️ 트랜스파일 | ⚠️ 별도 설치 |
| **HMR 테스트** | ✅ 지원 | ❌ | ❌ |
| **Watch 모드** | ⚡ 빠름 | 보통 | 보통 |
| **