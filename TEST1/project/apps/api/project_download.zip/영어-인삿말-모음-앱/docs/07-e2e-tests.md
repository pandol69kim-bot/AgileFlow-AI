# EnglishGreet E2E 테스트 코드 (Playwright)

## 프로젝트 구조

```
tests/
├── e2e/
│   ├── scenarios/
│   │   ├── 01.onboarding.spec.ts
│   │   ├── 02.search-and-play.spec.ts
│   │   ├── 03.favorites.spec.ts
│   │   ├── 04.category-browse.spec.ts
│   │   └── 05.premium-upgrade.spec.ts
│   ├── fixtures/
│   │   └── test-data.ts
│   ├── pages/
│   │   ├── OnboardingPage.ts
│   │   ├── HomePage.ts
│   │   ├── SearchPage.ts
│   │   ├── PlayerPage.ts
│   │   ├── FavoritesPage.ts
│   │   └── PremiumPage.ts
│   └── helpers/
│       └── auth.helper.ts
├── playwright.config.ts
└── global-setup.ts
```

---

## playwright.config.ts

```typescript
import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 2 : undefined,
  timeout: 30_000,
  expect: {
    timeout: 5_000,
  },

  reporter: [
    ["html", { outputFolder: "playwright-report", open: "never" }],
    ["list"],
    [
      "json",
      {
        outputFile: "test-results/results.json",
      },
    ],
  ],

  use: {
    baseURL: process.env.BASE_URL || "http://localhost:3000",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
    actionTimeout: 10_000,
    navigationTimeout: 15_000,
    locale: "ko-KR",
    timezoneId: "Asia/Seoul",
  },

  projects: [
    // ── Setup: 인증 상태 사전 준비 ──
    {
      name: "setup",
      testMatch: /global-setup\.ts/,
    },

    // ── Desktop Chrome (주 테스트 환경) ──
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        storageState: "tests/e2e/.auth/user.json",
      },
      dependencies: ["setup"],
    },

    // ── Mobile Safari (모바일 UX 검증) ──
    {
      name: "mobile-safari",
      use: {
        ...devices["iPhone 14"],
        storageState: "tests/e2e/.auth/user.json",
      },
      dependencies: ["setup"],
    },

    // ── 비로그인 전용 테스트 (온보딩 등) ──
    {
      name: "no-auth",
      use: {
        ...devices["Desktop Chrome"],
      },
      testMatch: /onboarding\.spec\.ts/,
    },
  ],
});
```

---

## global-setup.ts

```typescript
import { chromium, FullConfig } from "@playwright/test";
import path from "path";
import fs from "fs";

const AUTH_FILE = "tests/e2e/.auth/user.json";

async function globalSetup(config: FullConfig) {
  // auth 디렉토리 생성
  const authDir = path.dirname(AUTH_FILE);
  if (!fs.existsSync(authDir)) {
    fs.mkdirSync(authDir, { recursive: true });
  }

  const { baseURL } = config.projects[0].use;
  const browser = await chromium.launch();
  const page = await browser.newPage();

  try {
    await page.goto(`${baseURL}/login`);

    // 테스트용 계정으로 로그인
    await page.getByLabel("이메일").fill(process.env.TEST_USER_EMAIL!);
    await page.getByLabel("비밀번호").fill(process.env.TEST_USER_PASSWORD!);
    await page.getByRole("button", { name: "로그인" }).click();

    // 로그인 성공 확인
    await page.waitForURL("**/home");

    // 인증 상태 저장
    await page.context().storageState({ path: AUTH_FILE });

    console.log("✅ Global setup: 인증 상태 저장 완료");
  } finally {
    await browser.close();
  }
}

export default globalSetup;
```

---

## tests/e2e/fixtures/test-data.ts

```typescript
export const TEST_USER = {
  email: process.env.TEST_USER_EMAIL || "test@englishgreet.com",
  password: process.env.TEST_USER_PASSWORD || "Test1234!",
  name: "테스트유저",
} as const;

export const GREETINGS = {
  basic: {
    keyword: "Hello",
    expression: "Hello! How are you doing today?",
    korean: "안녕하세요! 오늘 어떻게 지내세요?",
    category: "일상",
  },
  business: {
    keyword: "Nice to meet you",
    expression: "Nice to meet you. I look forward to working with you.",
    korean: "만나서 반갑습니다. 함께 일하게 되어 기대됩니다.",
    category: "비즈니스",
  },
  travel: {
    keyword: "Excuse me",
    expression: "Excuse me, could you help me find the station?",
    korean: "실례합니다, 역을 찾는 것을 도와주실 수 있나요?",
    category: "여행",
  },
} as const;

export const CATEGORIES = [
  { id: "daily", label: "일상", icon: "👋" },
  { id: "business", label: "비즈니스", icon: "💼" },
  { id: "travel", label: "여행", icon: "✈️" },
  { id: "formal", label: "격식체", icon: "🎩" },
  { id: "casual", label: "캐주얼", icon: "😊" },
] as const;

export const ONBOARDING_STEPS = [
  {
    step: 1,
    title: "상황에 맞는 영어 인삿말",
    description: "일상, 비즈니스, 여행 등 상황별 표현",
  },
  {
    step: 2,
    title: "네이티브 발음으로 듣기",
    description: "원어민 발음으로 정확하게",
  },
  {
    step: 3,
    title: "즐겨찾기로 나만의 표현집",
    description: "자주 쓰는 표현을 저장하세요",
  },
] as const;
```

---

## tests/e2e/pages/OnboardingPage.ts

```typescript
import { Page, Locator, expect } from "@playwright/test";

export class OnboardingPage {
  readonly page: Page;

  // 온보딩 슬라이드 요소
  readonly slideContainer: Locator;
  readonly slideTitle: Locator;
  readonly slideDescription: Locator;
  readonly nextButton: Locator;
  readonly skipButton: Locator;
  readonly startButton: Locator;
  readonly progressDots: Locator;
  readonly currentDot: Locator;

  constructor(page: Page) {
    this.page = page;
    this.slideContainer = page.getByTestId("onboarding-slide");
    this.slideTitle = page.getByTestId("slide-title");
    this.slideDescription = page.getByTestId("slide-description");
    this.nextButton = page.getByRole("button", { name: "다음" });
    this.skipButton = page.getByRole("button", { name: "건너뛰기" });
    this.startButton = page.getByRole("button", { name: "시작하기" });
    this.progressDots = page.getByTestId("progress-dot");
    this.currentDot = page.getByTestId("progress-dot-active");
  }

  async goto() {
    await this.page.goto("/onboarding");
    await this.slideContainer.waitFor({ state: "visible" });
  }

  async goToNextSlide() {
    await this.nextButton.click();
    // 슬라이드 전환 애니메이션 대기
    await this.page.waitForTimeout(300);
  }

  async skipOnboarding() {
    await this.skipButton.click();
  }

  async completeOnboarding() {
    // 모든 슬라이드 순차 진행
    const dotCount = await this.progressDots.count();
    for (let i = 0; i < dotCount - 1; i++) {
      await this.goToNextSlide();
    }
    await this.startButton.click();
  }

  async getCurrentStepIndex(): Promise<number> {
    const dots = await this.progressDots.all();
    for (let i = 0; i < dots.length; i++) {
      const isActive = await dots[i].getAttribute("data-active");
      if (isActive === "true") return i;
    }
    return 0;
  }

  async verifyStep(stepIndex: number, title: string) {
    await expect(this.slideTitle).toContainText(title);
    const activeDotIndex = await this.getCurrentStepIndex();
    expect(activeDotIndex).toBe(stepIndex);
  }
}
```

---

## tests/e2e/pages/HomePage.ts

```typescript
import { Page, Locator, expect } from "@playwright/test";

export class HomePage {
  readonly page: Page;

  readonly searchInput: Locator;
  readonly categoryList: Locator;
  readonly greetingCards: Locator;
  readonly featuredSection: Locator;
  readonly bottomNav: Locator;
  readonly navHome: Locator;
  readonly navSearch: Locator;
  readonly navFavorites: Locator;
  readonly navProfile: Locator;
  readonly todayExpression: Locator;
  readonly premiumBanner: Locator;

  constructor(page: Page) {
    this.page = page;
    this.searchInput = page.getByRole("searchbox", { name: "표현 검색" });
    this.categoryList = page.getByTestId("category-list");
    this.greetingCards = page.getByTestId("greeting-card");
    this.featuredSection = page.getByTestId("featured-section");
    this.bottomNav = page.getByRole("navigation", { name: "하단 네비게이션" });
    this.navHome = page.getByRole("link", { name: "홈" });
    this.navSearch = page.getByRole("link", { name: "검색" });
    this.navFavorites = page.getByRole("link", { name: "즐겨찾기" });
    this.navProfile = page.getByRole("link", { name: "프로필" });
    this.todayExpression = page.getByTestId("today-expression");
    this.premiumBanner = page.getByTestId("premium-banner");
  }

  async goto() {
    await this.page.goto("/home");
    await this.greetingCards.first().waitFor({ state: "visible" });
  }

  async selectCategory(categoryLabel: string) {
    await this.categoryList
      .getByRole("button", { name: categoryLabel })
      .click();
    await this.page.waitForResponse(
      (res) => res.url().includes("/api/greetings") && res.status() === 200
    );
  }

  async clickFirstGreetingCard() {
    await this.greetingCards.first().click();
  }

  async getGreetingCardCount(): Promise<number> {
    return await this.greetingCards.count();
  }
}
```

---

## tests/e2e/pages/PlayerPage.ts

```typescript
import { Page, Locator, expect } from "@playwright/test";

export class PlayerPage {
  readonly page: Page;

  readonly expressionText: Locator;
  readonly translationText: Locator;
  readonly playButton: Locator;
  readonly favoriteButton: Locator;
  readonly shareButton: Locator;
  readonly backButton: Locator;
  readonly audioProgressBar: Locator;
  readonly speedSelector: Locator;
  readonly repeatButton: Locator;
  readonly phoneticsText: Locator;
  readonly exampleSentences: Locator;
  readonly relatedExpressions: Locator;

  constructor(page: Page) {
    this.page = page;
    this.expressionText = page.getByTestId("expression-text");
    this.translationText = page.getByTestId("translation-text");
    this.playButton = page.getByRole("button", { name: /재생|일시정지/ });
    this.favoriteButton = page.getByRole("button", { name: /즐겨찾기|저장됨/ });
    this.shareButton = page.getByRole("button", { name: "공유" });
    this.backButton = page.getByRole("button", { name: "뒤로" });
    this.audioProgressBar = page.getByRole("progressbar", { name: "오디오 진행" });
    this.speedSelector = page.getByTestId("speed-selector");
    this.repeatButton = page.getByRole("button", { name: "반복" });
    this.phoneticsText = page.getByTestId("phonetics");
    this.exampleSentences = page.getByTestId("example-sentence");
    this.relatedExpressions = page.getByTestId("related-expression");
  }

  async waitForLoad() {
    await this.expressionText.waitFor({ state: "visible" });
    await this.playButton.waitFor({ state: "visible" });
  }

  async playAudio() {
    await this.playButton.click();
  }

  async pauseAudio() {
    // 재생 중일 때 버튼 텍스트가 "일시정지"로 변경됨
    await this.page
      .getByRole("button", { name: "일시정지" })
      .click();
  }

  async toggleFavorite() {
    await this.favoriteButton.click();
  }

  async isFavorited(): Promise<boolean> {
    const label = await this.favoriteButton.getAttribute("aria-label");
    return label === "저장됨";
  }

  async setPlaybackSpeed(speed: "0.5x" | "0.75x" | "1x" | "1.5x" | "2x") {
    await this.speedSelector.selectOption(speed);
  }

  async waitForAudioToPlay() {
    // 오디오 진행 바가 업데이트되는 것으로 재생 확인
    await expect(this.audioProgressBar).not.toHaveAttribute("value", "0", {
      timeout: 3_000,
    });
  }
}
```

---

## tests/e2e/pages/SearchPage.ts

```typescript
import { Page, Locator, expect }