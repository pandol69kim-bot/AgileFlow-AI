# Fastify API 라우트 코드 (EnglishGreet)

## 1. 프로젝트 구조

```
src/
├── routes/
│   ├── auth.ts
│   ├── greetings.ts
│   ├── favorites.ts
│   └── health.ts
├── middleware/
│   ├── auth.ts
│   └── errorHandler.ts
├── schemas/
│   ├── auth.ts
│   ├── greeting.ts
│   └── common.ts
├── services/
│   ├── authService.ts
│   ├── greetingService.ts
│   └── userService.ts
├── types/
│   └── index.ts
└── app.ts
```

---

## 2. 타입 정의 (`src/types/index.ts`)

```typescript
export interface User {
  id: string;
  email: string;
  password: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Greeting {
  id: string;
  korean: string;
  english: string;
  pronunciation: string;
  category: 'casual' | 'business' | 'travel' | 'formal';
  audioUrl: string;
  difficulty: 'easy' | 'medium' | 'hard';
  createdAt: Date;
}

export interface Favorite {
  id: string;
  userId: string;
  greetingId: string;
  createdAt: Date;
}

export interface JwtPayload {
  userId: string;
  email: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };
  timestamp: string;
}

export interface AuthRequest {
  email: string;
  password: string;
}

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}
```

---

## 3. Zod 스키마 (`src/schemas/`)

### `src/schemas/auth.ts`

```typescript
import { z } from 'zod';

export const registerSchema = z.object({
  email: z
    .string()
    .email('유효한 이메일을 입력해주세요')
    .min(5)
    .max(255),
  password: z
    .string()
    .min(8, '비밀번호는 최소 8자 이상이어야 합니다')
    .regex(/[A-Z]/, '대문자를 포함해야 합니다')
    .regex(/[0-9]/, '숫자를 포함해야 합니다')
    .regex(/[!@#$%^&*]/, '특수문자를 포함해야 합니다'),
  passwordConfirm: z.string(),
}).refine((data) => data.password === data.passwordConfirm, {
  message: '비밀번호가 일치하지 않습니다',
  path: ['passwordConfirm'],
});

export const loginSchema = z.object({
  email: z.string().email('유효한 이메일을 입력해주세요'),
  password: z.string().min(1, '비밀번호를 입력해주세요'),
});

export const refreshTokenSchema = z.object({
  refreshToken: z.string().min(1, 'refreshToken이 필요합니다'),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type RefreshTokenInput = z.infer<typeof refreshTokenSchema>;
```

### `src/schemas/greeting.ts`

```typescript
import { z } from 'zod';

export const greetingQuerySchema = z.object({
  category: z
    .enum(['casual', 'business', 'travel', 'formal'])
    .optional(),
  difficulty: z.enum(['easy', 'medium', 'hard']).optional(),
  search: z.string().max(100).optional(),
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export const addFavoriteSchema = z.object({
  greetingId: z.string().uuid('유효한 ID를 입력해주세요'),
});

export const removeFavoriteSchema = z.object({
  greetingId: z.string().uuid('유효한 ID를 입력해주세요'),
});

export type GreetingQuery = z.infer<typeof greetingQuerySchema>;
export type AddFavoriteInput = z.infer<typeof addFavoriteSchema>;
export type RemoveFavoriteInput = z.infer<typeof removeFavoriteSchema>;
```

### `src/schemas/common.ts`

```typescript
import { z } from 'zod';

export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export const uuidSchema = z.string().uuid('유효한 UUID를 입력해주세요');

export type PaginationInput = z.infer<typeof paginationSchema>;
```

---

## 4. 인증 미들웨어 (`src/middleware/auth.ts`)

```typescript
import { FastifyRequest, FastifyReply } from 'fastify';
import jwt from '@fastify/jwt';
import { JwtPayload } from '../types';

export const jwtSecret = process.env.JWT_SECRET || 'your-super-secret-key';

export const verifyJwt = async (
  request: FastifyRequest,
  reply: FastifyReply
) => {
  try {
    await request.jwtVerify();
  } catch (error) {
    reply.code(401).send({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: '인증 토큰이 유효하지 않습니다',
      },
      timestamp: new Date().toISOString(),
    });
  }
};

export const extractUserFromToken = (
  request: FastifyRequest
): JwtPayload => {
  return request.user as JwtPayload;
};

// 선택적 인증 (로그인하지 않은 사용자도 접근 가능)
export const optionalAuth = async (
  request: FastifyRequest,
  reply: FastifyReply
) => {
  try {
    await request.jwtVerify();
  } catch (error) {
    // 인증 실패해도 계속 진행 (request.user는 undefined)
  }
};
```

---

## 5. 에러 처리 미들웨어 (`src/middleware/errorHandler.ts`)

```typescript
import { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';

export class AppError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const errorHandler = (
  error: FastifyError | AppError | ZodError | Error,
  request: FastifyRequest,
  reply: FastifyReply
) => {
  const timestamp = new Date().toISOString();

  // Zod 검증 에러
  if (error instanceof ZodError) {
    return reply.code(400).send({
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: '입력 데이터 검증 실패',
        details: error.errors.map((e) => ({
          path: e.path.join('.'),
          message: e.message,
        })),
      },
      timestamp,
    });
  }

  // 커스텀 앱 에러
  if (error instanceof AppError) {
    return reply.code(error.statusCode).send({
      success: false,
      error: {
        code: error.code,
        message: error.message,
      },
      timestamp,
    });
  }

  // Fastify 내장 에러
  if ('statusCode' in error) {
    return reply.code(error.statusCode).send({
      success: false,
      error: {
        code: 'FASTIFY_ERROR',
        message: error.message || '서버 오류가 발생했습니다',
      },
      timestamp,
    });
  }

  // 예상치 못한 에러
  console.error('Unexpected error:', error);
  return reply.code(500).send({
    success: false,
    error: {
      code: 'INTERNAL_SERVER_ERROR',
      message: '서버 오류가 발생했습니다',
    },
    timestamp,
  });
};
```

---

## 6. 서비스 레이어 (`src/services/`)

### `src/services/authService.ts`

```typescript
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { jwtSecret } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';
import { User, JwtPayload, TokenResponse } from '../types';

// 임시 메모리 저장소 (실제로는 DB 사용)
const users: Map<string, User> = new Map();

export class AuthService {
  async register(email: string, password: string): Promise<User> {
    // 중복 이메일 확인
    const existingUser = Array.from(users.values()).find(
      (u) => u.email === email
    );
    if (existingUser) {
      throw new AppError(409, 'EMAIL_ALREADY_EXISTS', '이미 등록된 이메일입니다');
    }

    // 비밀번호 해시
    const hashedPassword = await bcrypt.hash(password, 10);

    const user: User = {
      id: crypto.randomUUID(),
      email,
      password: hashedPassword,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    users.set(user.id, user);
    return { ...user, password: undefined } as any;
  }

  async login(email: string, password: string): Promise<TokenResponse> {
    // 사용자 조회
    const user = Array.from(users.values()).find((u) => u.email === email);
    if (!user) {
      throw new AppError(401, 'INVALID_CREDENTIALS', '이메일 또는 비밀번호가 틀렸습니다');
    }

    // 비밀번호 검증
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new AppError(401, 'INVALID_CREDENTIALS', '이메일 또는 비밀번호가 틀렸습니다');
    }

    // 토큰 생성
    const payload: JwtPayload = {
      userId: user.id,
      email: user.email,
    };

    const accessToken = jwt.sign(payload, jwtSecret, {
      expiresIn: '1h',
    });

    const refreshToken = jwt.sign(payload, jwtSecret, {
      expiresIn: '7d',
    });

    return {
      accessToken,
      refreshToken,
      expiresIn: 3600, // 1시간 (초 단위)
    };
  }

  async refreshToken(refreshToken: string): Promise<TokenResponse> {
    try {
      const payload = jwt.verify(refreshToken, jwtSecret) as JwtPayload;

      const newAccessToken = jwt.sign(
        { userId: payload.userId, email: payload.email },
        jwtSecret,
        { expiresIn: '1h' }
      );

      return {
        accessToken: newAccessToken,
        refreshToken, // 재사용 가능
        expiresIn: 3600,
      };
    } catch (error) {
      throw new AppError(401, 'INVALID_REFRESH_TOKEN', 'Refresh token이 유효하지 않습니다');
    }
  }

  getUserById(userId: string): User | null {
    return users.get(userId) || null;
  }
}

export const authService = new AuthService();
```

### `src/services/greetingService.ts`

```typescript
import { Greeting, Favorite } from '../types';
import { GreetingQuery } from '../schemas/greeting';
import { AppError } from '../middleware/errorHandler';

// 임시 메모리 저장소
const greetings: Map<string, Greeting> = new Map();
const favorites: Map<string, Favorite> = new Map();

// 샘플 데이터
const initializeSampleData = () => {
  if (greetings.size === 0) {
    const sampleGreetings: Greeting[] = [
      {
        id: crypto.randomUUID(),
        korean: '안녕하세요',
        english: 'Hello',
        pronunciation: 'hə-ˈlō',
        category: 'formal',
        audioUrl: 'https://cdn.example.com/hello.mp3',
        difficulty: 'easy',
        createdAt: new Date(),
      },
      {
        id: crypto.randomUUID(),
        korean: '안녕',
        english: "What's up?",
        pronunciation: "wɑts ˈəp",
        category: 'casual',
        audioUrl: 'https://cdn.example.com/whatsup.mp3',
        difficulty: 'easy',
        createdAt: new Date(),
      },
      {
        id: crypto.randomUUID(),
        korean: '만나서 반갑습니다',
        english: 'Nice to meet you',
        pronunciation: 'nīs tu ˈmēt yo͞o',
        category: 'business',
        audioUrl: 'https://cdn.example.com/nicetomeetyou.mp3',
        difficulty: 'medium',
        createdAt: new Date(),
      },
    ];

    sampleGreetings.forEach((g) => greetings.set(g.id, g));
  }
};

initializeSampleData();

export class GreetingService {
  async getGreetings(params: GreetingQuery) {
    let result = Array.from(greetings.values());

    // 카테고리 필터
    if (params.category) {
      result = result.filter((g) => g.category === params.category);
    }

    // 난이도 필터
    if (params.difficulty) {
      result = result.filter((g) => g.difficulty === params.difficulty);
    }

    // 검색어 필터
    if (params.search) {
      const searchLower = params.search.toLowerCase();
      result = result.filter(
        (g) =>
          g.korean.toLowerCase().includes(searchLower) ||
          g.english.toLowerCase().includes(searchLower)
      );
    }

    // 정렬
    result.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    // 페이징
    const total = result.length;
    const page = params.page - 1;
    const start = page * params.limit;
    const end = start + params.limit;

    return {
      data: result.slice(start, end),
      pagination: {
        page: params.page,
        limit: params.limit,
        total,
        pages: Math.ceil(total / params.limit),
      },