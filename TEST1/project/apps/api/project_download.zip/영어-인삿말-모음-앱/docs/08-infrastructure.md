# EnglishGreet 인프라 구성 문서

**문서 버전**: v2.0  
**작성일**: 2025년 1월  
**작성자**: DevOps & Infrastructure Team  
**상태**: Final  
**대상 독자**: DevOps팀, CTO, 보안팀, 개발 리더

---

## 목차

1. [인프라 아키텍처 개요](#1-인프라-아키텍처-개요)
2. [클라우드 아키텍처 (Vercel + AWS)](#2-클라우드-아키텍처-vercel--aws)
3. [환경 구성](#3-환경-구성)
4. [스케일링 정책](#4-스케일링-정책)
5. [백업 정책](#5-백업-정책)
6. [재해 복구 (DR) 계획](#6-재해-복구-dr-계획)
7. [모니터링 & 알림](#7-모니터링--알림)
8. [보안 정책](#8-보안-정책)
9. [비용 최적화](#9-비용-최적화)
10. [체크리스트](#10-체크리스트)

---

## 1. 인프라 아키텍처 개요

### 1.1 아키텍처 원칙

```
┌─────────────────────────────────────────────────────────┐
│ EnglishGreet 인프라 설계 철학                             │
│                                                         │
│ ✓ Multi-Tier: 프론트엔드/백엔드/DB 계층 분리             │
│ ✓ Global CDN: 음성파일·이미지 글로벌 배포               │
│ ✓ Serverless-First: 초기 비용 최소화                    │
│ ✓ High Availability: 99.9% SLA 목표                     │
│ ✓ Disaster Recovery: RTO 1시간, RPO 15분                │
└─────────────────────────────────────────────────────────┘
```

### 1.2 예상 인프라 규모

| 단계 | 시점 | MAU | 월 예상 인프라 비용 |
|------|------|-----|-----------------|
| **Phase 1** | 0~3개월 | 1K~10K | $500~$1,500 |
| **Phase 2** | 3~6개월 | 10K~50K | $2,000~$5,000 |
| **Phase 3** | 6~12개월 | 50K~100K | $5,000~$15,000 |

---

## 2. 클라우드 아키텍처 (Vercel + AWS)

### 2.1 고수준 아키텍처 다이어그램

```
┌────────────────────────────────────────────────────────────────┐
│                        사용자 (전세계)                          │
└────────────────────────────────────────────────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    ▼                   ▼
          ┌──────────────────┐  ┌──────────────────┐
          │  Vercel Edge     │  │  CloudFlare CDN  │
          │  (Next.js 배포)  │  │  (정적 자산)     │
          └──────────────────┘  └──────────────────┘
                    │                   │
                    └─────────┬─────────┘
                              ▼
          ┌────────────────────────────────────┐
          │  API Gateway + ALB                 │
          │  (AWS, us-east-1)                  │
          └────────────────────────────────────┘
                    │
        ┌───────────┼───────────┬──────────────┐
        ▼           ▼           ▼              ▼
   ┌─────────┐ ┌─────────┐ ┌────────┐  ┌──────────┐
   │ Lambda  │ │  ECS    │ │ RDS    │  │   S3    │
   │ (API)   │ │ (WebSocket)│(PostgreSQL)│(Media) │
   └─────────┘ └─────────┘ └────────┘  └──────────┘
        │           │           │            │
        └───────────┼───────────┴────────────┘
                    ▼
        ┌────────────────────────┐
        │  ElastiCache (Redis)   │
        │  (Session, 캐싱)       │
        └────────────────────────┘
```

### 2.2 Vercel 배포 구성

```yaml
# vercel.json
{
  "buildCommand": "npm run build",
  "outputDirectory": ".next",
  "installCommand": "npm install",
  "env": {
    "NEXT_PUBLIC_API_BASE": "@api_base_url",
    "NEXT_PUBLIC_ANALYTICS_ID": "@analytics_id"
  },
  "regions": ["iad1"],  # 미국 동부 (AWS 와 동일 리전)
  "functions": {
    "api/**": {
      "maxDuration": 60,
      "memory": 3008
    }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        }
      ]
    }
  ],
  "rewrites": [
    {
      "source": "/api/:path*",
      "destination": "https://api.englishgreet.com/:path*"
    }
  ]
}
```

### 2.3 AWS 인프라 구성

#### 2.3.1 네트워크 (VPC)

```
Region: us-east-1

VPC: 10.0.0.0/16
  │
  ├─ Public Subnet AZ-A: 10.0.1.0/24
  │   └─ NAT Gateway
  │   └─ Internet Gateway
  │
  ├─ Public Subnet AZ-B: 10.0.2.0/24
  │   └─ NAT Gateway
  │   └─ Internet Gateway
  │
  ├─ Private Subnet AZ-A: 10.0.10.0/24
  │   ├─ ECS Task (API Container)
  │   └─ Lambda
  │
  ├─ Private Subnet AZ-B: 10.0.11.0/24
  │   ├─ ECS Task (API Container)
  │   └─ Lambda
  │
  └─ Database Subnet AZ-A, B: 10.0.20.0/24, 10.0.21.0/24
      └─ RDS PostgreSQL (Multi-AZ)
```

#### 2.3.2 Application Load Balancer (ALB)

```yaml
# AWS EC2 > Load Balancers
Name: englishgreet-alb
Scheme: internet-facing
Subnets: Public Subnet AZ-A, AZ-B
Security Groups:
  - Allow HTTP (80) from 0.0.0.0/0
  - Allow HTTPS (443) from 0.0.0.0/0
  - Allow port 3000 from 10.0.0.0/16 (ECS)

Listeners:
  - Port 80 → Redirect to 443
  - Port 443 → Target Group: ECS Cluster

Target Group:
  Name: englishgreet-ecs-tg
  Protocol: HTTP
  Port: 3000
  Health Check:
    Path: /api/health
    Interval: 30s
    Timeout: 5s
    Healthy Threshold: 2
    Unhealthy Threshold: 3
```

#### 2.3.3 컴퓨팅 (ECS + Lambda)

**ECS 클러스터 (API 서버)**
```yaml
# AWS ECS > Clusters
Cluster Name: englishgreet-api-prod

Capacity Provider: FARGATE_SPOT + FARGATE (7:3 비율)
  # FARGATE_SPOT: 비용 절감 (70% 할인)
  # FARGATE: 안정성 보장

Service: englishgreet-api-service
  Desired Count: 2
  Min: 2, Max: 10
  
Task Definition: englishgreet-api-task
  CPU: 512
  Memory: 1024
  Container:
    Image: 123456789.dkr.ecr.us-east-1.amazonaws.com/englishgreet-api:latest
    Port: 3000
    Environment:
      - DATABASE_URL: ${RDS_ENDPOINT}
      - REDIS_URL: ${ELASTICACHE_ENDPOINT}
      - JWT_SECRET: ${SECRETS_MANAGER_JWT}
    Log Driver: awslogs
      Log Group: /ecs/englishgreet-api
```

**Lambda (경량 작업)**
```yaml
# AWS Lambda
Function 1: englishgreet-tts-processor
  Runtime: Python 3.11
  Memory: 3008 MB
  Timeout: 300s (5분)
  Trigger: SQS Queue (tts-jobs)
  Environment:
    - AWS_POLLY_VOICE_ID: Joanna
    - OUTPUT_BUCKET: englishgreet-audio-output
  Policy: S3, Polly, SQS, CloudWatch Logs

Function 2: englishgreet-scheduler
  Runtime: Node.js 20
  Memory: 256 MB
  Timeout: 60s
  Trigger: EventBridge (cron: 0 0 * * ? *)
  Role: DynamoDB, SNS, CloudWatch
```

#### 2.3.4 데이터베이스 (RDS)

```yaml
# AWS RDS > Create Database
Engine: PostgreSQL 15.3
Instance Class: db.t3.medium
Storage: 100 GB (gp3)
Multi-AZ: true
Backup Retention: 30 days
Preferred Backup Window: 03:00-04:00 UTC

Enhanced Monitoring:
  Enabled: true
  Interval: 60 seconds
  
Performance Insights:
  Enabled: true
  Retention: 7 days

Parameter Group:
  max_connections: 200
  shared_buffers: 262144 (1GB)
  work_mem: 4194 (4MB)
  maintenance_work_mem: 262144 (256MB)

Security:
  - Publicly Accessible: false
  - Storage Encryption: true (KMS)
  - IAM Database Authentication: enabled
  - Deletion Protection: true
```

#### 2.3.5 캐싱 (ElastiCache)

```yaml
# AWS ElastiCache > Create Cluster
Engine: Redis 7.0
Node Type: cache.t3.micro
Num Cache Nodes: 2
Multi-AZ: true
Automatic Failover: true
Subnet Group: private-subnets
Security Groups:
  - Allow 6379 from ECS + Lambda

Parameter Group:
  maxmemory-policy: allkeys-lru
  timeout: 300
  tcp-keepalive: 300

Backup:
  Automated Backups: enabled
  Backup Retention: 5 days
  Snapshot Window: 03:30-04:30 UTC
```

#### 2.3.6 객체 스토리지 (S3)

```yaml
# AWS S3 > Create Bucket
Bucket Name: englishgreet-media-prod
Region: us-east-1

Folder Structure:
  englishgreet-media-prod/
  ├── audio/
  │   ├── user-recordings/
  │   │   └── {user_id}/{file_id}.wav
  │   └── tts-output/
  │       └── {expression_id}/{voice_id}.mp3
  ├── images/
  │   └── avatar/{user_id}.jpg
  └── exports/
      └── {user_id}/{export_date}.json

Versioning: enabled
Server-Side Encryption: AES-256 (or KMS)
Block Public Access: enabled

Lifecycle Policy:
  - Transition audio/* to GLACIER after 90 days
  - Delete exports/* after 30 days
  - Delete user-recordings/* after 365 days

CORS Configuration:
  AllowedOrigins:
    - https://englishgreet.com
    - https://www.englishgreet.com
  AllowedMethods: GET, PUT, POST
  AllowedHeaders: "*"
  MaxAgeSeconds: 3000

Bucket Policy:
  - CloudFront OAI only
  - Deny unencrypted uploads
  - Deny non-HTTPS requests
```

---

## 3. 환경 구성

### 3.1 환경 종류 및 용도

| 환경 | 용도 | 배포 빈도 | 데이터 | 리소스 규모 |
|------|------|---------|--------|-----------|
| **Development** | 로컬 개발 | 실시간 | Mock 데이터 | 1 Dev 노트북 |
| **Staging** | QA/테스트 | 매 PR 머지 | 프로덕션 동기화 | 50% 규모 |
| **Production** | 실제 서비스 | 주 1~2회 | 실제 사용자 데이터 | 100% 규모 |

### 3.2 개발 환경 설정

```bash
# .env.development
NEXT_PUBLIC_API_BASE=http://localhost:8000
NEXT_PUBLIC_WS_URL=ws://localhost:8000/ws
DATABASE_URL=postgresql://dev:dev@localhost:5432/englishgreet_dev
REDIS_URL=redis://localhost:6379/0
AWS_S3_BUCKET=englishgreet-dev
NEXTAUTH_SECRET=dev-secret-key
NODE_ENV=development
DEBUG=true

# API 로컬 실행
npm run dev
# API: http://localhost:3000
```

**로컬 데이터베이스 초기화:**
```bash
docker-compose -f docker-compose.dev.yml up -d

# docker-compose.dev.yml
version: '3.8'
services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: dev
      POSTGRES_PASSWORD: dev
      POSTGRES_DB: englishgreet_dev
    ports:
      - "5432:5432"
    volumes:
      - postgres_dev_data:/var/lib/postgresql/data
      - ./scripts/init.sql:/docker-entrypoint-initdb.d/init.sql
  
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  postgres_dev_data:
```

### 3.3 스테이징 환경 설정

```yaml
# terraform/staging.tfvars
environment = "staging"
instance_class = "db.t3.small"
ecs_desired_count = 1
ecs_max_count = 3
lambda_memory = 1024
alb_enabled = true

# ECS Task Definition