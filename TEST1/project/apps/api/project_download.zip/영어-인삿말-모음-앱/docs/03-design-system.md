# EnglishGreet 디자인 시스템 v1.0

## 목차
1. [컬러 팔레트](#1-컬러-팔레트)
2. [타이포그래피](#2-타이포그래피)
3. [스페이싱 & 레이아웃](#3-스페이싱--레이아웃)
4. [컴포넌트 상태 색상](#4-컴포넌트-상태-색상)
5. [그림자 시스템](#5-그림자-시스템)
6. [컴포넌트 명세](#6-컴포넌트-명세)
7. [다크테마 적용 가이드](#7-다크테마-적용-가이드)

---

## 1. 컬러 팔레트

### 1.1 Primary Colors (주요 색상)

```tailwind
/* Primary - 브랜드 색상 (영어 학습의 신뢰감 & 활동성) */
primary-50:   #f0f9ff   /* Tailwind: bg-blue-50 */
primary-100:  #e0f2fe   /* bg-blue-100 */
primary-200:  #bae6fd   /* bg-blue-200 */
primary-300:  #7dd3fc   /* bg-blue-300 */
primary-400:  #38bdf8   /* bg-blue-400 */
primary-500:  #0ea5e9   /* bg-blue-500 - Main Brand */
primary-600:  #0284c7   /* bg-blue-600 */
primary-700:  #0369a1   /* bg-blue-700 - Hover State */
primary-800:  #075985   /* bg-blue-800 */
primary-900:  #0c3d66   /* bg-blue-900 */
```

**사용처**:
- 기본 버튼 & CTA (Call-To-Action)
- 활성 탭 & 네비게이션
- 즐겨찾기 아이콘 (활성)
- 링크 텍스트
- 진행도 표시줄

### 1.2 Secondary Colors (보조 색상)

```tailwind
/* Secondary - 카테고리 & 상호작용성 강화 */
secondary-50:   #fef3c7   /* Warmth & Encouragement */
secondary-100:  #fde68a
secondary-200:  #fcd34d
secondary-300:  #fbbf24
secondary-400:  #f59e0b
secondary-500:  #f97316   /* Orange - Accent */
secondary-600:  #ea580c
secondary-700:  #c2410c
secondary-800:  #92400e
secondary-900:  #78350f
```

**사용처**:
- 경고/주의 메시지
- 특정 카테고리 강조
- 한정된 콘텐츠 표시 (프리미엄)
- 음성 재생 중 인디케이터

### 1.3 Success Colors (성공 상태)

```tailwind
success-50:   #f0fdf4   /* bg-green-50 */
success-100:  #dcfce7   /* bg-green-100 */
success-200:  #bbf7d0   /* bg-green-200 */
success-300:  #86efac   /* bg-green-300 */
success-400:  #4ade80   /* bg-green-400 */
success-500:  #22c55e   /* bg-green-500 - Main Success */
success-600:  #16a34a   /* bg-green-600 */
success-700:  #15803d   /* bg-green-700 */
```

**사용처**:
- 학습 완료 배지
- 마일스톤 달성 표시
- 긍정적 피드백 메시지
- 체크마크 아이콘

### 1.4 Error Colors (에러 상태)

```tailwind
error-50:   #fef2f2   /* bg-red-50 */
error-100:  #fee2e2   /* bg-red-100 */
error-200:  #fecaca   /* bg-red-200 */
error-300:  #fca5a5   /* bg-red-300 */
error-400:  #f87171   /* bg-red-400 */
error-500:  #ef4444   /* bg-red-500 - Main Error */
error-600:  #dc2626   /* bg-red-600 */
error-700:  #b91c1c   /* bg-red-700 */
```

**사용처**:
- 에러 메시지
- 삭제 버튼 (위험)
- 입력 필드 에러 상태
- 위험 작업 경고

### 1.5 Warning Colors (경고 상태)

```tailwind
warning-50:   #fffbeb   /* bg-amber-50 */
warning-100:  #fef3c7   /* bg-amber-100 */
warning-200:  #fde68a   /* bg-amber-200 */
warning-300:  #fcd34d   /* bg-amber-300 */
warning-400:  #fbbf24   /* bg-amber-400 */
warning-500:  #f59e0b   /* bg-amber-500 - Main Warning */
warning-600:  #d97706   /* bg-amber-600 */
warning-700:  #b45309   /* bg-amber-700 */
```

**사용처**:
- 주의 메시지
- 정보성 알림
- 한정된 기능 안내

### 1.6 Neutral Colors (중립 색상 - 다크테마)

```tailwind
/* Dark Mode Base */
neutral-50:   #f9fafb   /* bg-gray-50 - Light accents only */
neutral-100:  #f3f4f6   /* bg-gray-100 */
neutral-200:  #e5e7eb   /* bg-gray-200 - Borders */
neutral-300:  #d1d5db   /* bg-gray-300 */
neutral-400:  #9ca3af   /* bg-gray-400 - Secondary text */
neutral-500:  #6b7280   /* bg-gray-500 - Tertiary text */
neutral-600:  #4b5563   /* bg-gray-600 - Dark text */
neutral-700:  #374151   /* bg-gray-700 - Card backgrounds */
neutral-800:  #1f2937   /* bg-gray-800 - Secondary backgrounds */
neutral-900:  #111827   /* bg-gray-900 - Main backgrounds */
neutral-950:  #030712   /* bg-gray-950 - Deep dark (Optional) */
```

**사용처**:
- 배경색 (neutral-900 기본)
- 텍스트 색상
- 보더 & 디바이더
- 비활성 상태

### 1.7 다크테마 색상 매핑

```css
/* Tailwind Dark Mode */
@media (prefers-color-scheme: dark) {
  :root {
    /* Main Background */
    --bg-primary: #111827;      /* neutral-900 */
    --bg-secondary: #1f2937;    /* neutral-800 */
    --bg-tertiary: #374151;     /* neutral-700 */
    
    /* Text Colors */
    --text-primary: #f9fafb;    /* neutral-50 */
    --text-secondary: #d1d5db;  /* neutral-300 */
    --text-tertiary: #9ca3af;   /* neutral-400 */
    --text-disabled: #6b7280;   /* neutral-500 */
    
    /* Interactive Elements */
    --border-color: #374151;    /* neutral-700 */
    --border-light: #4b5563;    /* neutral-600 */
    
    /* Accent Colors */
    --accent-primary: #0ea5e9;  /* primary-500 */
    --accent-hover: #0369a1;    /* primary-700 */
  }
}
```

---

## 2. 타이포그래피

### 2.1 Font Family

```tailwind
/* 다국어 지원 */
font-family: {
  sans: ['Pretendard', 'system-ui', 'sans-serif'],
  /* iOS/macOS: SF Pro Display */
  /* Android: Roboto */
  /* Fallback: system-ui */
  
  mono: ['Menlo', 'Monaco', 'Courier New', 'monospace']
}

/* Tailwind Config */
theme: {
  fontFamily: {
    sans: ['Pretendard', 'system-ui', '-apple-system', 'BlinkMacSystemFont'],
    mono: ['Menlo', 'Monaco', 'Courier New']
  }
}
```

**선택 이유**:
- **Pretendard**: 한글 & 영문 최적화, 모던하고 가독성 우수
- 시스템 폰트 폴백으로 성능 최적화

### 2.2 Font Size & Line Height

```tailwind
/* Display (Large Headlines) */
display-lg:
  font-size: 2.5rem (40px)
  line-height: 1.2 (48px)
  font-weight: 700
  letter-spacing: -0.02em
  /* @apply text-4xl leading-tight font-bold tracking-tight */

display-md:
  font-size: 2rem (32px)
  line-height: 1.25 (40px)
  font-weight: 700
  letter-spacing: -0.01em
  /* @apply text-3xl leading-tight font-bold */

/* Heading (Section Titles) */
heading-lg:
  font-size: 1.875rem (30px)
  line-height: 1.3 (39px)
  font-weight: 700
  letter-spacing: -0.01em
  /* @apply text-2xl leading-tight font-bold */

heading-md:
  font-size: 1.5rem (24px)
  line-height: 1.33 (32px)
  font-weight: 600
  letter-spacing: 0
  /* @apply text-xl leading-8 font-semibold */

heading-sm:
  font-size: 1.25rem (20px)
  line-height: 1.4 (28px)
  font-weight: 600
  letter-spacing: 0
  /* @apply text-lg leading-7 font-semibold */

/* Body (Main Content) */
body-lg:
  font-size: 1.125rem (18px)
  line-height: 1.5 (27px)
  font-weight: 400
  letter-spacing: 0
  /* @apply text-base leading-relaxed */

body-md:
  font-size: 1rem (16px)
  line-height: 1.5 (24px)
  font-weight: 400
  letter-spacing: 0
  /* @apply text-base leading-6 */

body-sm:
  font-size: 0.875rem (14px)
  line-height: 1.43 (20px)
  font-weight: 400
  letter-spacing: 0.01em
  /* @apply text-sm leading-5 tracking-wide */

/* Caption (Small Text) */
caption-md:
  font-size: 0.75rem (12px)
  line-height: 1.33 (16px)
  font-weight: 500
  letter-spacing: 0.02em
  /* @apply text-xs leading-4 font-medium tracking-widest */

caption-sm:
  font-size: 0.625rem (10px)
  line-height: 1.2 (12px)
  font-weight: 500
  letter-spacing: 0.03em
  /* @apply text-[10px] font-medium tracking-wider */
```

### 2.3 Font Weight Hierarchy

```tailwind
font-weight: {
  400: 'Regular',      /* Body text, descriptions */
  500: 'Medium',       /* Labels, small headings */
  600: 'Semibold',     /* Subheadings, emphasized text */
  700: 'Bold',         /* Main headings, important text */
}

/* Tailwind Classes */
font-normal   /* 400 */
font-medium   /* 500 */
font-semibold /* 600 */
font-bold     /* 700 */
```

### 2.4 Letter Spacing

```tailwind
letter-spacing: {
  tighter: '-0.02em',  /* Tight headlines */
  tight: '-0.01em',    /* Headings */
  normal: '0em',       /* Body */
  wide: '0.01em',      /* Small text */
  wider: '0.02em',     /* Extra small labels */
  widest: '0.03em',    /* Tiny captions */
}

/* 음성 발음 표기 (특별 스타일) */
.phonetic {
  @apply text-sm font-medium tracking-widest text-primary-400;
  font-family: 'Menlo', monospace;
}
```

### 2.5 Typography 적용 사례

```html
<!-- Display - 온보딩 화면 타이틀 -->
<h1 class="text-4xl leading-tight font-bold tracking-tight">
  5초 안에 영어 인삿말을 찾아보세요
</h1>

<!-- Heading - 섹션 타이틀 -->
<h2 class="text-2xl leading-tight font-bold">
  자주 사용하는 표현
</h2>

<!-- Body - 설명 텍스트 -->
<p class="text-base leading-6 text-neutral-300">
  일상에서 자주 쓰는 영어 인삿말을 배워보세요.
</p>

<!-- Caption - 서브 정보 -->
<span class="text-xs leading-4 font-medium tracking-widest text-neutral-500">
  [발음] ɡrɪˈtɪŋ
</span>

<!-- Phonetic - 음성 기호 -->
<code class="phonetic">/ɡrɪˈtɪŋ/</code>
```

---

## 3. 스페이싱 & 레이아웃

### 3.1 Spacing Scale (8px 기반)

```tailwind
spacing: {
  0: '0px',
  1: '0.25rem' (4px),    /* Extra small gaps */
  2: '0.5rem' (8px),     /* Base unit */
  3: '0.75rem' (12px),
  4: '1rem' (16px),      /* Standard padding */
  5: '1.25rem' (20px),
  6: '1.5rem' (24px),    /* Card spacing */
  7: '1.75rem' (28px),
  8: '2rem' (32px),      /* Section spacing */
  10: '2.5rem' (40px),
  12: '3rem' (48px),     /* Large gaps */
  14: '3.5rem' (56px),
  16: '4rem' (64px),     /* Hero sections */
}

/* Tailwind Classes */
p-0 to p-16          /* Padding */
m-0 to m-16          /* Margin