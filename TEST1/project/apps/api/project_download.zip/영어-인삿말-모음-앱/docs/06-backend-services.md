# EnglishGreet 서비스 레이어 & Repository 패턴 구현

## 1. 도메인 모델 정의

```java
// domain/model/Greeting.java
package com.englishgreet.domain.model;

import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "greetings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Greeting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String englishText;
    
    @Column(nullable = false)
    private String koreanMeaning;
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private GreetingCategory category;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Situation situation;
    
    @Column(nullable = false)
    private String audioUrl;
    
    @Column(name = "difficulty_level")
    @Enumerated(EnumType.STRING)
    private DifficultyLevel difficultyLevel;
    
    @Column(name = "native_speaker")
    private String nativeSpeaker;
    
    @Column(name = "view_count")
    @Builder.Default
    private Long viewCount = 0L;
    
    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}

// domain/model/UserGreeting.java
@Entity
@Table(name = "user_greetings", 
       uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "greeting_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserGreeting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "greeting_id", nullable = false)
    private Greeting greeting;
    
    @Column(name = "is_favorited")
    @Builder.Default
    private Boolean isFavorited = false;
    
    @Column(name = "learning_count")
    @Builder.Default
    private Long learningCount = 0L;
    
    @Column(name = "last_learned_at")
    private LocalDateTime lastLearnedAt;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}

// domain/model/User.java
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    @Column(nullable = false)
    private String nickname;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private UserRole role = UserRole.USER;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private SubscriptionStatus subscriptionStatus = SubscriptionStatus.FREE;
    
    @Column(name = "subscription_end_date")
    private LocalDateTime subscriptionEndDate;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}

// domain/model/LearningHistory.java
@Entity
@Table(name = "learning_histories", 
       indexes = @Index(name = "idx_user_created", columnList = "user_id,created_at"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LearningHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "greeting_id", nullable = false)
    private Greeting greeting;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ActionType actionType;
    
    @Column(name = "duration_seconds")
    private Long durationSeconds;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}

// domain/enums
public enum GreetingCategory {
    CASUAL, FORMAL, BUSINESS, TRAVEL, SOCIAL
}

public enum Situation {
    MORNING, EVENING, INTRODUCTION, THANKS, APOLOGY, 
    FAREWELL, QUESTION, RESPONSE, EMERGENCY
}

public enum DifficultyLevel {
    BEGINNER, INTERMEDIATE, ADVANCED
}

public enum ActionType {
    VIEW, PLAY_AUDIO, FAVORITE, UNFAVORITE
}

public enum UserRole {
    USER, ADMIN
}

public enum SubscriptionStatus {
    FREE, PREMIUM, EXPIRED
}
```

---

## 2. Repository 패턴 구현

```java
// infrastructure/repository/GreetingRepository.java
package com.englishgreet.infrastructure.repository;

import com.englishgreet.domain.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface GreetingRepository extends JpaRepository<Greeting, Long> {
    
    // 기본 조회
    List<Greeting> findByCategory(GreetingCategory category);
    
    List<Greeting> findBySituation(Situation situation);
    
    List<Greeting> findByCategoryAndSituation(
        GreetingCategory category, 
        Situation situation
    );
    
    // 페이징 조회
    Page<Greeting> findByIsActiveTrue(Pageable pageable);
    
    Page<Greeting> findByIsActiveTrueAndCategory(
        GreetingCategory category, 
        Pageable pageable
    );
    
    Page<Greeting> findByIsActiveTrueAndSituation(
        Situation situation, 
        Pageable pageable
    );
    
    Page<Greeting> findByIsActiveTrueAndCategoryAndSituation(
        GreetingCategory category,
        Situation situation,
        Pageable pageable
    );
    
    // 검색
    @Query("SELECT g FROM Greeting g WHERE g.isActive = true " +
           "AND (LOWER(g.englishText) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(g.koreanMeaning) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Greeting> searchByKeyword(
        @Param("keyword") String keyword,
        Pageable pageable
    );
    
    // 인기순 조회
    @Query("SELECT g FROM Greeting g WHERE g.isActive = true " +
           "ORDER BY g.viewCount DESC, g.id DESC")
    Page<Greeting> findPopular(Pageable pageable);
    
    // 최신순 조회
    @Query("SELECT g FROM Greeting g WHERE g.isActive = true " +
           "ORDER BY g.createdAt DESC")
    Page<Greeting> findLatest(Pageable pageable);
    
    // 난이도별 조회
    Page<Greeting> findByIsActiveTrueAndDifficultyLevel(
        DifficultyLevel level,
        Pageable pageable
    );
    
    // 조회수 증가 (벌크 업데이트)
    @Query("UPDATE Greeting g SET g.viewCount = g.viewCount + 1 " +
           "WHERE g.id = :greetingId")
    void incrementViewCount(@Param("greetingId") Long greetingId);
}

// infrastructure/repository/UserGreetingRepository.java
@Repository
public interface UserGreetingRepository extends JpaRepository<UserGreeting, Long> {
    
    // 사용자의 즐겨찾기 조회
    @Query("SELECT ug FROM UserGreeting ug WHERE ug.user.id = :userId " +
           "AND ug.isFavorited = true ORDER BY ug.updatedAt DESC")
    Page<UserGreeting> findFavoritesByUserId(
        @Param("userId") Long userId,
        Pageable pageable
    );
    
    // 사용자의 학습 표현 조회
    @Query("SELECT ug FROM UserGreeting ug WHERE ug.user.id = :userId " +
           "ORDER BY ug.lastLearnedAt DESC NULLS LAST")
    Page<UserGreeting> findLearningsByUserId(
        @Param("userId") Long userId,
        Pageable pageable
    );
    
    // 사용자-표현 조회
    Optional<UserGreeting> findByUserIdAndGreetingId(Long userId, Long greetingId);
    
    // 즐겨찾기 여부 확인
    boolean existsByUserIdAndGreetingIdAndIsFavoritedTrue(Long userId, Long greetingId);
    
    // 사용자의 전체 즐겨찾기 수
    long countByUserIdAndIsFavoritedTrue(Long userId);
    
    // 사용자의 카테고리별 즐겨찾기
    @Query("SELECT COUNT(ug) FROM UserGreeting ug " +
           "WHERE ug.user.id = :userId AND ug.isFavorited = true " +
           "AND ug.greeting.category = :category")
    long countFavoritesByCategory(
        @Param("userId") Long userId,
        @Param("category") GreetingCategory category
    );
}

// infrastructure/repository/LearningHistoryRepository.java
@Repository
public interface LearningHistoryRepository extends JpaRepository<LearningHistory, Long> {
    
    // 사용자의 학습 이력 조회
    @Query("SELECT lh FROM LearningHistory lh WHERE lh.user.id = :userId " +
           "ORDER BY lh.createdAt DESC")
    Page<LearningHistory> findByUserId(
        @Param("userId") Long userId,
        Pageable pageable
    );
    
    // 특정 기간의 학습 이력
    @Query("SELECT lh FROM LearningHistory lh WHERE lh.user.id = :userId " +
           "AND lh.createdAt BETWEEN :startDate AND :endDate " +
           "ORDER BY lh.createdAt DESC")
    List<LearningHistory> findByUserIdAndDateRange(
        @Param("userId") Long userId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate
    );
    
    // 일일 학습 통계
    @Query("SELECT new map(DATE(lh.createdAt) as date, COUNT(*) as count) " +
           "FROM LearningHistory lh WHERE lh.user.id = :userId " +
           "AND lh.createdAt BETWEEN :startDate AND :endDate " +
           "GROUP BY DATE(lh.createdAt) ORDER BY DATE(lh.createdAt) DESC")
    List<Map<String, Object>> getDailyStats(
        @Param("userId") Long userId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate
    );
    
    // 액션 타입별 통계
    @Query("SELECT new map(lh.actionType as actionType, COUNT(*) as count) " +
           "FROM LearningHistory lh WHERE lh.user.id = :userId " +
           "AND lh.createdAt BETWEEN :startDate AND :endDate " +
           "GROUP BY lh.actionType")
    List<Map<String, Object>> getActionTypeStats(
        @Param("userId") Long userId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate
    );
    
    // 가장 많이 학습한 표현
    @Query("SELECT lh.greeting.id FROM LearningHistory lh " +
           "WHERE lh.user.id = :userId " +
           "GROUP BY lh.greeting.id ORDER BY COUNT(*) DESC")
    List<Long> findMostLearnedGreetingIds(
        @Param("userId") Long userId,
        Pageable pageable
    );
}

// infrastructure/repository/UserRepository.java
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    
    boolean existsByEmail(String email);
    
    @Query("SELECT u FROM User u WHERE u.subscriptionStatus = 'PREMIUM' " +
           "AND u.subscriptionEndDate < :now")
    List<User> findExpiredSubscriptions(@Param("now") LocalDateTime now);
}
```

---

## 3. Service 레이어 구현

```java
// application/service/GreetingService.java
package com.englishgreet.application.service;

import com.englishgreet.domain.model.*;
import com.englishgreet.infrastructure.repository.*;
import com.englishgreet.application.dto.*;
import com.englishgreet.application.exception.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.