# 영어 인삿말 모음 앱

이 ZIP은 AgileFlow 파이프라인 결과물을 문서와 개발 소스로 정리한 패키지입니다.

## 포함 내용

- docs/: 원본 에이전트 산출물 27개
- generated/frontend/: 추출된 프론트엔드 소스 8개
- generated/backend/: 추출된 백엔드 소스 8개

## 사용 방법

1. docs/ 아래 문서를 먼저 읽고 전체 구조와 의도를 확인합니다.
2. generated/frontend 와 generated/backend 파일을 새 프로젝트나 기존 저장소에 맞게 복사합니다.
3. docs/05-frontend-setup.md 와 docs/06-backend-setup.md 를 참고해 환경 변수와 의존성을 맞춥니다.
4. 생성 소스는 AI 산출물이므로 실행 전에 경로, 의존성, 보안 설정을 검토합니다.
5. 동일 경로 충돌이 있으면 아래 경고 목록을 참고해 어떤 산출물이 제외됐는지 확인합니다.

## 추출된 소스 파일

- generated/frontend/src/store/authStore.ts
- generated/frontend/src/store/uiStore.ts
- generated/frontend/src/store/lessonStore.ts
- generated/frontend/src/hooks/queries/useAuthQueries.ts
- generated/frontend/src/hooks/queries/useLessonQueries.ts
- generated/frontend/src/hooks/queries/useVocabularyQueries.ts
- generated/frontend/src/hooks/useAuth.ts
- generated/frontend/src/hooks/useTheme.ts
- generated/backend/prisma/schema.prisma
- generated/backend/src/types/index.ts
- generated/backend/src/schemas/auth.ts
- generated/backend/src/schemas/greeting.ts
- generated/backend/src/schemas/common.ts
- generated/backend/src/middleware/auth.ts
- generated/backend/src/middleware/errorHandler.ts
- generated/backend/src/services/authService.ts

## 포함된 문서

- docs/01-idea-analysis.md
- docs/02-requirements.md
- docs/03-design-system.md
- docs/03-wireframes.md
- docs/03-components.md
- docs/04-tech-stack.md
- docs/04-architecture.md
- docs/04-database-schema.md
- docs/04-project-structure.md
- docs/05-frontend-setup.md
- docs/05-frontend-components.md
- docs/05-frontend-pages.md
- docs/05-frontend-hooks.md
- docs/06-backend-setup.md
- docs/06-backend-schema.md
- docs/06-backend-routes.md
- docs/06-backend-services.md
- docs/07-test-strategy.md
- docs/07-backend-tests.md
- docs/07-frontend-tests.md
- docs/07-e2e-tests.md
- docs/07-code-review.md
- docs/08-docker.md
- docs/08-cicd.md
- docs/08-infrastructure.md
- docs/08-monitoring.md
- docs/09-final-report.md