import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

export interface Lesson {
  id: string;
  title: string;
  category: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  progress: number;
  isFavorite: boolean;
  completedAt?: string;
}

interface LessonFilters {
  search: string;
  category: string;
  level: 'all' | 'beginner' | 'intermediate' | 'advanced';
  favoriteOnly: boolean;
}

interface LessonState {
  lessons: Lesson[];
  filters: LessonFilters;
  selectedLessonId: string | null;
  
  // Actions
  setLessons: (lessons: Lesson[]) => void;
  updateLesson: (id: string, lesson: Partial<Lesson>) => void;
  toggleFavorite: (id: string) => void;
  setFilters: (filters: Partial<LessonFilters>) => void;
  setSelectedLesson: (id: string | null) => void;
  resetFilters: () => void;
}

const defaultFilters: LessonFilters = {
  search: '',
  category: '',
  level: 'all',
  favoriteOnly: false,
};

export const useLessonStore = create<LessonState>()(
  devtools(
    (set) => ({
      lessons: [],
      filters: defaultFilters,
      selectedLessonId: null,

      setLessons: (lessons) => set({ lessons }),
      updateLesson: (id, updatedLesson) =>
        set((state) => ({
          lessons: state.lessons.map((lesson) =>
            lesson.id === id ? { ...lesson, ...updatedLesson } : lesson
          ),
        })),
      toggleFavorite: (id) =>
        set((state) => ({
          lessons: state.lessons.map((lesson) =>
            lesson.id === id
              ? { ...lesson, isFavorite: !lesson.isFavorite }
              : lesson
          ),
        })),
      setFilters: (filters) =>
        set((state) => ({
          filters: { ...state.filters, ...filters },
        })),
      setSelectedLesson: (id) => set({ selectedLessonId: id }),
      resetFilters: () => set({ filters: defaultFilters }),
    }),
    { name: 'LessonStore' }
  )
);