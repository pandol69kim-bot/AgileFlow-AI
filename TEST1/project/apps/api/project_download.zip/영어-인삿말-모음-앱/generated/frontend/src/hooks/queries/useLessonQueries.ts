import {
  useMutation,
  useQuery,
  useQueryClient,
  useInfiniteQuery,
} from '@tanstack/react-query';
import { useLessonStore } from '@/store/lessonStore';
import { lessonAPI } from '@/api/lesson';

interface GetLessonsParams {
  search?: string;
  category?: string;
  level?: string;
  favoriteOnly?: boolean;
  page?: number;
}

export const useLessonsQuery = (params?: GetLessonsParams) => {
  const { setLessons, filters } = useLessonStore();

  return useQuery({
    queryKey: ['lessons', { ...filters, ...params }],
    queryFn: () =>
      lessonAPI.getLessons({
        ...filters,
        ...params,
      }),
    staleTime: 1000 * 60 * 5,
    onSuccess: (data) => setLessons(data.lessons),
  });
};

export const useLessonsInfiniteQuery = () => {
  const { filters } = useLessonStore();

  return useInfiniteQuery({
    queryKey: ['lessons-infinite', filters],
    queryFn: ({ pageParam = 1 }) =>
      lessonAPI.getLessons({
        ...filters,
        page: pageParam,
      }),
    getNextPageParam: (lastPage) =>
      lastPage.hasMore ? lastPage.nextPage : undefined,
    initialPageParam: 1,
  });
};

export const useLessonDetailQuery = (lessonId: string | null) => {
  return useQuery({
    queryKey: ['lesson', lessonId],
    queryFn: () => lessonAPI.getLessonDetail(lessonId!),
    enabled: !!lessonId,
    staleTime: 1000 * 60 * 10,
  });
};

export const useUpdateProgressMutation = () => {
  const queryClient = useQueryClient();
  const { updateLesson } = useLessonStore();

  return useMutation({
    mutationFn: (data: { lessonId: string; progress: number }) =>
      lessonAPI.updateProgress(data.lessonId, data.progress),
    onMutate: async (data) => {
      // Optimistic update
      updateLesson(data.lessonId, { progress: data.progress });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: ['lesson', variables.lessonId],
      });
    },
  });
};

export const useToggleFavoriteMutation = () => {
  const queryClient = useQueryClient();
  const { toggleFavorite } = useLessonStore();

  return useMutation({
    mutationFn: (lessonId: string) =>
      lessonAPI.toggleFavorite(lessonId),
    onMutate: (lessonId) => {
      toggleFavorite(lessonId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lessons'] });
    },
  });
};

export const useLessonStatisticsQuery = () => {
  return useQuery({
    queryKey: ['lesson-statistics'],
    queryFn: () => lessonAPI.getStatistics(),
    staleTime: 1000 * 60 * 5,
  });
};