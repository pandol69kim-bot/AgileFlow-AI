import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { vocabularyAPI } from '@/api/vocabulary';

export interface VocabularyWord {
  id: string;
  word: string;
  pronunciation: string;
  meaning: string;
  example: string;
  difficulty: 'easy' | 'medium' | 'hard';
  learned: boolean;
}

export const useVocabularyQuery = (lessonId: string) => {
  return useQuery({
    queryKey: ['vocabulary', lessonId],
    queryFn: () => vocabularyAPI.getVocabulary(lessonId),
    staleTime: 1000 * 60 * 10,
  });
};

export const useMarkWordLearned = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (wordId: string) =>
      vocabularyAPI.markWordLearned(wordId),
    onSuccess: (_, wordId) => {
      queryClient.invalidateQueries({ queryKey: ['vocabulary'] });
    },
  });
};

export const usePlayAudioMutation = () => {
  return useMutation({
    mutationFn: (word: string) =>
      vocabularyAPI.getAudio(word),
  });
};