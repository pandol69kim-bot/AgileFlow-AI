import { useEffect } from 'react';
import { useAuthStore } from '@/store/authStore';
import { useUserQuery, useLogoutMutation } from './queries/useAuthQueries';

export const useAuth = () => {
  const {
    user,
    isAuthenticated,
    isLoading,
    error,
    setLoading,
    clearError,
  } = useAuthStore();
  
  const { data: userData, isLoading: queryLoading } = useUserQuery(
    isAuthenticated
  );
  const logoutMutation = useLogoutMutation();

  useEffect(() => {
    setLoading(queryLoading);
  }, [queryLoading, setLoading]);

  return {
    user,
    isAuthenticated,
    isLoading: isLoading || queryLoading,
    error,
    clearError,
    logout: logoutMutation.mutate,
    isPremium: user?.role === 'premium',
    isAdmin: user?.role === 'admin',
  };
};