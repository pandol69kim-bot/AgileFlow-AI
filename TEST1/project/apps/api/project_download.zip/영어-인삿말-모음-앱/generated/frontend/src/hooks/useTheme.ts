import { useEffect } from 'react';
import { useUIStore } from '@/store/uiStore';

export const useTheme = () => {
  const { theme, setTheme } = useUIStore();

  useEffect(() => {
    // 시스템 테마 감지
    if (theme === 'system') {
      const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const isDark = darkModeQuery.matches;
      
      if (isDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }

      const handleChange = (e: MediaQueryListEvent) => {
        if (e.matches) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      };

      darkModeQuery.addEventListener('change', handleChange);
      return () => darkModeQuery.removeEventListener('change', handleChange);
    }

    // 명시적 테마 설정
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  return {
    theme,
    setTheme,
    isDark: theme === 'dark',
  };
};