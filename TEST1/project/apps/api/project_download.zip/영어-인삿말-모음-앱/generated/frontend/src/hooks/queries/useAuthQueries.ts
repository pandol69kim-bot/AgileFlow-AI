import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/store/authStore';
import { authAPI } from '@/api/auth';

export const useLoginMutation = () => {
  const queryClient = useQueryClient();
  const { setUser, setError } = useAuthStore();

  return useMutation({
    mutationFn: (credentials: { email: string; password: string }) =>
      authAPI.login(credentials),
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || '로그인 실패';
      setError(message);
    },
  });
};

export const useSignUpMutation = () => {
  const queryClient = useQueryClient();
  const { setUser, setError } = useAuthStore();

  return useMutation({
    mutationFn: (data: {
      email: string;
      password: string;
      name: string;
    }) => authAPI.signUp(data),
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || '회원가입 실패';
      setError(message);
    },
  });
};

export const useLogoutMutation = () => {
  const queryClient = useQueryClient();
  const { logout } = useAuthStore();

  return useMutation({
    mutationFn: () => authAPI.logout(),
    onSuccess: () => {
      logout();
      queryClient.clear();
    },
  });
};

export const useUserQuery = (enabled: boolean = true) => {
  const { setUser } = useAuthStore();

  return useQuery({
    queryKey: ['user'],
    queryFn: () => authAPI.getUser(),
    enabled,
    staleTime: 1000 * 60 * 5, // 5분
    onSuccess: (data) => setUser(data),
  });
};