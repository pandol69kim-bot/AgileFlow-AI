import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

type ThemeMode = 'light' | 'dark' | 'system';

interface UIState {
  theme: ThemeMode;
  sidebarOpen: boolean;
  notificationCount: number;
  
  // Actions
  setTheme: (theme: ThemeMode) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  setNotificationCount: (count: number) => void;
  incrementNotification: () => void;
  clearNotifications: () => void;
}

export const useUIStore = create<UIState>()(
  devtools(
    (set) => ({
      theme: 'system' as ThemeMode,
      sidebarOpen: true,
      notificationCount: 0,

      setTheme: (theme) => set({ theme }),
      toggleSidebar: () => set((state) => ({ 
        sidebarOpen: !state.sidebarOpen 
      })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setNotificationCount: (count) => set({ notificationCount: count }),
      incrementNotification: () => set((state) => ({ 
        notificationCount: state.notificationCount + 1 
      })),
      clearNotifications: () => set({ notificationCount: 0 }),
    }),
    { name: 'UIStore' }
  )
);