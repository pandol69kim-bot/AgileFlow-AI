import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { jwtSecret } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';
import { User, JwtPayload, TokenResponse } from '../types';

// 임시 메모리 저장소 (실제로는 DB 사용)
const users: Map<string, User> = new Map();

export class AuthService {
  async register(email: string, password: string): Promise<User> {
    // 중복 이메일 확인
    const existingUser = Array.from(users.values()).find(
      (u) => u.email === email
    );
    if (existingUser) {
      throw new AppError(409, 'EMAIL_ALREADY_EXISTS', '이미 등록된 이메일입니다');
    }

    // 비밀번호 해시
    const hashedPassword = await bcrypt.hash(password, 10);

    const user: User = {
      id: crypto.randomUUID(),
      email,
      password: hashedPassword,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    users.set(user.id, user);
    return { ...user, password: undefined } as any;
  }

  async login(email: string, password: string): Promise<TokenResponse> {
    // 사용자 조회
    const user = Array.from(users.values()).find((u) => u.email === email);
    if (!user) {
      throw new AppError(401, 'INVALID_CREDENTIALS', '이메일 또는 비밀번호가 틀렸습니다');
    }

    // 비밀번호 검증
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw new AppError(401, 'INVALID_CREDENTIALS', '이메일 또는 비밀번호가 틀렸습니다');
    }

    // 토큰 생성
    const payload: JwtPayload = {
      userId: user.id,
      email: user.email,
    };

    const accessToken = jwt.sign(payload, jwtSecret, {
      expiresIn: '1h',
    });

    const refreshToken = jwt.sign(payload, jwtSecret, {
      expiresIn: '7d',
    });

    return {
      accessToken,
      refreshToken,
      expiresIn: 3600, // 1시간 (초 단위)
    };
  }

  async refreshToken(refreshToken: string): Promise<TokenResponse> {
    try {
      const payload = jwt.verify(refreshToken, jwtSecret) as JwtPayload;

      const newAccessToken = jwt.sign(
        { userId: payload.userId, email: payload.email },
        jwtSecret,
        { expiresIn: '1h' }
      );

      return {
        accessToken: newAccessToken,
        refreshToken, // 재사용 가능
        expiresIn: 3600,
      };
    } catch (error) {
      throw new AppError(401, 'INVALID_REFRESH_TOKEN', 'Refresh token이 유효하지 않습니다');
    }
  }

  getUserById(userId: string): User | null {
    return users.get(userId) || null;
  }
}

export const authService = new AuthService();