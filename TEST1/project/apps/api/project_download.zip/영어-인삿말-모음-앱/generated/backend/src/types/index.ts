export interface User {
  id: string;
  email: string;
  password: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Greeting {
  id: string;
  korean: string;
  english: string;
  pronunciation: string;
  category: 'casual' | 'business' | 'travel' | 'formal';
  audioUrl: string;
  difficulty: 'easy' | 'medium' | 'hard';
  createdAt: Date;
}

export interface Favorite {
  id: string;
  userId: string;
  greetingId: string;
  createdAt: Date;
}

export interface JwtPayload {
  userId: string;
  email: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };
  timestamp: string;
}

export interface AuthRequest {
  email: string;
  password: string;
}

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}