import { FastifyError, FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';

export class AppError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const errorHandler = (
  error: FastifyError | AppError | ZodError | Error,
  request: FastifyRequest,
  reply: FastifyReply
) => {
  const timestamp = new Date().toISOString();

  // Zod 검증 에러
  if (error instanceof ZodError) {
    return reply.code(400).send({
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: '입력 데이터 검증 실패',
        details: error.errors.map((e) => ({
          path: e.path.join('.'),
          message: e.message,
        })),
      },
      timestamp,
    });
  }

  // 커스텀 앱 에러
  if (error instanceof AppError) {
    return reply.code(error.statusCode).send({
      success: false,
      error: {
        code: error.code,
        message: error.message,
      },
      timestamp,
    });
  }

  // Fastify 내장 에러
  if ('statusCode' in error) {
    return reply.code(error.statusCode).send({
      success: false,
      error: {
        code: 'FASTIFY_ERROR',
        message: error.message || '서버 오류가 발생했습니다',
      },
      timestamp,
    });
  }

  // 예상치 못한 에러
  console.error('Unexpected error:', error);
  return reply.code(500).send({
    success: false,
    error: {
      code: 'INTERNAL_SERVER_ERROR',
      message: '서버 오류가 발생했습니다',
    },
    timestamp,
  });
};