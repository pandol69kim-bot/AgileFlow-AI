import { z } from 'zod';

export const greetingQuerySchema = z.object({
  category: z
    .enum(['casual', 'business', 'travel', 'formal'])
    .optional(),
  difficulty: z.enum(['easy', 'medium', 'hard']).optional(),
  search: z.string().max(100).optional(),
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export const addFavoriteSchema = z.object({
  greetingId: z.string().uuid('유효한 ID를 입력해주세요'),
});

export const removeFavoriteSchema = z.object({
  greetingId: z.string().uuid('유효한 ID를 입력해주세요'),
});

export type GreetingQuery = z.infer<typeof greetingQuerySchema>;
export type AddFavoriteInput = z.infer<typeof addFavoriteSchema>;
export type RemoveFavoriteInput = z.infer<typeof removeFavoriteSchema>;