import { FastifyRequest, FastifyReply } from 'fastify';
import jwt from '@fastify/jwt';
import { JwtPayload } from '../types';

export const jwtSecret = process.env.JWT_SECRET || 'your-super-secret-key';

export const verifyJwt = async (
  request: FastifyRequest,
  reply: FastifyReply
) => {
  try {
    await request.jwtVerify();
  } catch (error) {
    reply.code(401).send({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: '인증 토큰이 유효하지 않습니다',
      },
      timestamp: new Date().toISOString(),
    });
  }
};

export const extractUserFromToken = (
  request: FastifyRequest
): JwtPayload => {
  return request.user as JwtPayload;
};

// 선택적 인증 (로그인하지 않은 사용자도 접근 가능)
export const optionalAuth = async (
  request: FastifyRequest,
  reply: FastifyReply
) => {
  try {
    await request.jwtVerify();
  } catch (error) {
    // 인증 실패해도 계속 진행 (request.user는 undefined)
  }
};