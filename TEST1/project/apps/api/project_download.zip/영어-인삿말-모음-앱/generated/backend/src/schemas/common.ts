import { z } from 'zod';

export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export const uuidSchema = z.string().uuid('유효한 UUID를 입력해주세요');

export type PaginationInput = z.infer<typeof paginationSchema>;